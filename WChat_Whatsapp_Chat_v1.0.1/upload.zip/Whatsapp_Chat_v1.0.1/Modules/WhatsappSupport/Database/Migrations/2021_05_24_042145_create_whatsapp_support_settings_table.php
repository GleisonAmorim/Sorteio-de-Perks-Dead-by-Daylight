<?php

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWhatsappSupportSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('whatsapp_support_settings', function (Blueprint $table) {
            $table->id();
            $table->string('agent_type')->default('single');
            $table->string('availability')->default('both')->comment('mobile','desktop','both');
            $table->string('showing_page')->default('all')->comment('all','homepage');
            $table->string('color')->default('#0dc152');
            $table->text('intro_text')->nullable();
            $table->text('welcome_message')->nullable();
            $table->text('homepage_url');
            $table->string('primary_number');
            $table->boolean('open_popup')->default(false);
            $table->boolean('show_unavailable_agent')->default(true);
            $table->integer('layout')->default(1);
            $table->string('icon_position')->default('bottom_right');
            $table->integer('bottom')->default(20);
            $table->integer('right')->default(30);
            $table->integer('left')->default(30);
            $table->string('bubble_logo')->default('public/whatsapp-support/demo-avatar.jpg');
            $table->string('layout_preview_url')->default('whatsapp-support/preview-1.png');
            $table->timestamps();
        });

        DB::table('whatsapp_support_settings')->insert([
            'intro_text' => 'Our customer support team is here to answer your questions. Ask us anything!',
            'welcome_message' => 'Hi, How can I help?',
            'homepage_url' => '',
            'primary_number' => '+8801841412141'
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('whatsapp_support_settings');
    }
}
