<?php

use App\Models\User;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;
use Modules\WhatsappSupport\Entities\Agents;

class CreateWhatsappSupportAgentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('whatsapp_support_agents', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('designation');
            $table->string('avatar')->nullable();
            $table->string('number');
            $table->boolean('status')->default(true);
            $table->foreignId('user_id')->constrained('users');
            $table->boolean('always_available')->default(false);
            $table->timestamps();
        });

        $agent = User::where('role_id', 3)->first();

        Agents::create([
            'name' => $agent->name,
            'designation' => 'Sales',
            'avatar' => 'public/whatsapp-support/demo-avatar.jpg',
            'user_id' => $agent->id,
            'number' => '+8801841412141',
            'always_available' => 1
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('whatsapp_support_agents');
    }
}
