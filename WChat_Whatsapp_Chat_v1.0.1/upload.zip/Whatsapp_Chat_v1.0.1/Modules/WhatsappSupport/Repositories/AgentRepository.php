<?php


namespace Modules\WhatsappSupport\Repositories;


use App\Models\User;
use Modules\WhatsappSupport\Entities\Agents;

class AgentRepository
{
    public static function store($data)
    {
       return Agents::create($data);
    }

    public static function update(Agents $agents, $data)
    {
       return $agents->update($data);
    }
}
