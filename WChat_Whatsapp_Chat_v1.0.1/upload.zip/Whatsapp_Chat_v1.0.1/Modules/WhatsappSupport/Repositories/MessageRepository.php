<?php


namespace Modules\WhatsappSupport\Repositories;


use App\Http\Resources\MessageResource;
use Modules\WhatsappSupport\Entities\Message;

class MessageRepository
{
    public function __construct()
    {

    }

    public static function store(array $data){
       return  Message::create([
            'ip' => $data['ip'],
            'browser'=> $data['browser'],
            'os' => $data['os'],
            'device_type' => $data['device_type'],
            'message' => $data['message'],
            'number' => $data['number'] ?? null,
        ]);
    }
}
