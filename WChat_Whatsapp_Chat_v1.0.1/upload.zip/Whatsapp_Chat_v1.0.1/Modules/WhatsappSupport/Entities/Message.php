<?php

namespace Modules\WhatsappSupport\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Mews\Purifier\Facades\Purifier;

class Message extends Model
{

    protected $guarded = [];

    protected $table = 'whatsapp_support_messages';

    protected static function newFactory()
    {
        return \Modules\WhatsappSupport\Database\factories\SettingsFactory::new();
    }

}
