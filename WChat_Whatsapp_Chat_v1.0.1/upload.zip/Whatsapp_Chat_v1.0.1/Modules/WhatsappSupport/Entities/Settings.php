<?php

namespace Modules\WhatsappSupport\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Settings extends Model
{

    protected $guarded = [];

    protected $table = 'whatsapp_support_settings';

    protected static function newFactory()
    {
        return \Modules\WhatsappSupport\Database\factories\SettingsFactory::new();
    }

    public function isMulti()
    {
        return $this->agent_type == 'multi';
    }

    public function isSingle()
    {
        return $this->agent_type == 'single';
    }

    public function forDesktop()
    {
        return $this->availability == 'desktop';
    }

    public function forMobile()
    {
        return $this->availability == 'mobile';
    }

    public function forBoth()
    {
        return $this->availability == 'both';
    }
}
