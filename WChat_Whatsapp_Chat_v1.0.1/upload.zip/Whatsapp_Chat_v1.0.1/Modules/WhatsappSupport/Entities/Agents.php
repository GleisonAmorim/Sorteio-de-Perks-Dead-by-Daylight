<?php

namespace Modules\WhatsappSupport\Entities;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Agents extends Model
{

    protected $guarded = [];

    protected $table = 'whatsapp_support_agents';

    protected static function newFactory()
    {
        return \Modules\WhatsappSupport\Database\factories\SettingsFactory::new();
    }

    public function times()
    {
        return $this->hasMany(AgentTime::class,'agent_id','id');
    }

    public function isAvailable()
    {
        if ($this->always_available) return true;

        if ($this->times->where('day', now()->dayName)->first()){
            $row = $this->times->where('day', now()->dayName)->first();
            return $row->start_time_str < strtotime(now()->format('H:s:i'))
                && $row->end_time_str > strtotime(now()->format('H:s:i'));
        }

        return false;

    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
