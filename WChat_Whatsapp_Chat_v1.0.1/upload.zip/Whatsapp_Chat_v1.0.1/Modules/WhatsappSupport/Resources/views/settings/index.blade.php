@extends('backend.master')
@section('mainContent')
    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="">
                        <div class="row">
                            <div class="col-lg-12 mb-4">
                                <div class="white_box_30px">
                                    <div class="main-title mb-25">
                                        <h3 class="mb-0">{{ __('general.your_scripts') }}</h3>
                                        <p class="text-success">{{ __('general.copy_script') }}</p>
                                    </div>
                                    <div class="primary_input mb-25">
                                        <textarea class="primary_textarea h_unset" placeholder="Company Info" id="company_info" cols="30" rows="10" name="company_info">

                                            &lt;div&gt;
                                                &lt;div id="whatsapp_support_service"&gt;
                                                &lt;whatsapp-support
                                                    :server_base_url="'{{url('/')}}/'"
                                                    :token="'{{$token}}'"
                                                &gt;&lt;/whatsapp-support&gt;
                                                &lt;/div&gt;&lt;script src="{{url('/')}}/public/js/app.js"&gt;&lt;/script&gt;
                                            &lt;/div&gt;
                                        </textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-12">
                                <div class="white_box_30px">
                                    <div class="main-title mb-25">
                                        <h3 class="mb-0">{{ __('general.view_settings') }}</h3>
                                    </div>

                                    <form action="{{ route('whatsapp-support.settings.update') }}" method="post">
                                        @csrf
                                        <div class="row" id="pusher">
                                            <div class="col-xl-12">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.color') }}</label>
                                                    <input class="primary_input_field" type="color" name="color" value="{{ app('whatsapp_support_settings')->color ?? '' }}">
                                                </div>
                                            </div>

                                            <div class="col-xl-12">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.intro_text') }}</label>
                                                    <input class="primary_input_field" name="intro_text" type="text" value="{{ app('whatsapp_support_settings')->intro_text ?? '' }}">
                                                </div>
                                            </div>

                                            <div class="col-xl-12">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.welcome_message') }}</label>
                                                    <input class="primary_input_field" name="welcome_message" type="text" value="{{ app('whatsapp_support_settings')->welcome_message ?? '' }}">
                                                </div>
                                            </div>
                                            <div class="col-xl-12 mt-4">
                                                <h5>{{ __('general.Whatsapp support icon position') }} : </h5>
                                                <div class="row">
                                                    <div class="col-xl-4">
                                                        <div class="primary_input mb-25">
                                                            <label class="primary_input_label" for="">{{ __('general.icon_position') }} *</label>
                                                            <select id="icon_position" name="icon_position" class="primary_select mb-25">
                                                                <option value="bottom_left" {{ app('whatsapp_support_settings')->icon_position === 'bottom_left' ? 'selected' : '' }}>{{ __('general.bottom_left') }}</option>
                                                                <option value="bottom_right" {{ app('whatsapp_support_settings')->icon_position === 'bottom_right' ? 'selected' : '' }}>{{ __('general.bottom_right') }}</option>
                                                            </select>
                                                            @error('icon_position') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4">
                                                        <div class="primary_input mb-25">
                                                            <label class="primary_input_label" for="">{{ __('general.margin_from_bottom') }} (px)</label>
                                                            <input class="primary_input_field" name="bottom" type="text" value="{{ app('whatsapp_support_settings')->bottom ?? '' }}">
                                                        </div>
                                                    </div>
                                                    <div class="col-xl-4 d-none" id="margin_right">
                                                        <div class="primary_input mb-25">
                                                            <label class="primary_input_label" for="">{{ __('general.margin_from_right') }} (px)</label>
                                                            <input class="primary_input_field" name="right" type="text" value="{{ app('whatsapp_support_settings')->right ?? '' }}">
                                                        </div>
                                                    </div>

                                                    <div class="col-xl-4 d-none" id="margin_left">
                                                        <div class="primary_input mb-25">
                                                            <label class="primary_input_label" for="">{{ __('general.margin_from_left') }} (px)</label>
                                                            <input class="primary_input_field" name="left" type="text" value="{{ app('whatsapp_support_settings')->left ?? '' }}">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="primary-btn radius_30px  fix-gr-bg"><i class="ti-check"></i>{{ __('general.update') }}</button>
                                    </form>

                                </div>
                            </div>

                            <div class="col-lg-12 mt-4">
                                <div class="white_box_30px">
                                    <div class="main-title mb-25">
                                        <h3 class="mb-3">{{ __('general.functional_settings') }}</h3>
                                    </div>

                                    <form action="{{ route('whatsapp-support.settings.update') }}" method="post" enctype="multipart/form-data">
                                        @csrf
                                        <div class="row" id="pusher">
                                            <div class="col-xl-6">
                                                <p class="primary_input_label">{{ __('general.agent_type') }}</p>
                                                <div class="d-flex radio-btn-flex">
                                                    <div class="mr-20">
                                                        <input type="radio" name="agent_type" {{ app('whatsapp_support_settings')->agent_type == 'multi' ? 'checked' : '' }} id="relationFather3" value="multi" class="common-radio relationButton">
                                                        <label for="relationFather3">{{ __('general.multi_agent') }}</label>
                                                    </div>
                                                    <div class="mr-20">
                                                        <input type="radio" name="agent_type" {{ app('whatsapp_support_settings')->agent_type == 'single' ? 'checked' : '' }} id="relationMother4" value="single" class="common-radio relationButton">
                                                        <label for="relationMother4">{{ __('general.single_agent') }}</label>
                                                    </div>
                                                    @error('agent_type') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                                </div>
                                            </div>

                                            <div class="col-xl-6">
                                                <p class="primary_input_label">{{ __('general.availability') }}</p>
                                                <div class="d-flex radio-btn-flex">
                                                    <div class="mr-20">
                                                        <input type="radio" name="availability" {{ app('whatsapp_support_settings')->availability == 'mobile' ? 'checked' : '' }} id="relationFather33333" value="mobile" class="common-radio relationButton" checked>
                                                        <label for="relationFather33333">{{ __('general.only_mobile') }}</label>
                                                    </div>
                                                    <div class="mr-20">
                                                        <input type="radio" name="availability" {{ app('whatsapp_support_settings')->availability == 'desktop' ? 'checked' : '' }} id="relationMother4433" value="desktop" class="common-radio relationButton">
                                                        <label for="relationMother4433">{{ __('general.only_desktop') }}</label>
                                                    </div>
                                                    <div class="mr-20">
                                                        <input type="radio" name="availability" {{ app('whatsapp_support_settings')->availability == 'both' ? 'checked' : '' }} id="relationMother4222" value="both" class="common-radio relationButton">
                                                        <label for="relationMother4222">{{ __('general.both') }}</label>
                                                    </div>
                                                    @error('availability') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <p class="primary_input_label">{{ __('general.popup_open_initially') }}</p>
                                                <div class="d-flex radio-btn-flex">
                                                    <div class="mr-20">
                                                        <input type="radio" name="open_popup" {{ app('whatsapp_support_settings')->open_popup == 1 ? 'checked' : '' }} id="relationFather3119" value="1" class="common-radio relationButton" checked>
                                                        <label for="relationFather3119">{{ __('general.yes') }}</label>
                                                    </div>
                                                    <div class="mr-20">
                                                        <input type="radio" name="open_popup" {{ app('whatsapp_support_settings')->open_popup == 0 ? 'checked' : '' }} id="relationMother4119" value="0" class="common-radio relationButton">
                                                        <label for="relationMother4119">{{ __('general.no') }}</label>
                                                    </div>
                                                    @error('open_popup') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <p class="primary_input_label">{{ __('general.show_unavailable_agent_in_popup') }}</p>
                                                <div class="d-flex radio-btn-flex">
                                                    <div class="mr-20">
                                                        <input type="radio" name="show_unavailable_agent" {{ app('whatsapp_support_settings')->show_unavailable_agent == 1 ? 'checked' : '' }} id="relationFather33333v" value="1" class="common-radio relationButton" checked>
                                                        <label for="relationFather33333v">{{ __('general.yes') }}</label>
                                                    </div>
                                                    <div class="mr-20">
                                                        <input type="radio" name="show_unavailable_agent" {{ app('whatsapp_support_settings')->show_unavailable_agent == 0 ? 'checked' : '' }} id="relationMother4433v" value="0" class="common-radio relationButton">
                                                        <label for="relationMother4433v">{{ __('general.no') }}</label>
                                                    </div>
                                                    @error('show_unavailable_agent') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                                </div>
                                            </div>
                                            <div class="col-xl-6 mt-4">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.primary_number') }}</label>
                                                    <input class="primary_input_field" name="primary_number" type="text" value="{{ app('whatsapp_support_settings')->primary_number ?? '' }}">
                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <div class="primary_input">
                                                    <label class="primary_input_label" for="">
                                                        {{ __('general.whatsapp bubble logo') }}
                                                    </label>
                                                    <div class="primary_file_uploader">
                                                        <input class="primary-input" type="text" id="php_file_input_ph" placeholder="{{ __('general.Browse') }}..." readonly="">
                                                        <button class="primary_btn_2" type="button">
                                                            <label class="primary_btn_2" for="php_file_input"> {{ __('general.Browse') }} </label>
                                                            <input type="file" class="d-none" name="bubble_pic" id="php_file_input">
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="primary-btn radius_30px fix-gr-bg mt-4"><i class="ti-check"></i>{{ __('general.update') }}</button>
                                    </form>

                                </div>
                            </div>

                            <div class="col-lg-12 mt-4">
                                <div class="white_box_30px">
                                    <div class="main-title mb-25">
                                        <h3 class="mb-0">{{ __('general.layout_settings') }}</h3>
                                    </div>

                                    <form action="{{ route('whatsapp-support.settings.update') }}" method="post">
                                        @csrf
                                        <div class="col-xl-12">
                                            <p class="primary_input_label">{{ __('general.choose_layout') }}</p>
                                            <div class="d-flex radio-btn-flex">
                                                <div class="mr-20">
                                                    <input type="radio" name="layout" {{ app('whatsapp_support_settings')->layout == 1 ? 'checked' : '' }} id="relationFather113" value="1" class="common-radio relationButton">
                                                    <label for="relationFather113"><img class="br_10" src="{{ asset('public/whatsapp-support/preview-1.png') }}" alt=""></label>
                                                </div>
                                                <div class="mr-20">
                                                    <input type="radio" name="layout" {{ app('whatsapp_support_settings')->layout == 2 ? 'checked' : '' }} id="relationMother1114" value="2" class="common-radio relationButton">
                                                    <label for="relationMother1114"><img class="br_10" src="{{ asset('public/whatsapp-support/preview-2.png') }}" alt=""></label>
                                                </div>
                                                @error('layout') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                            </div>
                                        </div>
                                        <button class="primary-btn radius_30px mt-4 fix-gr-bg"><i class="ti-check"></i>{{ __('general.update') }}</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row mt-5">
                <div class="col-lg-3 col-md-6">

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="main-title">
                                <h3 class="mb-30">@lang('general.change_logo')</h3>
                            </div>

                            {{ Form::open(['class' => 'form-horizontal', 'files' => true, 'route' => 'whatsapp-support.settings.update.gs', 'method' => 'POST', 'enctype' => 'multipart/form-data']) }}

                            <div class="white-box">
                                <div class="text-center">
                                    @if(isset($gs->logo) && !empty($gs->logo))
                                        <img class="img-fluid Img-100" src="{{asset('/')}}{{$gs->logo}}" alt="" >
                                    @else
                                        <img class="img-fluid Img-100" src="{{asset('public/backend/frontend/img/logo.png')}}" alt="">
                                    @endif
                                </div>

                                <div class="mt-40">
                                    <div class="text-center">
                                        <label class="primary-btn small fix-gr-bg" for="upload_logo">@lang('general.upload')</label>
                                        <input type="file" class="d-none form-control" name="logo_pic" id="upload_logo">
                                    </div>
                                </div>
                                <div class="col-lg-12 text-center">
                                    <button class="primary-btn fix-gr-bg">
                                        <span class="ti-check"></span>
                                        @lang('general.change_logo')
                                    </button>
                                </div>
                            </div>
                            {{ Form::close() }}
                        </div>
                    </div>


                    <div class="row mt-40">
                        <div class="col-lg-12">
                            <div class="main-title">

                                <h3 class="mb-30">@lang('general.change_fav') </h3>
                            </div>

                            {{ Form::open(['class' => 'form-horizontal', 'files' => true, 'route' => 'whatsapp-support.settings.update.gs', 'method' => 'POST', 'enctype' => 'multipart/form-data']) }}

                            <div class="white-box">
                                <div class="text-center">
                                    @if(isset($gs->favicon) && !empty($gs->favicon))
                                        <img class="img-fluid Img-50" src="{{asset('/')}}{{$gs->favicon}}" alt="" >
                                    @else
                                        <img class="img-fluid" src="{{asset('public/favicon.png')}}" alt="">
                                    @endif
                                </div>

                                <div class="mt-40">
                                    <div class="text-center">
                                        <label class="primary-btn small fix-gr-bg" for="upload_favicon">@lang('general.upload')</label>
                                        <input type="file" class="d-none form-control" name="favicon_pic" id="upload_favicon">
                                    </div>
                                </div>
                                <div class="col-lg-12 text-center">
                                    <button class="primary-btn fix-gr-bg  ">
                                        <span class="ti-check"></span>
                                        @lang('general.change_fav')
                                    </button>
                                </div>
                            </div>
                            {{ Form::close() }}
                        </div>
                    </div>



                </div>
                <div class="col-lg-9 mt-5">
                    <div class="white_box_30px">
                        <form action="{{ route('whatsapp-support.settings.update.gs') }}" method="post">
                            @csrf


                            <div class="primary_input mb-25">
                                <label class="primary_input_label" for="">{{ __('general.TimeZone') }}</label>
                                <select class="primary_select mb-25" name="time_zone_id" id="time_zone_id">
                                    @foreach ($timezones as $key => $timeZone)
                                        <option value="{{ $timeZone->id }}"
                                                @if ($gs->time_zone_id == $timeZone->id) selected @endif>{{ $timeZone->time_zone }}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="primary_input mb-25">
                                <label class="primary_input_label" for="">{{ __('general.site_title') }}</label>
                                <input class="primary_input_field" name="site_title" type="text" value="{{ $gs->site_title ?? '' }}">
                            </div>
                            <div class="primary_input mb-25">
                                <label class="primary_input_label" for="">{{ __('general.copy_right') }}</label>
                                <input class="primary_input_field" name="copyright_text" type="text" value="{{ $gs->copyright_text ?? '' }}">
                            </div>

                            <button class="primary-btn fix-gr-bg" type="submit">
                                <span class="ti-check"></span>
                                @lang('general.Update')
                            </button>
                        </form>

                    </div>
                </div>
            </div>

        </div>
    </section>
@endsection

@push('scripts')
    <script>
        (function($)
        {
            "use strict";
            $(document).ready(function(){
                "use strict";
                let position = '{{ app('whatsapp_support_settings')->icon_position }}';

                if(position === 'bottom_right'){
                    $('#margin_right').removeClass('d-none');
                }else{
                    $('#margin_left').removeClass('d-none');
                }
                $('#icon_position').on('change', function() {
                    "use strict";
                    let position = $(this).val();
                    if(position === 'bottom_right'){
                        $('#margin_right').removeClass('d-none');
                        $('#margin_left').addClass('d-none');
                    }else{
                        $('#margin_left').removeClass('d-none');
                        $('#margin_right').addClass('d-none');
                    }
                });
            });

        })(jQuery);
    </script>
@endpush
