@extends('whatsappsupport::layouts.master')

@section('content')
    <h1>{{ __('general.Confirmation') }}</h1>

    <p>
        {{ config('whatsappsupport.name') }}
    </p>
@endsection
