@if (permissionCheck('whatsapp-support.agents'))
    <li>
        <a href="javascript:;" class="has-arrow" aria-expanded="false">
            <div class="nav_icon_small">
                <i class="fab fa-whatsapp"></i>
            </div>
            <div class="nav_title">
                <span>{{ __('general.whatsapp_support') }}</span>
            </div>
        </a>
        <ul>
            @if (permissionCheck('whatsapp-support.settings'))
                <li>
                    <a href="{{ route('whatsapp-support.settings') }}">{{ __('general.settings') }}</a>
                </li>
            @endif

            @if (permissionCheck('whatsapp-support.agents'))
                <li>
                    <a href="{{ route('whatsapp-support.agents') }}">{{ __('general.agents') }}</a>
                </li>
            @endif

            @if (permissionCheck('whatsapp-support.analytics'))
                <li>
                    <a href="{{ route('whatsapp-support.analytics') }}">{{ __('general.analytics') }}</a>
                </li>
            @endif
        </ul>
    </li>
@endif
