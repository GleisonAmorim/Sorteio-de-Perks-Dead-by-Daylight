@extends('backend.master')
@section('mainContent')
    <section class="mb-40 up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row mb-5">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.total_click') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ $messages->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.click_from_mobile') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ $messages->where('device_type', 'Mobile')->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.click_from_desktop') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ $messages->where('device_type', 'Desktop')->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>

            </div>
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="box_header common_table_header">
                        <div class="main-title d-flex">
                            <h3 class="mb-0 mr-30" >{{ __('general.analytics') }}</h3>
                        </div>
                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="QA_section QA_section_heading_custom check_box_table">
                        <div class="QA_table ">
                            <div class="">
                                <table class="table Crm_table_active">
                                    <thead>
                                    <tr>
                                        <th scope="col">{{ __('general.id') }}</th>
                                        <th scope="col">{{ __('general.ip') }}</th>
                                        <th scope="col">{{ __('general.browser') }}</th>
                                        <th scope="col">{{ __('general.operating_system') }}</th>
                                        <th scope="col">{{ __('general.messages') }}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @forelse($messages as $index => $message)
                                        <tr>
                                            <th><a>{{ $index+1 }}</a></th>
                                            <td>{{ $message->ip }}</td>
                                            <td>{{ $message->browser }}</td>
                                            <td>{{ $message->os }}</td>
                                            <td>{{ $message->message }}</td>
                                        </tr>
                                    @empty
                                    @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
@endsection
