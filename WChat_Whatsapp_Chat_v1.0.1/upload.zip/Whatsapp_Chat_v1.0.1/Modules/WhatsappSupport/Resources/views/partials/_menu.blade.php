<li>
    <a href="javascript:;" class="has-arrow" aria-expanded="false">
        <div class="nav_icon_small">
            <span class="fa fa-whatsapp"></span>
        </div>
        <div class="nav_title">
            <span>{{ __('general.whatsapp_chat') }}</span>
        </div>
    </a>
    <ul>
        @if(auth()->check() && auth()->user()->role_id == 3)
            <li>
                <a href="{{ route('whatsapp-support.agents.show', auth()->id()) }}">{{ __('general.Timetable') }}</a>
            </li>
        @endif
        @if (permissionCheck('users.index'))
            <li>
                <a href="{{ route('users.index') }}">{{ __('general.users') }}</a>
            </li>
        @endif
        @if (permissionCheck('whatsapp-support.agents'))
            <li>
                <a href="{{ route('whatsapp-support.agents') }}">{{ __('general.agents') }}</a>
            </li>
        @endif
        @if (permissionCheck('whatsapp-support.analytics'))
            <li>
                <a href="{{ route('whatsapp-support.analytics') }}">{{ __('general.analytics') }}</a>
            </li>
        @endif


    </ul>
</li>

@if(permissionCheck('setting.updateSystem'))
<li>
    <a href="javascript:;" class="has-arrow" aria-expanded="false">
        <div class="nav_icon_small">
            <span class="fa fa-cog"></span>
        </div>
        <div class="nav_title">
            <span>{{ __('general.System Settings') }}</span>
        </div>
    </a>
    <ul>
        @if (permissionCheck('whatsapp-support.settings'))
            <li>
                <a href="{{ route('whatsapp-support.settings') }}">{{ __('general.general_settings') }}</a>
            </li>
        @endif
        @if (permissionCheck('languages.index'))
            <li>
                <a href="{{ route('languages.index') }}">{{ __('general.Language') }}</a>
            </li>
        @endif

        @if (permissionCheck('setting.updateSystem'))
            <li>
                <a href="{{ route('setting.updateSystem') }}">{{ __('general.update') }}</a>
            </li>
        @endif

        @if (permissionCheck('permission.roles.index'))
            <li>
                <a href="{{ route('permission.roles.index') }}">{{ __('general.Role') }} {{ __('general.permission') }}</a>
            </li>
        @endif

        @if (permissionCheck('timezone.index'))
            <li>
                <a href="{{ route('timezone.index') }}">{{ __('general.TimeZone') }}</a>
            </li>
        @endif

        @if (permissionCheck('setting.email_setup'))
            <li>
                <a href="{{ route('setting.email_setup') }}">{{ __('general.Email Setup') }}</a>
            </li>
        @endif
    </ul>
</li>
@endif
