@extends('backend.master')
@section('mainContent')
    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="">
                        <div class="row">
                            <div class="col-lg-12 mt-4">
                                <div class="white_box_30px">
                                    <div class="main-title mb-25">
                                        <h3 class="mb-3">{{ __('general.create_agent') }}</h3>
                                    </div>

                                    <form action="{{ route('whatsapp-support.agents.store') }}" method=POST enctype=multipart/form-data>
                                        @csrf
                                        <div class="row" id="pusher">

                                            <div class="col-xl-6 mt-4">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.name') }} *</label>
                                                    <input class="primary_input_field" name="name" type="text" required value="{{ old('name') }}">
                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.designation') }} *</label>
                                                    <input class="primary_input_field" name="designation" type="text" required value="{{ old('designation') }}">
                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.number') }} * (<small class="text-danger">{{ __('general.with_country_code') }}</small>)</label>
                                                    <input class="primary_input_field" name="number" type="text" required placeholder="{{ __('general.with_country_code') }}.." value="{{ old('number') }}">
                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('Email') }} * </label>
                                                    <input class="primary_input_field" name="email" type="text" required placeholder="" value="{{ old('email') }}">
                                                </div>
                                            </div>

                                            <div class="col-xl-12 mt-4">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.avatar') }} </label>

                                                    <div class="primary_file_uploader">
                                                        <input class="primary-input" type="text" id="php_file_input_ph" placeholder="{{ __('general.browse_avatar') }}" readonly="">
                                                        <button class="" type="button">
                                                            <label class="primary-btn small fix-gr-bg" for="php_file_input"><span class="ripple rippleEffect create_label"></span>{{ __('general.Browse') }}</label>
                                                            <input name="pic" type="file" class="d-none" id="php_file_input">
                                                        </button>
                                                    </div>

                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <p class="primary_input_label">{{ __('general.status') }} *</p>
                                                <div class="d-flex radio-btn-flex">
                                                    <div class="mr-20">
                                                        <input type="radio" checked name="status" required id="relationFather3" value="1" class="common-radio relationButton">
                                                        <label for="relationFather3">{{ __('general.active') }}</label>
                                                    </div>
                                                    <div class="mr-20">
                                                        <input type="radio" name="status" id="relationMother4" value="0" class="common-radio relationButton">
                                                        <label for="relationMother4">{{ __('general.inactive') }}</label>
                                                    </div>
                                                    @error('status') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <p class="primary_input_label">{{ __('general.always_available') }} *</p>
                                                <div class="d-flex radio-btn-flex">
                                                    <div class="mr-20">
                                                        <input type="radio" name="always_available" required id="relationFather33333" value="1" class="common-radio relationButton" {{ old('always_available') == '1'? 'checked' : '' }} {{ is_null(old('always_available')) ? 'checked' : '' }}>
                                                        <label for="relationFather33333">{{ __('general.yes') }}</label>
                                                    </div>
                                                    <div class="mr-20">
                                                        <input type="radio" name="always_available" id="relationMother4433" value="0" class="common-radio relationButton" {{ old('always_available') == '0'? 'checked' : '' }}>
                                                        <label for="relationMother4433">{{ __('general.no') }}</label>
                                                    </div>
                                                    @error('always_available') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                                </div>
                                            </div>

                                            <div class="col-xl-6 mt-4">
                                                <h4>Time : </h4>
                                                @foreach(\Carbon\Carbon::getDays() as $index => $day)
                                                    <div class="row no-gutters input-right-icon mt-25">
                                                    <div class="col-md-3">
                                                        <div class="input-effect">
                                                            <input type="checkbox" id="isBreak{{ $index }}" class="common-checkbox read-only-input" value="{{$day}}" name="day[]">
                                                            <label for="isBreak{{ $index }}">{{ $day }}</label>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="col">
                                                            <div class="input-effect">
                                                                <input id="agent_start{{$index}}" class="primary-input time form-control has-content" type="text" name="start[]">
                                                                <label>{{ __('general.start') }} {{ __('general.time') }}</label>
                                                                <span class="focus-border"></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-auto">
                                                            <button class="" type="button">
                                                                <i class="ti-timer"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        <div class="col">
                                                            <div class="input-effect">
                                                                <input id="agent_end{{$index}}" class="primary-input time form-control has-content" type="text" name="end[]">
                                                                <label>{{ __('general.end') }} {{ __('general.time') }}</label>
                                                                <span class="focus-border"></span>
                                                            </div>
                                                        </div>
                                                        <div class="col-auto">
                                                            <button class="" type="button">
                                                                <i class="ti-timer"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-3">
                                                        @if($index == 0)
                                                            <p onclick="setTimeToAll()" class="primary-btn radius_30px fix-gr-bg ml-3">{{ __('general.Apply All Days') }}</p>
                                                        @endif
                                                    </div>
                                                </div>
                                                @endforeach
                                            </div>
                                        </div>
                                        <button class="primary-btn radius_30px fix-gr-bg mt-4"><i class="ti-check"></i>{{ __('general.update') }}</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
