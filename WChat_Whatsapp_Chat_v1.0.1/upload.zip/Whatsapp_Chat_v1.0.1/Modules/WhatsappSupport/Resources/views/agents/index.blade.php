@extends('backend.master')
@section('mainContent')
    <section class="mb-40 up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="box_header common_table_header">
                        <div class="main-title d-flex">
                            <h3 class="mb-0 mr-30" >{{ __('general.agents') }}</h3>
                            <ul>
                                <li><a href="{{ route('whatsapp-support.agents.create') }}" class="primary-btn radius_30px fix-gr-bg text-white"><i class="ti-plus"></i> {{ __('general.add_agent') }}</a></li>
                            </ul>
                        </div>

                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="QA_section QA_section_heading_custom check_box_table">
                        <div class="QA_table ">
                            <div class="">
                                <table class="table Crm_table_active">
                                    <thead>
                                    <tr>
                                        <th scope="col">{{ __('general.id') }}</th>
                                        <th scope="col">{{ __('general.name') }}</th>
                                        <th scope="col">{{ __('general.number') }}</th>
                                        <th scope="col">{{ __('general.designation') }}</th>
                                        <th scope="col">{{ __('general.status') }}</th>
                                        <th scope="col">{{ __('general.action') }}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @forelse($agents as $index => $agent)
                                        <tr>
                                            <th><a>{{ $index+1 }}</a></th>
                                            <td><a href="">{{ $agent->name }}</a> </td>
                                            <td>{{ $agent->number }}</td>
                                            <td>{{ $agent->designation }}</td>
                                            <td>
                                                @if($agent->isAvailable())
                                                    <span class="badge badge-success">{{ __('general.Active') }}</span>
                                                @else
                                                    <span class="badge badge-danger">{{ __('general.In-active') }}</span>
                                                @endif
                                            </td>
                                            <td>
                                                <div class="dropdown CRM_dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        {{ __('general.select') }}
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
                                                        <a class="dropdown-item" href="{{ route('whatsapp-support.agents.show', $agent->id) }}" type="button">{{ __('general.edit') }}</a>
                                                        <a href="#" data-toggle="modal" data-target="#deleteAdmissionQueryModal{{$index}}" class="dropdown-item" type="button">{{ __('general.Delete') }}</a>

                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <div class="modal fade admin-query" id="deleteAdmissionQueryModal{{ $index }}">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Delete File</h4>
                                                        <button type="button" class="close text-black" data-dismiss="modal">&times;
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="text-center">
                                                            <h4>{{ __('general.Are you sure to delete') }}?</h4>
                                                            <h5 class="text-danger">( {{ __('general.Delete') }} {{ __('general.Confirmation') }} )</h5>
                                                        </div>
                                                        <div class="mt-40 d-flex justify-content-between">
                                                            <button type="button" class="primary-btn tr-bg" data-dismiss="modal">{{ __('general.cancel') }}</button>
                                                            <a href="{{ route('whatsapp-support.agents.delete', $agent->id) }}" class="primary-btn fix-gr-bg" type="submit">{{ __('general.Delete') }}</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    @empty
                                    @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
@endsection
