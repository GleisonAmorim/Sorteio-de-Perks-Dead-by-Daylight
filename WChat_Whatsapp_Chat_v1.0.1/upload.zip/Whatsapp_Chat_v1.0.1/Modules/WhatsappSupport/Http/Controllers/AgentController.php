<?php

namespace Modules\WhatsappSupport\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Modules\WhatsappSupport\Entities\Agents;
use Modules\WhatsappSupport\Http\Requests\AgentCreation;
use Modules\WhatsappSupport\Repositories\AgentRepository;
use Modules\WhatsappSupport\Traits\ImageStore;

class AgentController extends Controller
{
    public function index()
    {
        $agents = Agents::all();
        return view('whatsappsupport::agents.index', compact('agents'));
    }

    public function create()
    {
        return view('whatsappsupport::agents.create');
    }

    public function store(AgentCreation $request)
    {
        if($request->always_available == '0'){
            if (!$request->has('day')){
                session()->flash('error', 'Please select/check at least one working day!');
                return redirect()->back()->withInput();
            }
        }


        $imagepath = 'public/whatsapp-support/demo-avatar.jpg';
        if($request->hasFile('pic')){
            $imagepath = ImageStore::saveAvatarImage($request->pic);
        }
        $request['avatar'] = $imagepath;

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'avatar' => $imagepath,
            'role_id' => 3,
            'password' => bcrypt(12345678)
        ]);

        $request['user_id'] = $user->id;

        $agent = AgentRepository::store($request->except('_token', 'day', 'start','end','pic','email'));

        if($request->always_available == '0') {
            foreach ($request->day as $day) {
                $index = $this->getDayIndex($day);
                $agent->times()->updateOrCreate(
                    [
                        'agent_id' => $agent->id,
                        'day' => $day
                    ], [
                    'day' => $day,
                    'start' => Carbon::parse($request->start[$index])->format('H:i:s'),
                    'end' => Carbon::parse($request->end[$index])->format('H:i:s')
                ]);
            }
        }
        session()->flash('success', 'Agent added!');

        return redirect()->route('whatsapp-support.agents');

    }

    public function show($id)
    {
        if(auth()->user()->role_id == 3){
            $agent = Agents::find(auth()->user()->agent->id);

            if ($id !=auth()->id()){
                return redirect()->back();
            }
        }else{
            $agent = Agents::find($id);

        }

        return view('whatsappsupport::agents.show', compact('agent'));
    }

    public function edit($id)
    {
        return view('whatsappsupport::edit');
    }

    public function update(Request $request)
    {
        if(appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }

        $agent = Agents::find($request->agent_id);

        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users,email,' . $agent->user->id,
            'number' => 'required',
            'designation' => 'required',
            'status' => 'required',
            'always_available' => 'required',
        ]);
        if($request->always_available == '0'){
            if (!$request->has('day')){
                session()->flash('error', 'Please select/check at least one working day!');
                return redirect()->back();
            }
        }

        $agent->user->update([
            'email' => $request->email
        ]);

        $imagepath = $agent->avatar;
        if($request->hasFile('pic')){
            $imagepath = ImageStore::saveAvatarImage($request->pic);
        }
        $request['avatar'] = $imagepath;

        AgentRepository::update(
            $agent,
            $request->only('name','avatar','designation','number','always_available','status')
        );

        if($request->always_available == '0') {
            $agent->times()->delete();
            foreach ($request->day as $day){
                $index = $this->getDayIndex($day);
                $agent->times()->updateOrCreate(
                    [
                        'agent_id' => $agent->id,
                        'day' => $day
                    ], [
                    'day' => $day,
                    'start' => Carbon::parse($request->start[$index])->format('H:i:s'),
                    'end' => Carbon::parse($request->end[$index])->format('H:i:s')
                ]);
            }
        }

        session()->flash('success', 'Agent Updated');

        return redirect()->back();

    }

    public function destroy($id)
    {
        if(appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }

        $agent = Agents::find($id);
        $agent->times()->delete();
        $agent->delete();
        session()->flash('success','Agent Delete!');
        return redirect()->back();
    }

    public function getDayIndex($day)
    {
        switch ($day){
            case 'Sunday' :
                return 0;
            case 'Monday' :
                return 1;
            case 'Tuesday' :
                return 2;
            case 'Wednesday' :
                return 3;
            case 'Thursday' :
                return 4;
            case 'Friday' :
                return 5;
            case 'Saturday' :
                return 6;
        }
    }
}
