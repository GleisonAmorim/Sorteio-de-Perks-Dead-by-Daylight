<?php

namespace Modules\WhatsappSupport\Http\Controllers;

use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\WhatsappSupport\Entities\Message;
use Modules\WhatsappSupport\Entities\Settings;
use Modules\WhatsappSupport\Repositories\MessageRepository;

class MessageController extends Controller
{
    public function send(Request $request)
    {
        MessageRepository::store($request->all());

        $ws_setting = Settings::first();
        $to_number = $ws_setting->isMulti() ? $request->agent_number : $ws_setting->primary_number;

        return redirect()->to('https://api.whatsapp.com/send?phone='.$to_number.'&text='.$request->message);
    }

    public function analytics()
    {
        $messages = Message::all();
        return view('whatsappsupport::analytics', compact('messages'));
    }
}
