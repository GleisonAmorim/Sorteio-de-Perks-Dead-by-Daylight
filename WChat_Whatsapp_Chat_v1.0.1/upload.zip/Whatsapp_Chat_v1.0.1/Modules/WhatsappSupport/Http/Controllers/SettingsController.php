<?php

namespace Modules\WhatsappSupport\Http\Controllers;

use App\Models\User;
use GeoSot\EnvEditor\EnvEditor;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Mews\Purifier\Facades\Purifier;
use Modules\Setting\Model\GeneralSetting;
use Modules\Setting\Model\TimeZone;
use Modules\WhatsappSupport\Entities\Settings;
use Modules\WhatsappSupport\Traits\ImageStore;

class SettingsController extends Controller
{
    use ImageStore;
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index()
    {
        $timezones = TimeZone::all();
        $settings = Settings::first();
        $token = User::where('role_id', 1)->first()->ws_token;
        return view('whatsappsupport::settings.index', compact('settings','token','timezones'));
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        return view('whatsappsupport::create');
    }


    public function store(Request $request)
    {

    }


    public function show($id)
    {
        return view('whatsappsupport::show');
    }


    public function edit($id)
    {
        return view('whatsappsupport::edit');
    }


    public function update(Request $request)
    {
        if(appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }

        if ($request->hasFile('bubble_pic')){
            $request['bubble_logo'] = $this->saveAvatarImage($request->bubble_pic);
        }
        Settings::first()->update($request->except('_token','bubble_pic'));
        session()->flash('success', __('general.settings').' '.__('general.update').'!');
        return redirect()->back();
    }

    public function updateGs(Request $request)
    {
        try {
            if(appMode()){
                session()->flash('error','For the demo version, you cannot do this action.');
                return redirect()->back();
            }

            if ($request->has('logo_pic')){
                $logo = $this->saveImage($request->logo_pic);
                $request['logo'] = $logo;
            }

            if ($request->has('favicon_pic')){
                $fav = $this->saveImage($request->favicon_pic);
                $request['favicon'] = $fav;
            }

            $key1 = 'TIME_ZONE';

            if ($request->time_zone_id) {
                $time_zone = TimeZone::find($request->time_zone_id);
                $value1 = $time_zone->code ?? 83;
                if( (new EnvEditor())->keyExists($key1)){
                    (new EnvEditor())->editKey($key1, $value1);
                }else{
                    (new EnvEditor())->addKey($key1, $value1);

                }
            }


            $request->merge(['copyright_text' => Purifier::clean($request->get('copyright_text'))]);

            GeneralSetting::first()->update($request->except('_token', 'favicon_pic', 'logo_pic'));
            session()->flash('success', 'Settings Updated!');
            return redirect()->back();

        }catch (\Exception $e){
            session()->flash('error', $e->getMessage());
            return redirect()->back();
        }
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {

    }
}
