<?php

return [
    'name' => 'Localization'
];
