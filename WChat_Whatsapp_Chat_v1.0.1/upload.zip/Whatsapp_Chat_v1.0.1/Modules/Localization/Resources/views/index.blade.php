@extends('localization::layouts.master')

@section('content')
    <h1>{{ __('general.Profile Settings') }}</h1>

    <p>
        {{ config('localization.name') }}
    </p>
@endsection
