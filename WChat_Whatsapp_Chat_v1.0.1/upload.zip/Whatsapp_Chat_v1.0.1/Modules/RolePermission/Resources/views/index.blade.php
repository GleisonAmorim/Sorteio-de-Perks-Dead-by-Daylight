@extends('rolepermission::layouts.master')

@section('content')
    <h1>{{ __('general.Profile Settings') }}</h1>

    <p>
         {{ config('rolepermission.name') }}
    </p>
@endsection
