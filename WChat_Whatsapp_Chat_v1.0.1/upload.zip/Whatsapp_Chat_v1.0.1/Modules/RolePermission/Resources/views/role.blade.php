@extends('backend.master')
@section('mainContent')
    <section class="sms-breadcrumb mb-40 white-box">
        <div class="container-fluid">
            <div class="row justify-content-between">
                <h1>{{__('general.role')}} {{__('general.permission')}}</h1>
            </div>
        </div>
    </section>

    <section class="admin-visitor-area up_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row">
                <div class="col-lg-12">

                    <div class="row">
                        @if(permissionCheck('permission.roles.store'))
                            <div class="col-lg-4">
                                <div class="main-title mb-4 mt-2">
                                    <h3 class="mb-0">{{__('general.Add')}} {{__('general.role')}}</h3>
                                </div>
                                <form method="POST" action="{{ route('permission.roles.store') }}" accept-charset="UTF-8" class="form-horizontal" enctype="multipart/form-data"><input name="_token" type="hidden" value="J967XvjhEew51m7PlIft0Xjx9jtV9HQZeWx2yvp4">
                                    <div class="white-box">
                                        @csrf
                                        <div class="add-visitor">
                                            <div class="row">
                                                <div class="col-lg-12">
                                                    <div class="input-effect">
                                                        <input class="primary-input form-control" type="text" name="name" autocomplete="off" value="">
                                                        <label>{{ __('general.name') }} <span>*</span></label>
                                                        <span class="focus-border"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-40">
                                                <div class="col-lg-12 text-center">
                                                    <button class="primary-btn fix-gr-bg" data-toggle="tooltip" title="" data-original-title="">
                                                        <span class="ti-check"></span>
                                                        {{ __('general.Save') }}
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        @endif
                        <div class="{{ permissionCheck('permission.roles.store') ? 'col-lg-8' : 'col-lg-12' }} ">
                            <div class="main-title my-2">
                                <h3 class="mb-0">{{__('general.role')}} {{__('general.List')}}</h3>
                            </div>
                            <div class="QA_section QA_section_heading_custom check_box_table">
                                <div class="QA_table ">
                                    <div class="mt-30">
                                        <table class="table Crm_table_active">
                                            <thead>
                                            <tr>
                                                <th width="30%">{{__('general.role')}}</th>
                                                <th width="30%">{{__('general.Type')}}</th>
                                                <th width="40%">{{__('general.Action')}}</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($RoleList as $role)
                                                <tr>
                                                    <td>{{@$role->name}}</td>
                                                    <td>{{@$role->type}}</td>
                                                    <td>
                                                        @if (permissionCheck('permission.permissions.store'))
                                                            <a href="{{ route('permission.permissions.index', [ 'id' => @$role->id])}}" class="">
                                                                <button type="button" class="primary-btn small fix-gr-bg"> {{__('general.assign_permission')}} </button>
                                                            </a>
                                                        @endif
                                                        @if(@$role->type == 'User Defined')
                                                                @if(permissionCheck('permission.roles.edit'))
                                                                    <a class="m-1 text-white primary-btn small fix-gr-bg" data-toggle="modal" data-id="{{@$role->id}}" data-target="#editItem_{{$role->id}}">{{__('general.Edit')}}</a>
                                                                @endif

                                                                @if(permissionCheck('permission.roles.destroy'))
                                                                    <a class="m-1 text-white primary-btn small fix-gr-bg" data-toggle="modal"  data-id="{{@$role->id}}" data-target="#deleteItem_{{$role->id}}">{{__('general.Delete')}}</a>
                                                                @endif
                                                        @endif
                                                    </td>
                                                    @include('backend.partials.deleteModalMessage',[
                                                        'item_id' => @$role->id,
                                                        'item_name' => 'Role',
                                                        'route_url' => route('permission.roles.destroy',$role->id)])

                                                    @include('backend.partials.editModalMessage',[
                                                        'id' => @$role->id,
                                                        'name' => $role->name,
                                                        'route_url' => route('permission.roles.update',$role->id)])
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
