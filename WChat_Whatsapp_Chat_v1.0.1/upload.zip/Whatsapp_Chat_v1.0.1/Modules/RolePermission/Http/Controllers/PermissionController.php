<?php

namespace Modules\RolePermission\Http\Controllers;

use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\RolePermission\Entities\Permission;
use Modules\RolePermission\Entities\Role;

class PermissionController extends Controller
{
    public function __construct()
    {
    }


    public function index(Request $request)
    {
        $role_id = $request['id'];
        if ($role_id == null || $role_id == 1) {
            return redirect(route('permission.roles.index'));
        }
        $PermissionList = Permission::where('status', 1)->get();
        $role = Role::with('permissions')->find($role_id);
        $data['role'] = $role;
        $data['MainMenuList'] = $PermissionList->where('type', 1);
        $data['SubMenuList'] = $PermissionList->where('type', 2);
        $data['ActionList'] = $PermissionList->where('type', 3);
        $data['PermissionList'] = $PermissionList;
        return view('rolepermission::permission', $data);
    }

    public function store(Request $request)
    {
        if(auth()->user()->isAdmin() && appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }

        $validator = Validator::make($request->all(), [
            'role_id' => "required",
            'module_id' => "required|array"
        ]);

        if ($validator->fails()) {
            session()->flash('error','Please Select Minimum one Permission');
            return redirect()->back();
        }

        try {
            DB::beginTransaction();
            $role = Role::findOrFail($request->role_id);
            $role->permissions()->detach();
            $role->permissions()->attach(array_unique($request->module_id));
            DB::commit();
            session()->flash('success','Operation successful');
            return redirect()->back();
        } catch (\Exception $e) {
            DB::rollback();
            session()->flash('error','Operation failed!');
            return redirect()->back();
        }
    }
}
