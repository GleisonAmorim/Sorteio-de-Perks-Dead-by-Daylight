<?php

return [
    'name' => 'RolePermission'
];
