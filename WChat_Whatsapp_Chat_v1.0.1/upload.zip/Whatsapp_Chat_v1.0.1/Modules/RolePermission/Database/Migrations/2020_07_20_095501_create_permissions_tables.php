<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

class CreatePermissionsTables extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('module_id')->nullable();
            $table->integer('parent_id')->nullable();
            $table->string('name')->nullable();
            $table->string('route')->nullable();
            $table->tinyInteger('status')->default(1);
            $table->integer('created_by')->default(1)->unsigned();
            $table->integer('updated_by')->default(1)->unsigned();
            $table->integer('type')->nullable()->comment('1 for main menu, 2 for sub menu , 3 action');
            $table->timestamps();
        });

        $sql = [
            ['id' => 1, 'module_id' => 1, 'parent_id' => null, 'name' => 'Whatsapp Settings', 'route' => 'whatsapp-support.settings', 'type' => 1],
            ['id' => 2, 'module_id' => 1, 'parent_id' => 1, 'name' => 'Agents', 'route' => 'whatsapp-support.agents', 'type' => 2],
            ['id' => 3, 'module_id' => 1, 'parent_id' => 3, 'name' => 'all agents', 'route' => 'whatsapp-support.agents', 'type' => 3],
            ['id' => 4, 'module_id' => 1, 'parent_id' => 3, 'name' => 'agent edit', 'route' => 'whatsapp-support.agents.show', 'type' => 3],
            ['id' => 5, 'module_id' => 1, 'parent_id' => 1, 'name' => 'Analytics', 'route' => 'whatsapp-support.analytics', 'type' => 2],
            ['id' => 6, 'module_id' => 1, 'parent_id' => 1, 'name' => 'Users', 'route' => 'users.index', 'type' => 2],
            ['id' => 7, 'module_id' => 1, 'parent_id' => 6, 'name' => 'Create', 'route' => 'users.create', 'type' => 3],

            ['id' => 8, 'module_id' => 2, 'parent_id' => null, 'name' => 'System Settings', 'route' => 'setting.updateSystem', 'type' => 1],
            ['id' => 9, 'module_id' => 2, 'parent_id' => 8, 'name' => 'Language', 'route' => 'languages.index', 'type' => 2],
            ['id' => 10, 'module_id' => 2, 'parent_id' => 8, 'name' => 'General Settings', 'route' => 'whatsapp-support.settings', 'type' => 2],
            ['id' => 11, 'module_id' => 2, 'parent_id' => 8, 'name' => 'Role Permission', 'route' => 'permission.roles.index', 'type' => 2],
            ['id' => 12, 'module_id' => 2, 'parent_id' => 11, 'name' => 'Create Role', 'route' => 'permission.roles.store', 'type' => 3],
            ['id' => 13, 'module_id' => 2, 'parent_id' => 11, 'name' => 'Edit Role', 'route' => 'permission.roles.edit', 'type' => 3],
            ['id' => 14, 'module_id' => 2, 'parent_id' => 11, 'name' => 'Delete Role', 'route' => 'permission.roles.destroy', 'type' => 3],
            ['id' => 15, 'module_id' => 2, 'parent_id' => 8, 'name' => 'Update', 'route' => 'setting.updateSystem', 'type' => 2],
            ['id' => 16, 'module_id' => 2, 'parent_id' => 8, 'name' => 'Timezone', 'route' => 'timezone.index', 'type' => 2],
            ['id' => 17, 'module_id' => 2, 'parent_id' => 8, 'name' => 'Email Setup', 'route' => 'setting.email_setup', 'type' => 2],

        ];


        DB::table('permissions')->insert($sql);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('permissions');
    }
}
