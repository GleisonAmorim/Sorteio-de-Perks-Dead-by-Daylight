@extends('backend.master')
@section('mainContent')
    <section class="sms-breadcrumb mb-40 white-box">
        <div class="container-fluid">
            <div class="row justify-content-between">
                <h1>{{__('general.Email Configuration')}}</h1>
            </div>
        </div>
    </section>
    <section class="admin-visitor-area student-details">
        <div class="container-fluid p-0">
            <div class="row">

                <div class="row pt-20">
                    <ul class="nav nav-tabs no-bottom-border  mt-sm-md-20 mb-10" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link active"  href="#indivitual_email_sms" role="tab"
                               data-toggle="tab">{{__('general.SMTP')}}</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link " href="#group_email_sms"   role="tab"
                               data-toggle="tab">{{__('general.Php Mail')}}  </a>
                        </li>
                    </ul>
                </div>

                <div class="col-md-12 ">
                    <div class="white_box_30px">
                        <div class="row  mt_0_sm">

                            <div class="col-lg-12">
                                <div class="tab-content">
                                    <input type="hidden" name="selectTab" id="selectTab">
                                    <div role="tabpanel" class="tab-pane fade show active" id="indivitual_email_sms">
                                        @include('setting::page_components.smtp_mail_setup')
                                    </div>

                                    <div role="tabpanel" class="tab-pane fade " id="group_email_sms">

                                        @include('setting::page_components.send_mail_setup')

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="admin-visitor-area">
        <div class="container-fluid p-0">
            <div class="row">

                <div class="col-md-12 ">
                    <div class="white_box_30px">
                        <div class="row  mt_0_sm">

                            <div class="col-lg-12">
                                    <form class="" action="{{ route('setting.email_test') }}" method="post">
                                        @csrf
                                        <div class="row">
                                            <div class="col-xl-6">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label"
                                                           for="">{{ __('general.To Mail') }}*</label>
                                                    <input class="primary_input_field"
                                                           {{ $errors->has('mail_address') ? ' autofocus' : '' }} placeholder=""
                                                           type="email" required
                                                           name="mail_address" value="{{old('mail_address')}}">
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <div class="primary_input">
                                                    <label class="primary_input_label"
                                                           for="">{{ __('general.Email Text') }}</label>
                                                    <input class="primary_input_field"
                                                           {{ $errors->has('mail_text') ? ' autofocus' : '' }} placeholder=""
                                                           type="text" required
                                                           name="mail_text" value="{{old('mail_text')}}">
                                                </div>
                                            </div>
                                            <div class="col-xl-6">
                                                <button class="primary-btn fix-gr-bg" data-toggle="tooltip"
                                                        type="submit">{{ __('general.Send Test Mail') }}</button>
                                            </div>
                                        </div>

                                    </form>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </section>

@endsection
@push('scripts')

@endpush
