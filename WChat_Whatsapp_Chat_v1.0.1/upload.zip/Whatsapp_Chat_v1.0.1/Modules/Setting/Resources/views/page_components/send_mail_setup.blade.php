    <form action="{{ route('setting.email_setup_post') }}" method="post">
        @csrf
        <input type="hidden" name="id" value="1" id="">
        <div class="row">
            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.From Name') }}*</label>
                    <input class="primary_input_field"
                           {{ $errors->has('from_name') ? ' autofocus' : '' }} placeholder="" type="text"
                           name="mail_from_name" value="{{ env('MAIL_FROM_NAME') }}">
                </div>
            </div>
            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.From Mail') }}*</label>
                    <input class="primary_input_field"
                           {{ $errors->has('from_email') ? ' autofocus' : '' }} placeholder="" type="text"
                           name="mail_from_address" value="{{ env('MAIL_FROM_ADDRESS') }}">
                </div>
            </div>
        </div>
        <div class="row" id="smtp">
            <div class="col-xl-6">
                <div class="primary_input">
                    <label class="primary_input_label"
                           for="">{{ __('general.active') }} {{ __('general.status') }}</label>
                    <select name="mail_mailer" class="primary_select mb-25">
                        <option value="sendmail"
                                @if (env('MAIL_MAILER')=='sendmail') selected @endif>{{ __('general.Active') }}</option>
                        <option value="smtp"
                                @if (env('MAIL_MAILER')=='smtp') selected @endif>{{ __('general.Deactive') }}</option>
                    </select>
                </div>
            </div>

            <div class="col-12 mb-45 pt_15">
                <div class="submit_btn text-center">
                    <button class="primary_btn_large" data-toggle="tooltip" type="submit"><i
                            class="ti-check"></i> {{ __('general.Update') }}</button>
                </div>
            </div>
        </div>
    </form>

