
    <form action="{{ route('setting.email_setup_post') }}" method="post">
        @csrf
        <div class="row">
            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.From Name') }}*</label>
                    <input class="primary_input_field"
                           {{ $errors->has('from_name') ? ' autofocus' : '' }} placeholder="" type="text"
                           name="mail_from_name" value="{{ env('MAIL_FROM_NAME') }}" required>
                </div>
            </div>
            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.From Mail') }}*</label>
                    <input class="primary_input_field"
                           {{ $errors->has('from_email') ? ' autofocus' : '' }} placeholder="" type="email"
                           name="mail_from_address" value="{{ env('MAIL_FROM_ADDRESS') }}" required>
                </div>
            </div>
        </div>
        <div class="row" id="smtp">
            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.Mail Driver') }}*</label>
                    <input class="primary_input_field"
                           {{ $errors->has('mail_driver') ? ' autofocus' : '' }} placeholder="" type="text"
                           name="mail_mailer" value="{{ env('MAIL_MAILER') }}" required>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.Mail Host') }}*</label>
                    <input class="primary_input_field" placeholder="-" type="text" name="mail_host"
                           value="{{ env('MAIL_HOST') }}" required>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.Mail Port') }}*</label>
                    <input class="primary_input_field"
                           {{ $errors->has('mail_port') ? ' autofocus' : '' }} placeholder="" type="text"
                           name="mail_port" value="{{ env('MAIL_PORT') }}" required>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.Mail Username') }}*</label>
                    <input class="primary_input_field" placeholder="-" type="text" name="mail_username"
                           value="{{ env('MAIL_USERNAME') }}" required>
                </div>
            </div>


            <div class="col-xl-6">
                <div class="primary_input mb-25">
                    <label class="primary_input_label" for="">{{ __('general.Mail Password') }}*</label>
                    <input class="primary_input_field" placeholder="-" type="password" name="mail_password"
                           value="{{ env('MAIL_PASSWORD') }}" required>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="primary_input">
                    <label class="primary_input_label" for="">{{ __('general.Mail Encryption') }}*</label>
                    <select name="mail_encryption" class="primary_select mb-25" required>
                        <option value="ssl" @if (env('MAIL_ENCRYPTION') == "ssl") selected @endif>SSL
                        </option>
                        <option value="tls" @if (env('MAIL_ENCRYPTION')== "tls") selected @endif>TLS
                        </option>
                    </select>
                </div>
            </div>

        </div>

        <div class="row">
            <div class="col-xl-6">
                <div class="primary_input">
                    <label class="primary_input_label"
                           for="">{{ __('general.active') }} {{ __('general.status') }}</label>
                    <select name="mail_mailer" class="primary_select mb-25">
                        <option value="smtp"
                                @if (env('MAIL_MAILER')=='smtp') selected @endif>{{ __('general.Active') }}</option>
                        <option value="sendmail"
                                @if (env('MAIL_MAILER')=='sendmail') selected @endif>{{ __('general.Deactive') }}</option>
                    </select>
                </div>
            </div>
            <div class="col-12 mb-45 pt_15">
                <div class="submit_btn text-center">
                    <button class="primary_btn_large" data-toggle="tooltip" title="" type="submit"><i
                            class="ti-check"></i> {{ __('general.Update') }}</button>
                </div>
            </div>
        </div>
    </form>

