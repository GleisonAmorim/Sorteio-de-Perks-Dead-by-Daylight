@include('backend.partials.header')

@yield('mainContent')

@yield('script')

@include('backend.partials.footer')
