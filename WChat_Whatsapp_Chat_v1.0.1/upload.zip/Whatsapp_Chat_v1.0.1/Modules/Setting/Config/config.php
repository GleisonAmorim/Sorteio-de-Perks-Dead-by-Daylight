<?php

return [
    'name' => 'Setting'
];
