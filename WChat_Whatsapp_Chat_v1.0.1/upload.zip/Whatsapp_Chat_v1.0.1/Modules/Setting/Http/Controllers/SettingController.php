<?php

namespace Modules\Setting\Http\Controllers;

use App\Country;
use App\Traits\ImageStore;
use Brian2694\Toastr\Facades\Toastr;
use GeoSot\EnvEditor\EnvEditor;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Mail;
use Modules\FrontendManage\Entities\HomeContent;
use Modules\Localization\Entities\Language;
use Modules\Setting\Model\BusinessSetting;
use Modules\Setting\Model\Currency;
use Modules\Setting\Model\DateFormat;
use Modules\Setting\Model\GeneralSetting;
use Modules\Setting\Model\TimeZone;
use Modules\SystemSetting\Entities\EmailSetting;

class SettingController extends Controller
{
    public function activation()
    {
        $business_settings = BusinessSetting::all();
        $setting = GeneralSetting::first();
        return view('setting::activation', compact('business_settings', 'setting'));
    }


    public function general_settings()
    {
        $business_settings = BusinessSetting::all();
        $setting = GeneralSetting::first();
        $date_formats = DateFormat::all();
        $languages = Language::where('status', 1)->get();
        $countries = Country::where('active_status', 1)->get();
        $currencies = Currency::where('status', 1)->get();
        $timeZones = TimeZone::all();
        return view('setting::general_settings', compact('timeZones', 'currencies', 'countries', 'languages', 'business_settings', 'setting', 'date_formats'));
    }

    public function email_setup()
    {
        return view('setting::email_setup2');
    }

    public function email_setup_post(Request $request)
    {
        if(appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }

        try {
            foreach ($request->except('_token') as $key => $value){
                if( (new EnvEditor())->keyExists(strtoupper($key))){
                    (new EnvEditor())->editKey(strtoupper($key), str_replace(' ', '_', $value));
                }else{
                    (new EnvEditor())->addKey(strtoupper($key), str_replace(' ', '_', $value));
                }
            }
            session()->flash('success', 'Mail Configuration Updated!');
            return redirect()->back();

        }catch (\Exception $e){
            \Log::info($e->getMessage());
            session()->flash('error', 'Oops! Something went wrong!');
            return redirect()->back();
        }
    }

    public function email_test(Request $request)
    {
        try {
            Mail::raw($request->mail_text, function ($message) use($request){
                $message->to($request->mail_address)
                    ->subject("This is test mail");
                });

            session()->flash('success', 'Test mail successfully send!');
            return redirect()->back();
        }catch (\Exception $exception){
            session()->flash('error', 'Oops! something went wrong!');
            return redirect()->back();
        }
    }

    public function seo_setting()
    {
        $business_settings = BusinessSetting::all();
        $setting = GeneralSetting::first();
        return view('setting::seo_setting', compact('business_settings', 'setting'));
    }

    /**
     * Show the form for creating a new resource.
     * @return \Illuminate\Http\RedirectResponse
     */

    public function index()
    {
        return redirect()->route('home');
    }

    public function create()
    {
        return view('setting::create');
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('setting::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        return view('setting::edit');
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
    }

    public function update_activation_status(Request $request)
    {
        $business_setting = BusinessSetting::findOrFail($request->id);
        if ($business_setting != null) {
            $business_setting->status = $request->status;
            $business_setting->save();
            return 1;
        }
        return 0;
    }

    public function maintenance()
    {
        $setting = HomeContent::first();
        return view('setting::maintenance', compact('setting'));
    }

    public function maintenanceAction(Request $request)
    {

        try {


            $content = HomeContent::first();
            if ($request->maintenance_banner != null) {

                if ($request->file('maintenance_banner')->extension() == "svg") {
                    $file = $request->file('maintenance_banner');
                    $fileName = md5(rand(0, 9999) . '_' . time()) . '.' . $file->clientExtension();
                    $url1 = 'public/uploads/settings/' . $fileName;
                    $file->move(public_path('uploads/settings'), $fileName);
                } else {
                    $url1 = $this->saveImage($request->maintenance_banner);
                }
                $content->maintenance_banner = $url1;
            }

            $content->maintenance_title = $request->maintenance_title;
            $content->maintenance_sub_title = $request->maintenance_sub_title;
            $content->maintenance_status = $request->maintenance_status;
            $content->save();
            Toastr::success(trans('common.Operation successful'), trans('common.Success'));
            return redirect()->back();
        } catch (\Exception $e) {
            Toastr::error(trans('common.Operation failed'), trans('common.Failed'));
            return redirect()->back();
        }
    }

}
