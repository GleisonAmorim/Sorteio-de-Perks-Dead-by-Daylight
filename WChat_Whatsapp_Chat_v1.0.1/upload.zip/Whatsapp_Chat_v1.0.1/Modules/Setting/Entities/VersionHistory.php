<?php

namespace Modules\Setting\Entities;

use Illuminate\Database\Eloquent\Model;

class VersionHistory extends Model
{
    protected $fillable = [];
}
