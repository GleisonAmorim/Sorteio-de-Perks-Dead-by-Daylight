<?php

use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\UserController;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Modules\WhatsappSupport\Entities\Message;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    $messages = Message::all();
    return view('welcome', compact('messages'));
})->middleware('auth');

Auth::routes(['register' => false]);

Route::get('/home', function (){
    $messages = Message::all();
    return view('welcome', compact('messages'));
})->name('home');

Route::get('auto-login/{key}', function ($key){
    if (appMode()){
        if ($key == 'admin'){
            $user = User::where('role_id', 1)->first();
        }elseif($key == 'user'){
            $user = User::where('role_id', 2)->first();
        }else{
            $user = User::where('role_id', 3)->first();
        }
        Auth::loginUsingId($user->id);
        return redirect()->to('/');
    }else{
        return redirect()->back();
    }

})->name('auto.login');



Route::get('/profile', [ProfileController::class,'index'])->name('profile');
Route::post('/profile/update', [ProfileController::class,'update'])->name('profile.update');
Route::post('/profile/update/password', [ProfileController::class,'password'])->name('profile.update.password');
Route::post('home/language/change', [HomeController::class,'languageChange'])->name('language.change.home');

Route::group(['prefix' => 'users'], function(){
    Route::get('/', [UserController::class, 'index'])->name('users.index')->middleware('RoutePermissionCheck:users.index');
    Route::get('create', [UserController::class, 'create'])->name('users.create')->middleware('RoutePermissionCheck:users.create');
    Route::post('store', [UserController::class, 'store'])->name('users.store')->middleware('RoutePermissionCheck:users.store');
    Route::post('update/{id}', [UserController::class, 'update'])->name('users.update')->middleware('RoutePermissionCheck:users.update');
    Route::get('show/{id}', [UserController::class, 'show'])->name('users.show')->middleware('RoutePermissionCheck:users.show');
    Route::get('delete/{id}', [UserController::class, 'destroy'])->name('users.delete')->middleware('RoutePermissionCheck:users.delete');
});


Route::get('logout', [LoginController::class,'logout']);
