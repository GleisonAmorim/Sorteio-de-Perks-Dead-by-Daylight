require('./bootstrap');

window.Vue = require('vue').default;

import JQuery from 'jquery'
window.$$ = JQuery

import browserDetect from "vue-browser-detect-plugin";
Vue.use(browserDetect);


Vue.component('whatsapp-support', require('./components/WhatsappSupport.vue').default);

const app = new Vue({
    el: '#whatsapp_support_service',
});
