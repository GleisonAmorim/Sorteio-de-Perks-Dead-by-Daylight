<template>
    <div>
        <div v-if="this.valid && deviceAvailablity()">
            <div @click="whatsappIconClick()"
                 :class="{ 'whatsApp_icon_left' : positionIsLeft, 'whatsApp_icon' : positionIsRight}"
                 :style="[{ 'background-color': initialColor}, positionIsLeft ? {left:settings.left+'px'} : {right:settings.right+'px'}, {bottom:settings.bottom+'px'}]"
            >
                <svg viewBox="0 0 32 32" class="whatsapp-ico"><path d=" M19.11 17.205c-.372 0-1.088 1.39-1.518 1.39a.63.63 0 0 1-.315-.1c-.802-.402-1.504-.817-2.163-1.447-.545-.516-1.146-1.29-1.46-1.963a.426.426 0 0 1-.073-.215c0-.33.99-.945.99-1.49 0-.143-.73-2.09-.832-2.335-.143-.372-.214-.487-.6-.487-.187 0-.36-.043-.53-.043-.302 0-.53.115-.746.315-.688.645-1.032 1.318-1.06 2.264v.114c-.015.99.472 1.977 1.017 2.78 1.23 1.82 2.506 3.41 4.554 4.34.616.287 2.035.888 2.722.888.817 0 2.15-.515 2.478-1.318.13-.33.244-.73.244-1.088 0-.058 0-.144-.03-.215-.1-.172-2.434-1.39-2.678-1.39zm-2.908 7.593c-1.747 0-3.48-.53-4.942-1.49L7.793 24.41l1.132-3.337a8.955 8.955 0 0 1-1.72-5.272c0-4.955 4.04-8.995 8.997-8.995S25.2 10.845 25.2 15.8c0 4.958-4.04 8.998-8.998 8.998zm0-19.798c-5.96 0-10.8 4.842-10.8 10.8 0 1.964.53 3.898 1.546 5.574L5 27.176l5.974-1.92a10.807 10.807 0 0 0 16.03-9.455c0-5.958-4.842-10.8-10.802-10.8z" fill-rule="evenodd"></path></svg>
            </div>

            <div class="whats_app_popup"
                 :class="{ active: initialOpen, ' whatsApp_popup_position' : positionIsRight, ' whatsApp_popup_position_left' : positionIsLeft}"
                 :style="[positionIsLeft ? {left:settings.left+'px'} : {right:settings.right+'px'}, {bottom:+settings.bottom + +90+'px'}]"
                 id="whatsapp_support_container"
            >
                <span @click="whatsappPopupCloseClick($event)" class="whats_app_popup_close" :style="{ 'background-color': initialColor}">
                    <svg class="close-ico" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18"><path d="M14.53 4.53l-1.06-1.06L9 7.94 4.53 3.47 3.47 4.53 7.94 9l-4.47 4.47 1.06 1.06L9 10.06l4.47 4.47 1.06-1.06L10.06 9z"/></svg>
                </span>
                <div class="whats_app_popup_body">
                    <div v-if="settings.layout == 2" class="whats_app_popup_thumb">
                        <img :src="server_base_url + '/'+settings.bubble_logo" alt="">
                    </div>
                    <div class="whats_app_popup_msgs">
                        <div class="whats_app_popup_head" :style="{ 'background-color': initialColor}">
                            <div class="whats_app_popup_thumb mbottom_15">
                                <div v-if="settings.layout == 1" class="whats_app_popup_thumb">
                                    <img :src="server_base_url +  '/' +settings.bubble_logo " alt="">
                                </div>
                            </div>
                            <p>{{ settings.intro_text }}</p>
                        </div>
                        <div class="whats_app_popup_text">
                            <img :src="server_base_url + '/public/whatsapp-support/hand.svg'" alt="">
                            <p> {{ settings.welcome_message }}</p>
                        </div>

                        <div v-if="settings.agent_type == 'multi'" class="whats_app_members">
                            <div v-for="agent in whatsapp_support_agents">
                                <form v-if="agentShowingCondition(agent)" :action="message_send_action+'&agent_number='+agent.number" method="post">
                                    <div class="single_group_member">
                                        <div class="single_group_member_inner" @click="singleGroupMemberInner($event)">
                                            <div class="thumb">
                                                <img v-if="agent.avatar" :src="server_base_url+'/'+ agent.avatar" alt="">
                                                <img v-else :src="server_base_url+ '/public/whatsapp-support/demo-avatar.jpg'" alt="">

                                                <span v-if="agent.available" class="active_badge"></span>
                                                <span v-else class="inactive_badge"></span>

                                            </div>
                                            <div class="group_member_meta">
                                                <h4 class="name_font">{{ agent.name }}</h4>
                                                <span class="whatsap_padding_bottom designation_color">{{ agent.designation }}</span>

                                                <p v-if="agent.available">Available</p>
                                                <p v-else>Unavailable</p>
                                            </div>
                                        </div>
                                        <div class="whats_app_popup_input">
                                            <div class="input-group primary_input_coupon">
                                                <input type="text" name="message" class="primary_input_field" placeholder="Type message..." aria-label="Recipient's username" aria-describedby="basic-addon2">
                                                <div class="input-group-append">
                                                    <button class="btn" type="submit">
                                                        <svg class="wws-popup__send-btn" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
                                                            <path :fill="initialColor+80" id="path0_fill" class="wws-lau00001" d="M38.9,19.8H7.5L2,39L38.9,19.8z"></path>
                                                            <path :fill="initialColor" id="path0_fill_1_" class="wws-lau00002" d="M38.9,19.8H7.5L2,0.7L38.9,19.8z"></path>
                                                        </svg>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <form v-if="settings.agent_type == 'single'" :action="message_send_action" method="post">
                    <div class="whats_app_popup_input">
                        <div class="input-group primary_input_coupon">
                            <input type="text" name="message" class="primary_input_field" placeholder="Type message...">
                            <div class="input-group-append">
                                <button class="btn " type="submit">
                                    <svg class="wws-popup__send-btn" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 40 40" style="enable-background:new 0 0 40 40;" xml:space="preserve">
                                        <path :fill="initialColor+80" id="path0_fill" class="wws-lau00001" d="M38.9,19.8H7.5L2,39L38.9,19.8z"></path>
                                        <path :fill="initialColor" id="path0_fill_1_" class="wws-lau00002" d="M38.9,19.8H7.5L2,0.7L38.9,19.8z"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: "WhatsappSupport",
    props : {
        server_base_url : {
            required : true,
        },
        token : {
            required : true,
        }
    },
    data() {
        return {
            valid : false,
            settings : {},
            device_type:'',
            initialOpen : false,
            positionIsLeft : false,
            positionIsRight : true,
            message_send_action : '',
            initialColor : '#0dc152',
            initial_open_popup : false,
            whatsapp_support_agents : {},
        }
    },
    mounted() {
        fetch('https://api.ipify.org?format=json')
            .then(x => x.json())
            .then(({ ip }) => {
                this.device_type = this.isMobile() ? 'Mobile' : 'Desktop';
                this.message_send_action = this.server_base_url+'api/ws/message/send?os='+navigator.platform+'&browser='+this.$browserDetect.meta.name+'&ip='+ip+'&device_type='+this.device_type
            });
        axios.post(this.server_base_url+ 'api/ws/initials', {
            ws_token: this.token,
        }).then((response) => {
            this.valid = response.data.valid;
            if(this.valid){
                this.settings = response.data.setting;
                if(this.settings.open_popup) this.initialOpen = true;

                if(this.settings.icon_position === 'bottom_left'){
                    this.positionIsRight = false;
                    this.positionIsLeft = true;
                }
                this.whatsapp_support_agents = response.data.agents;
                this.initialColor = response.data.setting.color;
            }
        })
    },

    methods : {
        whatsappIconClick(){
            if(this.positionIsRight){
                $$('.whatsApp_popup_position').toggleClass('active');
            }else{
                $$('.whatsApp_popup_position_left').toggleClass('active');
            }
        },

        whatsappPopupCloseClick(){
            $$('#whatsapp_support_container').removeClass('active');
        },

        singleGroupMemberInner(event){
            event.preventDefault();
            $$('.single_group_member').each(function(i,e){
                $$(e).removeClass('active').children('.whats_app_popup_input').slideUp();
            });
            $$(event.target).closest('.single_group_member').addClass('active').children('.whats_app_popup_input').slideDown();
        },


        deviceAvailablity(){
            return (this.settings.availability == 'mobile' && this.isMobile()) || (this.settings.availability == 'desktop' && !this.isMobile) || this.settings.availability == 'both'
        },

        agentShowingCondition(agent){
           return agent.always_available || (!agent.always_available && this.settings.show_unavailable_agent)
        },

        isMobile(){
            if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|ipad|iris|kindle|Android|Silk|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(navigator.userAgent)
                || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(navigator.userAgent.substr(0,4))) {
                return true;
            }
            return false;
        },
    },
}
</script>

<style scoped>

p{
    margin: 0;
}

.whats_app_popup {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    width: 310px;
    align-items: flex-end;
    z-index: 100!important;
}

.whats_app_popup .whats_app_popup_close {
    background-color: #0dc152;
    width: 34px;
    height: 34px;
    text-align: center;
    line-height: 34px;
    border-radius: 50%;
    display: inline-block;
    color: #fff;
    margin-bottom: 15px;
    cursor: pointer;
}

.whats_app_popup .whats_app_popup_body {
    display: flex;
    align-items: flex-end;
    margin-bottom: 15px;
}

.whats_app_popup .whats_app_popup_body .whats_app_popup_thumb {
    flex: 50px 0 0;
    margin-right: 5px;
}

.whats_app_popup .whats_app_popup_body .whats_app_popup_thumb img {
    width: 50px;
    height: 50px;
    border-radius: 50%;
}

.whats_app_popup .whats_app_popup_body .whats_app_popup_msgs {
    box-shadow: 0 0 50px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
    background: #fff;
    width: 260px;
}

.whats_app_popup .whats_app_popup_body .whats_app_popup_msgs .whats_app_popup_head {
    background-color: #0dc152;
    border-radius: 7px 7px 0 0;
    padding: 20px 10px;
    text-align: center!important;
}

.whats_app_popup .whats_app_popup_body .whats_app_popup_msgs .whats_app_popup_head p {
    color: #fff;
    font-size: 14px;
    line-height: 20px;
    padding: 10px 20px;
}

.whats_app_popup .whats_app_popup_body .whats_app_popup_msgs .whats_app_popup_text {
    background-color: #fff;
    font-size: 14px;
    padding: 20px 35px;
    color: #888FBB;
    line-height: 16px;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    text-align: left;
    border-radius: 10px;
    display: flex;
    align-items: center;
    grid-gap: 6px;
}

.whats_app_popup .whats_app_popup_body .whats_app_popup_msgs .whats_app_popup_text img {
    width: 14px;
    flex: 14px 0 0;
    display: inline-block;
}

.whats_app_popup .whats_app_popup_body .whats_app_popup_msgs .whats_app_popup_text p {
    margin-bottom: 0;
}

.whats_app_popup .whats_app_popup_input {
    background: #fff;
    width: 260px;
    border-radius: 8px;
    box-shadow: 0 0 50px rgba(0, 0, 0, 0.1);
}

.whats_app_popup .whats_app_popup_input .primary_input_field,
.whats_app_popup .whats_app_popup_input .input-group-append button {
    border: 0;
}

.whats_app_popup .whats_app_popup_input .primary_input_field svg,
.whats_app_popup .whats_app_popup_input .input-group-append button svg {
    width: 20px;
}

.whats_app_popup .whats_app_members {
    padding: 12px;
}

.whats_app_popup .whats_app_members .whats_app_popup_input {
    background: #fff;
    width: 100%;
    border-radius: 8px;
    border: 1px solid #E7EDFB;
    margin-top: 10px;
    display: none;
}

.whats_app_popup .whats_app_members .single_group_member {
    margin-bottom: 10px;
}

.whats_app_popup .whats_app_members .single_group_member_inner {
    display: flex;
    align-items: center;
    cursor: pointer;
}

.whats_app_popup .whats_app_members .single_group_member_inner .thumb {
    flex: 50px 0 0;
    margin-right: 10px;
    position: relative;
}

.whats_app_popup .whats_app_members .single_group_member_inner .thumb img {
    width: 100%;
    border-radius: 50%;
}

.whats_app_popup .whats_app_members .single_group_member_inner .thumb .active_badge {
    width: 10px;
    height: 10px;
    background: #0DC152;
    border-radius: 50%;
    position: absolute;
    right: 1px;
    bottom: 4px;
    z-index: 13;
}

.whats_app_popup .whats_app_members .single_group_member_inner .thumb .inactive_badge {
    width: 10px;
    height: 10px;
    background: #f7bb08;
    border-radius: 50%;
    position: absolute;
    right: 1px;
    bottom: 4px;
    z-index: 13;
}

.whats_app_popup .whats_app_members .single_group_member_inner .group_member_meta span {
    font-size: 12px;
    display: block;
    line-height: 1;
}

.whats_app_popup .whats_app_members .single_group_member_inner .group_member_meta h4 {
    font-size: 13px;
    margin: 0;
    margin-bottom: 3px;
    font-weight: 500;
}

.whats_app_popup .whats_app_members .single_group_member_inner .group_member_meta p {
    font-size: 11px;
    margin: 0;
    line-height: 1;
}

.whats_app_popup .whats_app_popup_form {
    background: #fff;
    width: 260px;
    border-radius: 8px;
    padding: 0 12px 12px 12px;
}

.whats_app_popup .whats_app_popup_form .primary_input_coupon {
    border: 1px solid #E7EDFB;
    border-radius: 5px;
    overflow: hidden;
    height: 100px;
}

.whats_app_popup .whats_app_popup_form .primary_input_coupon textarea {
    padding: 12px 15px;
    font-size: 14px;
    color: #415094;
    border: 0;
    width: 1%;
    flex: 1 1 auto;
}

.whats_app_popup .whats_app_popup_form .primary_input_field,
.whats_app_popup .whats_app_popup_form .input-group-append button {
    border: 0;
    position: absolute;
    right: 5px;
    bottom: 5px;
    padding: 0;
    cursor: pointer;
    z-index: 12;
}

.whats_app_popup .whats_app_popup_form .primary_input_field svg,
.whats_app_popup .whats_app_popup_form .input-group-append button svg {
    width: 20px;
}

.whatsApp_popup_position {
    position: fixed;
    right: 30px;
    bottom: 90px;
    opacity: 0;
    visibility: hidden;
    z-index: 90;
}

.whatsApp_popup_position_left {
    position: fixed;
    left: 30px;
    bottom: 90px;
    opacity: 0;
    visibility: hidden;
    z-index: 90;
}

.whatsApp_popup_position.active {
    opacity: 1;
    visibility: visible;
}

.whatsApp_popup_position_left.active {
    opacity: 1;
    visibility: visible;
}

.whatsApp_icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: #00C348;
    font-size: 48px;
    line-height: 40px;
    text-align: center;
    color: #fff;
    position: fixed;
    right: 30px;
    bottom: 20px;
    cursor: pointer;
    z-index: 100;
}

.whatsApp_icon_left {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: #00C348;
    font-size: 48px;
    line-height: 40px;
    text-align: center;
    color: #fff;
    position: fixed;
    left: 30px;
    bottom: 20px;
    cursor: pointer;
    z-index: 100;
}
.whatsApp_icon i{
    padding: 15px;
    font-size: 30px;
}


.primary_input_field {
    border: 1px solid #ECEEF4;
    font-size: 14px;
    color: #415094;
    padding-left: 20px;
    height: 46px;
    border-radius: 30px;
    border-top-right-radius: 30px;
    border-bottom-right-radius: 30px;
    width: 100%;
    padding-right: 15px;
}
.input-group {
    position: relative;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    -ms-flex-align: stretch;
    align-items: stretch;
    width: 100%;
}
.input-group-append {
    margin-left: -1px;
    display: flex;
}
.whats_app_popup .whats_app_popup_input .primary_input_field, .whats_app_popup .whats_app_popup_input .input-group-append button{
    background: transparent;
}
.primary_input_coupon input {
    width: 1%;
    flex: 1 1 auto;
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
    border-right: 0;
    outline: 0;
}

.primary_input_coupon input:focus {

    outline: 0;
}

.whatsapp-ico {
    fill: white;
    width: 40px;
    height: 40px;
    margin: 10px;
}
.close-ico {
    fill: white;
    width: 16px;
    height: 16px;
    margin: 9px;
    margin-bottom: 10px;
}
.whats_app_popup_thumb{
    display: flex;
    justify-content: center;
}
.name_font{
    font-size: 16px!important;
}
.whatsap_padding_bottom{
    padding-bottom: 5px;
}
.mbottom_15{
    margin-bottom: 15px;
}
.designation_color{
    color: #9da0a7;
}
</style>
