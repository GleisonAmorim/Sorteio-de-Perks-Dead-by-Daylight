<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" href="{{ asset('public/favicon.png') }}">
    <link rel="stylesheet" href="{{asset('public/backend/vendors/css/bootstrap.css')}}">
    <link rel="stylesheet" href="{{asset('public/backend/login/css/themify-icons.css')}}">
    <link rel="stylesheet" href="{{asset('public/backend/login/css/style.css')}}">

    <style>
        .login_body{
            background: rgba(0, 0, 0, 0) url({{ asset('public/backend/login/img/login-bg.png') }}) no-repeat scroll center center / cover;
            margin-bottom: 29px;
        }
    </style>
</head>
<body class="login admin hight_100 login_body">

<div class="login_resister_area">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 offset-xl-2">
                @yield('authContent')
            </div>
        </div>
        <div class="row">
            <div class="col-xl-12 minus-bottom-100">
                <div class="footer_text text-center">
                    @if($gs->copyright_text)
                        <p> {{ $gs->copyright_text }} </p>
                    @else
                        <p>Copyright © 2021 Whatsapp Chat. All rights reserved | Made By <a href="https://codecanyon.net/user/codethemes"><span class="color_footer">CodeThemes</span></a></p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<script src="{{asset('public/backend/vendors/js/jquery-3.6.0.slim.min.js')}}" integrity=""></script>
<script src="{{asset('public/backend/vendors/js/popper.js')}}" ></script>
<script src="{{asset('public/backend/vendors/js/bootstrap.min.js')}}"></script>

</body>
</html>
