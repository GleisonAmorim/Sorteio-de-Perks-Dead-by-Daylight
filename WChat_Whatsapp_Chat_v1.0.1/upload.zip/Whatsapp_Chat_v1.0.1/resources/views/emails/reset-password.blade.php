<!doctype html>
<html lang="en-US">

<head>
    <meta content="text/html; charset=utf-8" http-equiv="Content-Type" />
    <title>Reset Password Email Template</title>
    <meta name="description" content="Reset Password Email Template.">
    <style type="text/css">
        a:hover {text-decoration: underline !important;}

        .body_st{
            margin: 0px; background-color: #f2f3f8;
        }
        .table_style{
            background-color: #f2f3f8;
            max-width:670px;
            margin:0 auto;
        }
        .td_st{
            height:80px;
        }
        .td1{
            text-align:center;
        }
        .td2{
            height:20px;
        }
        .tbl2{
            max-width:670px;background:#fff; border-radius:3px; text-align:center;-webkit-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);-moz-box-shadow:0 6px 18px 0 rgba(0,0,0,.06);box-shadow:0 6px 18px 0 rgba(0,0,0,.06);
        }
        .te3{
            height:40px;
        }
        .td12{
            padding:0 35px;
        }
        .hq1{
            color:#1e1e2d; font-weight:500; margin:0;font-size:32px;font-family:'Rubik',sans-serif;
        }
        .spncls{
            display:inline-block; vertical-align:middle; margin:29px 0 26px; border-bottom:1px solid #cecece; width:100px;
        }
        .pcls{
            color:#455056; font-size:15px;line-height:24px; margin:0;
        }
        .rp{
            background:#20e277;text-decoration:none !important; font-weight:500; margin-top:35px; color:#fff;text-transform:uppercase; font-size:14px;padding:10px 24px;display:inline-block;border-radius:50px;
        }
        .tdss{
            height:40px;
        }
        .td13{
            height:20px;
        }
        .tdr2{
            text-align:center;
        }
        .footer_cls{
            font-size:14px;
            color:rgba(69, 80, 86, 0.7411764705882353);
            line-height:18px;
            margin:0 0 0;
        }
        .last_cap{
            height:80px;
        }
        .t-top{
            font-family: 'Open Sans', sans-serif;
        }
    </style>
</head>

<body class="body_st" marginheight="0" topmargin="0" marginwidth="0" leftmargin="0">
<table cellspacing="0" border="0" cellpadding="0" width="100%" bgcolor="#f2f3f8" class="t-top">
    <tr>
        <td>
            <table class="table_style" width="100%" border="0"
                   align="center" cellpadding="0" cellspacing="0">
                <tr>
                    <td class="td_st">&nbsp;</td>
                </tr>
                <tr>
                    <td class="td1">
                        <a href="{{ $url }}" title="logo" target="_blank">
                            <img width="60" src="{{ $logo }}" title="logo" alt="logo">
                        </a>
                    </td>
                </tr>
                <tr>
                    <td class="td2">&nbsp;</td>
                </tr>
                <tr>
                    <td>
                        <table class="tbl2" width="95%" border="0" align="center" cellpadding="0" cellspacing="0">
                            <tr>
                                <td class="te3">&nbsp;</td>
                            </tr>
                            <tr>
                                <td class="td12">
                                    <h1 class="hq1">You have
                                        requested to reset your password</h1>
                                    <span class="spncls"></span>
                                    <p class="pcls">
                                        We cannot simply send you your old password. A unique link to reset your
                                        password has been generated for you. To reset your password, click the
                                        following link and follow the instructions.
                                    </p>
                                    <a href="{{ $url }}" class="rp">Reset
                                        Password</a>

                                    <p>If you’re having trouble clicking the "Reset Password" button, copy and paste the URL below
                                        into your web browser:
                                        <span>
                                            <a href="{{ $url }}"> {{ $url }}</a>
                                        </span>
                                    </p>
                                </td>
                            </tr>
                            <tr>
                                <td class="tdss">&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                <tr>
                    <td class="td13">&nbsp;</td>
                </tr>
                <tr>
                    <td class="tdr2">
                        <p class="footer_cls">&copy; <strong>{{ url('/') }}</strong></p>
                    </td>
                </tr>
                <tr>
                    <td class="last_cap">&nbsp;</td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>

</html>
