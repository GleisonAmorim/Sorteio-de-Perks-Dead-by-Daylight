@extends('layouts.auth')

@section('authContent')

    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-6 col-md-8">
            <div class="main_login_form">
                <div class="login_header text-center">
                    <div class="logo_img">
                        <a href="{{route('password.update')}}">
                            <img src="{{ asset(getSetting()->logo) }}" width="100" alt="">
                        </a>
                    </div>
                    <h5>Reset Password</h5>
                    <p class="text-success">{{ session()->get('message-success') }}</p>

                    <p class="text-danger">{{session()->get('message-danger') }}</p>

                </div>
                <form method="POST" class="loginForm" action="{{route('password.update') }}">
                    <input type="hidden" name="token" value="{{ $token }}">
                    {{ csrf_field() }}
                    <div class="single_input">
                        <input type="email" placeholder="Enter Email address" name="email">
                        <span class="addon_icon">
                            <i class="ti-email"></i>
                        </span>
                        @error('email')
                        <span class="invalid-feedback text-left pl-3" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="single_input">
                        <input type="password" placeholder="Enter Password" name="password">
                        <span class="addon_icon">
                            <i class="ti-key"></i>
                        </span>
                        @error('password')
                        <span class="invalid-feedback text-left pl-3" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>

                    <div class="single_input">
                        <input type="password" placeholder="Enter Password" name="password_confirmation">
                        <span class="addon_icon">
                            <i class="ti-key"></i>
                        </span>
                        @error('password')
                        <span class="invalid-feedback text-left pl-3" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="login_button text-center">
                        <button type="submit" class="primary-btn fix-gr-bg">
                            <span class="ti-lock mr-2"></span>
                            {{ __('general.Reset') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

@endsection
