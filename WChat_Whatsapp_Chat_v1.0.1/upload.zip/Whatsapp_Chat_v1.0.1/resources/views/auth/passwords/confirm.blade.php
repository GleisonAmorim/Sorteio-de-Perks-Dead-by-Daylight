@extends('layouts.auth')

@section('content')
    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-6 col-md-8">
            <div class="main_login_form">
                <div class="login_header text-center">
                    <div class="logo_img">
                        <a href="{{route('login')}}">
                            <img src="{{ asset(getSetting()->logo) }}" width="100" alt="">
                        </a>
                    </div>
                    <h5>{{ __('general.Confirm Password') }}</h5>
                    <p class="text-white">{{ __('general.Please confirm your password before continuing') }}.</p>
                </div>
                <form method="POST" class="loginForm" action="{{ route('password.confirm') }}">
                    @csrf
                    <div class="single_input">
                        <input type="password" placeholder="Enter Password" name="password">
                        <span class="addon_icon">
                            <i class="ti-key"></i>
                        </span>
                        @error('password')
                        <span class="invalid-feedback text-left pl-3" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="d-flex justify-content-between">
                        <div class="forgot_pass">
                            <a href="{{route('password.request') }}">{{ __('general.Forget Password') }}?</a>
                        </div>
                    </div>
                    <div class="login_button text-center">
                        <button type="submit" class="primary-btn fix-gr-bg">
                            <span class="ti-lock mr-2"></span>
                            {{ __('general.Confirm Password') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
