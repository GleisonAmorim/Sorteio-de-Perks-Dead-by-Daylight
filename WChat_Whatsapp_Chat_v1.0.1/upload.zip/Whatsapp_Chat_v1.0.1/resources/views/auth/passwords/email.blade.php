@extends('layouts.auth')

@section('authContent')

    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-6 col-md-8">
            <div class="main_login_form">
                <div class="login_header text-center">
                    <div class="logo_img">
                        <a href="{{route('login')}}">
                            <img src="{{ asset(getSetting()->logo) }}" width="100" alt="">
                        </a>
                    </div>
                    <h5>Reset Password</h5>
                    <p class="text-success">{{ session()->get('message-success') }}</p>

                    @if (session('status'))
                        <p class="text-danger">{{ session('status') }}</p>
                    @endif


                </div>
                <form method="POST" class="loginForm" action="{{ route('password.email') }}">
                    <input type="hidden" id="url" value="{{url('/')}}">
                    {{ csrf_field() }}
                    <div class="single_input">
                        <input type="email" placeholder="Enter Email address" name="email">
                        <span class="addon_icon">
                            <i class="ti-email"></i>
                        </span>
                        @error('email')
                        <span class="invalid-feedback text-left pl-3" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="login_button text-center">
                        <button type="submit" class="primary-btn fix-gr-bg">
                            <span class="ti-lock mr-2"></span>
                            {{ __('general.Send Reset Password Link') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
