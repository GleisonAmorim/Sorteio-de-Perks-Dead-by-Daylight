@extends('layouts.auth')

@section('authContent')
    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-6 col-md-8">
            <div class="main_login_form">
                <div class="login_header text-center">
                    <div class="logo_img">
                        <a href="{{route('login')}}">
                            <img src="{{ asset(getSetting()->logo) }}" width="100" alt="">
                        </a>
                    </div>
                    <h5>Login Details</h5>
                    <p class="text-success">{{ session()->get('message-success') }}</p>
                    <p class="text-danger">{{session()->get('message-danger') }}</p>

                </div>
                <form method="POST" class="loginForm" action="{{route('login') }}">
                    <input type="hidden" id="url" value="{{url('/')}}">
                    {{ csrf_field() }}
                    <div class="single_input">
                        <input type="email" placeholder="Enter Email address" name="email">
                        <span class="addon_icon">
                            <i class="ti-email"></i>
                        </span>
                        @error('email')
                            <span class="invalid-feedback text-left pl-3" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="single_input">
                        <input type="password" placeholder="Enter Password" name="password">
                        <span class="addon_icon">
                            <i class="ti-key"></i>
                        </span>
                        @error('password')
                            <span class="invalid-feedback text-left pl-3" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                        @enderror
                    </div>
                    <div class="d-flex justify-content-between">
                        <div class="checkbox">
                            <input class="form-check-input" type="checkbox" name="remember" id="rememberMe">
                            <label for="rememberMe">{{ __('general.Remember Me') }}</label>
                        </div>
                        <div class="forgot_pass">
                            <a href="{{route('password.request') }}">{{ __('general.Forget Password') }}?</a>
                        </div>
                    </div>
                    <div class="login_button text-center">
                        <button type="submit" class="primary-btn fix-gr-bg">
                            <span class="ti-lock mr-2"></span>
                            {{ __('general.login') }}
                        </button>
                    </div>
                </form>
            </div>

            @if(env('APP_SYNC'))
                <div class="row d-flex m-3 justify-content-center">
                    <a href="{{ route('auto.login','admin') }}" type="submit" class="demo-button primary-btn fix-gr-bg m-2">
                        <span class="ti-lock mr-2"></span>
                        {{ __('general.Super Admin') }}
                    </a>

                    <a href="{{ route('auto.login','user') }}" type="submit" class="demo-button primary-btn fix-gr-bg m-2">
                        <span class="ti-lock mr-2"></span>
                        {{ __('general.user') }}
                    </a>

                    <a href="{{ route('auto.login','agent') }}" type="submit" class="demo-button primary-btn fix-gr-bg m-2">
                        <span class="ti-lock mr-2"></span>
                        {{ __('general.agent') }}
                    </a>
                </div>

            @endif
        </div>
    </div>
@endsection
