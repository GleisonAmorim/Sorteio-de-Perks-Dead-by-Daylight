@extends('layouts.auth')

@section('authContent')
    <div class="row justify-content-center">
        <div class="col-xl-8 col-lg-6 col-md-8">
            <div class="main_login_form">
                <div class="login_header text-center">
                    <div class="logo_img">
                        <a href="{{route('login')}}">
                            <img src="{{ asset(getSetting()->logo) }}" width="100" alt="">
                        </a>
                    </div>
                    <h5>{{ __('general.Verify Your Email Address') }}</h5>
                    <p class="text-success">{{ __('general.A fresh verification link has been sent to your email address.') }}</p>
                    <p class="text-success">{{ __('general.Before proceeding, please check your email for a verification link. If you did not receive the email') }}</p>
                </div>
                <form method="POST" class="loginForm" action="{{ route('verification.resend') }}">
                    @csrf
                    <div class="login_button text-center">
                        <button type="submit" class="primary-btn fix-gr-bg">
                            <span class="ti-lock mr-2"></span>
                            {{ __('general.Click here to request another') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
