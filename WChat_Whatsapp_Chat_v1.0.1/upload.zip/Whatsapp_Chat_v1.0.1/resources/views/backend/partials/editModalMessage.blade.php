<div class="modal fade" id="editItem_{{$id}}" >
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h4 class="modal-title">@lang('general.Edit') {{ __('general.role')  }}</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="mt-2">
                    <form action="{{ $route_url }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="primary_input mb-25">
                            <label class="primary_input_label" for="">Name *</label>
                            <input class="primary_input_field" name="name" type="text" required value="{{ $name }}">
                        </div>
                        <br>
                        <input type="submit" class="primary-btn fix-gr-bg" value="Update"/>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
