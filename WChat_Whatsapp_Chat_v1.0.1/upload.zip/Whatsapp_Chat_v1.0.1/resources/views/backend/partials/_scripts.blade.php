
<script src="{{asset('public/backend/vendors/js/jquery-ui.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/jquery.data-tables.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/dataTables.buttons.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/buttons.flash.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/jszip.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/pdfmake_ex.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/vfs_fonts_1.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/buttons.html5.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/buttons.print.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/dataTables.responsive.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/buttons.colVis.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/popper.js')}}">
</script>
<script src="{{asset('public/backend/css/rtl/bootstrap.min.js')}}"></script>
<script src="{{asset('public/backend/vendors/js/nice-select.min.js')}}"></script>
<script src="{{asset('public/backend/vendors/js/jquery.magnific-popup.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/fastselect.standalone.min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/raphael-min.js')}}">
</script>
<script src="{{asset('public/backend/vendors/js/morris.min.js')}}"></script>
<script type="text/javascript" src="{{asset('public/backend/vendors/js/toastr.min.js')}}"></script>
<script type="text/javascript" src="{{asset('public/backend/vendors/js/moment.min.js')}}"></script>
<script src="{{ asset('public/backend/vendors/js/bootstrap-datetimepicker1.min.js') }}"></script>
<script src="{{asset('public/backend/vendors/js/bootstrap-datepicker.min.js')}}"></script>
<script src="{{ asset('public/backend/vendors/js/daterangepicker.min.js') }}"></script>


<script src="{{asset('public/backend/vendors/assets/tagsinput/tagsinput.js')}}"></script>
<script src="{{asset('public/backend/vendors/assets/text_editor/summernote-bs4.js')}}"></script>


<script src="{{asset('public/backend/vendors/js/nestable/jquery.nestable.js')}}"></script>

<script src="{{asset('public/backend/vendors/assets/js/metisMenu.js')}}"></script>
<script src="{{asset('public/backend/vendors/assets/progressbar/circle-progress.min.js')}}"></script>


<script type="text/javascript" src="{{asset('public/backend/vendors/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('public/backend/vendors/js/select2/select2.min.js')}}"></script>
<script src="{{asset('public/backend/js/main.js')}}"></script>
<script src="{{asset('public/backend/js/developer.js')}}"></script>
<script src="{{asset('public/backend/js/search.js')}}"></script>
<script src="{{asset('public/backend/vendors/js/toastr.js')}}"></script>
<script src="{{asset('public/backend/vendors/js/sweetalert.js')}}"></script>
@if(Session::has('messege'))
    <script src="{{asset('public/backend/js/tostr-flash.js')}}"></script>
@endif
<script >

    $(document).ready(function(){
        "use strict";
        let base_url = "{{ url('/').'/' }}";

        $("#sidebar_menu").find("a").removeClass("active");
        $("#sidebar_menu").find("li").removeClass("mm-active");
        $("#sidebar_menu").find("li ul").removeClass("mm-show");

        let current = window.location.pathname
        let home = '{{ url('/') }}';
        let current_url_php = '{{ url()->current() }}';

        $("#sidebar_menu >li a").filter(function () {
            "use strict";
            let link = $(this).attr("href");
            if(current === '/'){
                $('#dashboardMenu').toggleClass('active');
            }


            if (link && current_url_php !== home) {
                let check_url = link.indexOf(current);
                if (check_url != -1) {
                    $(this).parents().parents().children('ul.mm-collapse').addClass('mm-show').closest('li').addClass('mm-active');
                    $(this).addClass('active');
                    return false;
                }
            }
        });
    })

</script>

<script src="{{ asset('public/whatsapp-support/scripts.js') }}"></script>
<script src="{{ asset('public/backend/js/assets.js') }}"></script>

@stack('scripts')
