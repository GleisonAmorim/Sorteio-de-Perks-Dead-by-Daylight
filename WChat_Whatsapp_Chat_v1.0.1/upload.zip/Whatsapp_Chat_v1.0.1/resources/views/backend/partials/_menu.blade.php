<div class="container-fluid no-gutters">
    <div class="row">
        <div class="col-lg-12 p-0">
            <div class="header_iner d-flex justify-content-between align-items-center">
                <div class="small_logo_crm d-lg-none">
                   <a href="{{url('/login')}}"> <img src="{{asset('public/backend/frontend/img/logo.png')}}" alt=""></a>
                </div>
                <div id="sidebarCollapse" class="sidebar_icon  d-lg-none">
                    <i class="ti-menu"></i>
                </div>
                <div class="collaspe_icon open_miniSide">
                <i class="ti-menu"></i>
                </div>
                <div class="serach_field-area ml-40">
                        <div class="search_inner">
                            <form action="#">
                                <div class="search_field">
                                    <input type="text" placeholder="{{ __('general.search') }}" >
                                </div>
                                <button type="submit"> <i class="ti-search"></i> </button>
                            </form>
                        </div>
                    </div>
                <div class="header_middle d-none d-md-block">
                    <div class="select_style d-flex">
                        <div class="border_1px"></div>
                        <form action="{{ route('language.change.home') }}" method="post">
                            @csrf

                            <select name="lang" class="nice_Select bgLess mb-0" onchange="this.form.submit()">
                                @foreach($languages as $lang)
                                    <option value="{{ $lang->code }}" {{ app()->getLocale() == $lang->code ? 'selected' : '' }}>{{ $lang->name }}</option>
                                @endforeach
                            </select>
                        </form>
                    </div>
                </div>
                <div class="header_right d-flex justify-content-between align-items-center">
                    <div class="header_notification_warp d-flex align-items-center">

                    </div>
                    <div class="profile_info">
                        @if(auth()->check() && auth()->user()->avatar)
                            <img src="{{asset(auth()->user()->avatar)}}" alt="#">
                        @else
                            <img src="{{asset('public/whatsapp-support/demo-avatar.jpg')}}" alt="#">
                        @endif
                        <div class="profile_info_iner w-300px">
                            <div class="use_info d-flex align-items-center">
                                <div class="thumb">
                                    @if(auth()->user()->avatar)
                                        <img src="{{ asset(auth()->user()->avatar) }}" alt="">
                                    @else
                                        <img src="{{asset('public/whatsapp-support/demo-avatar.jpg')}}" alt="">
                                    @endif
                                </div>
                                <div class="user_text text-white ml-3" >
                                    <h5 class="text-white text-left font-20">{{ auth()->user()->name ?? '' }}</h5>
                                    <span class="text-left">
                                        {{ auth()->user()->email ?? '' }}
                                    </span>
                                </div>
                            </div>
                            <div class="profile_info_details text-left">
                                <a href="{{ route('profile') }}"><i class="ti-user"></i> {{ __('general.My Profile') }} </a>
                                <a href="{{ route('logout') }}" class="log_out"><i class="ti-shift-left"></i> {{ __('general.Logout') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
