
<footer class="footer-area pt-10 pb-20 d-block">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                @if($gs->copyright_text)
                    <p> {{ $gs->copyright_text }} </p>
                @else
                    Copyright © 2021 Whatsapp Chat. All rights reserved | Made By <a href="https://codecanyon.net/user/codethemes"><span class="color_footer">CodeThemes</span></a>
                @endif
            </div>
        </div>
    </div>
</footer>
