<nav id="sidebar" class="sidebar ">
    <div class="sidebar-header update_sidebar">
        <a class="large_logo" href="{{ url('/login') }}">
            @if(getSetting()->logo)
                <img src="{{ asset(getSetting()->logo) }}" alt="">
            @else
                <img src="{{ asset('public/backend/frontend/img/logo.png') }}" alt="">
            @endif
        </a>
        <a class="mini_logo" href="{{ url('/login') }}">
            @if(getSetting()->logo)
                <img src="{{ asset(getSetting()->favicon) }}" alt="">

            @else
                <img src="{{ asset('public/backend/frontend/img/upload_logo_small.png') }}" alt="">
            @endif
        </a>
        <a id="close_sidebar" class="d-lg-none">
            <i class="ti-close"></i>
        </a>
    </div>
    <ul id="sidebar_menu">
        <li>
            <a class="active" id="dashboardMenu" href="{{ url('/') }}" aria-expanded="false">
                <div class="nav_icon_small">
                    <span class="fas fa-th"></span>
                </div>
                <div class="nav_title">
                    <span>Dashboard</span>
                </div>
            </a>
        </li>

        @include('whatsappsupport::partials._menu')
    </ul>

</nav>
