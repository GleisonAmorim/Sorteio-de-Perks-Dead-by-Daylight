<head>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="icon" href="{{ asset($gs->favicon) }}" type="image/png" />
    <title>{{ $gs->site_title }}</title>
    <meta name="_token" content="{{  csrf_token() }}" />
    @if(isRtl())
        <style>
            .arrow::after{
                left: 12px!important;
                right: unset!important;
            }
        </style>
        <link rel="stylesheet" href="{{asset('public/backend/css/rtl/bootstrap.min.css')}}" />
        <link rel="stylesheet" href="{{asset('public/backend/css/rtl/base.css')}}" />
        <link rel="stylesheet" href="{{asset('public/backend/css/rtl/style.css')}}" />
    @else
        <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/bootstrap.css') }}" />
    @endif

    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/jquery-ui.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/jquery.data-tables.css') }}">
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/buttons.dataTables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/rowReorder.dataTables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/responsive.dataTables.min.css') }}">
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/bootstrap-datepicker.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/bootstrap-datetimepicker.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/css/daterangepicker.css') }}" />

    <link rel="stylesheet" href="{{ asset('public/backend/vendors/assets/font_awesome/css/all.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/assets/text_editor/summernote-bs4.css') }}" />

    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/themify-icons.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/flaticon.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/font-awesome.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/nice-select.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/magnific-popup.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/fastselect.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/css/toastr.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/js/select2/select2.css') }}" />

    <link rel="stylesheet" href="{{ asset('public/backend/vendors/assets/colorpicker.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/assets/css/metisMenu.css') }}" />

    <link rel="stylesheet" href="{{ asset('public/backend/css/loade.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/css/style.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/css/base.css') }}" />

    <link rel="stylesheet" href="{{ asset('public/backend/vendors/assets/css/style.css') }}" />
    <link rel="stylesheet" href="{{ asset('public/backend/vendors/assets/css/custom.css') }}" />

    <link rel="stylesheet" href="{{ asset('public/backend/css/role-permission.css') }}" />
    <link rel="stylesheet" href="{{asset('public/whatsapp-support/style.css')}}">

    <style>
        .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 34px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            -webkit-transition: .4s;
            transition: .4s;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 26px;
            width: 26px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            -webkit-transition: .4s;
            transition: .4s;
        }

        input:checked+.slider {
            background: linear-gradient(90deg, #7c32ff 0%, #c738d8 51%, #7c32ff 100%);
        }

        input:focus+.slider {
            box-shadow: 0 0 1px linear-gradient(90deg, #7c32ff 0%, #c738d8 51%, #7c32ff 100%);
        }

        input:checked+.slider:before {
            -webkit-transform: translateX(26px);
            -ms-transform: translateX(26px);
            transform: translateX(26px);
        }

        /* Rounded sliders */
        .slider.round {
            border-radius: 34px;
        }

        .slider.round:before {
            border-radius: 50%;
        }


        .switch::after {
            top: 6px;
            left: 6px;
            content: '';
            width: 15px;
            height: 15px;
            background-color: transparent;
            position: absolute;
            border-radius: 100%;
            transition: 1s;
        }

    </style>
    <style>
        .transfarent-btn{
            background-color: Transparent;
            background-repeat:no-repeat;
            border: none;
            cursor:pointer;
            overflow: hidden;
            outline:none;
        }

        #pre-loader{
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 1209;
            /* display: none; */
            overflow: hidden;
            outline: 0;
        }

      .loader
      {
          position: absolute;
          width: 100px;
          height: 100px;
          border-radius: 50%;
          background: linear-gradient(#14ffe9, #ffeb3b, #ff00e0);
          animation: animate 0.8s linear infinite;
          margin-top: 17%;
          margin-left: 50%;
          z-index: 10000;
      }
      @keyframes animate
      {
          0%
          {
              transform: rotate(0deg);
          }
          100%
          {
              transform: rotate(360deg);
          }
      }
      .loader span
      {
          position: absolute;
          width: 100%;
          height: 100%;
          border-radius: 50%;
          background: linear-gradient(#14ffe9, #ffeb3b, #ff00e0);
          animation: animate 0.8s linear infinite;
      }
      .loader span:nth-child(1)
      {
          filter: blur(5px);
      }
      .loader span:nth-child(2)
      {
          filter: blur(10px);
      }
      .loader span:nth-child(3)
      {
          filter: blur(25px);
      }
      .loader span:nth-child(4)
      {
          filter: blur(50px);
      }
      .loader:after
      {
          content: '';
          position: absolute;
          top: 10px;
          left: 10px;
          right: 10px;
          bottom: 10px;
          background: #fff;
          border-radius: 50%;
          background-image: url('/frontend/default/img/logo.png');
          background-size:cover;
      }
    .fileshow{
        display: grid;
        grid-template-columns: repeat(3,1fr);
        grid-template-rows: 120px;
        grid-gap: 30px;
    }
    .single-entry{
        width: 100%;
        flex: 100% 0 0;
        max-width: 100%;
    }
    .chat_input_box{
        right: 10px!important;
    }

    #lms_table_filter label{
        z-index: 0;
    }
    </style>

    @section('styles')
    @show

    <script src="{{ asset('public/backend/vendors/js/jquery-3.6.0.min.js') }}"></script>
</head>
