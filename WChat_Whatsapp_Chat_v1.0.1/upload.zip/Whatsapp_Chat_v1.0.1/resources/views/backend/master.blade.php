<!DOCTYPE html>
<html>

<html lang="{{ app()->getLocale() }}" @if(isRtl()) dir="rtl" class="rtl" @endif>
@include('backend.partials._header')
<body class="admin">
    <div id="pre-loader" class="d-none h-100 w-100">
        <div class="loader">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
        </div>
    </div>

    <div class="main-wrapper flex-column min_height_600">
        @include('backend.partials._sidebar')

        <div id="main-content">
            @include('backend.partials._menu')

            <div>
                @include('flash')
                @section('mainContent')
            </div>

            @show
        </div>

    </div>

    @include('backend.partials._footer')
    @include('backend.partials._scripts')
</body>

</html>
