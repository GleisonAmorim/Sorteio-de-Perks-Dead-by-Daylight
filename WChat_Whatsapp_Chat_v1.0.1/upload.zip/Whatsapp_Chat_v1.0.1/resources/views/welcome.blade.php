@extends('backend.master')

@section('mainContent')

    <section class="mb-40 up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row mb-5">
                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.total_click') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ $messages->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.click_from_mobile') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ $messages->where('device_type', 'Mobile')->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.click_from_desktop') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ $messages->where('device_type', 'Desktop')->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.total_user') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ \App\Models\User::whereNotIn('role_id', [1,3])->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.total_agent') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ \App\Models\User::where('role_id', 3)->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-lg-4 col-md-6 col-sm-6">
                    <a href="#" class="d-block">
                        <div class="white-box single-summery">
                            <div class="d-flex justify-content-between">
                                <div>
                                    <h3>{{ __('general.Unique Guest User') }}</h3>
                                    <p class="mb-0 invisible">{{ __('general.clicks') }}</p>
                                </div>
                                <h1 class="gradient-color2">
                                    {{ \Modules\WhatsappSupport\Entities\Message::all()->unique('ip')->count() }}
                                </h1>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>

    </section>

@endsection
