@extends('backend.master')
@section('mainContent')
    <section class="admin-visitor-area up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="">
                        <div class="row">
                            <div class="col-lg-12 mt-4">
                                <div class="white_box_30px">
                                    <div class="main-title mb-25">
                                        <h3 class="mb-3">{{ __('general.create_user') }}</h3>
                                        <p>{{ __('general.Default password will be') }} <code>12345678</code></p>
                                    </div>

                                    <form action="{{ route('users.store') }}" method=POST enctype=multipart/form-data>
                                        @csrf
                                        <div class="row" id="pusher">

                                            <div class="col-xl-12 mt-2">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.name') }} *</label>
                                                    <input class="primary_input_field" name="name" type="text" required>
                                                </div>
                                            </div>

                                            <div class="col-xl-12 mt-2">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.email') }} *</label>
                                                    <input class="primary_input_field" name="email" type="text" required>
                                                </div>
                                            </div>

                                            <div class="col-xl-12">
                                                <div class="primary_input mb-25">
                                                    <label class="primary_input_label" for="">{{ __('general.role') }} *</label>
                                                    <select id="translate_from" name="role_id" class="primary_select mb-25" required>
                                                        <option value="">Choose</option>
                                                        @foreach($roles as $role)
                                                            <option value="{{ $role->id }}">{{ $role->name }}</option>
                                                        @endforeach
                                                    </select>
                                                    @error('role_id') <small class="text-danger font-italic">*{{ $message }}</small> @enderror
                                                </div>
                                            </div>

                                            <div class="col-xl-12">
                                                <div class="primary_input mb-35">
                                                    <label class="primary_input_label" for="">
                                                        {{ __('general.Browse') }} {{ __('general.avatar') }}
                                                    </label>
                                                    <div class="primary_file_uploader">
                                                        <input class="primary-input" type="text" id="php_file_input_ph" placeholder="" readonly="">
                                                        <button class="primary_btn_2" type="button">
                                                            <label class="primary_btn_2" for="php_file_input">{{ __('general.Browse') }} </label>
                                                            <input type="file" class="d-none" name="image" id="php_file_input">
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <button class="primary-btn radius_30px fix-gr-bg mt-4"><i class="ti-check"></i>{{ __('general.create') }}</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
