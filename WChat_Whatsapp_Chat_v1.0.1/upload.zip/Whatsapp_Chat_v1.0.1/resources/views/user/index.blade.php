@extends('backend.master')
@section('mainContent')
    <section class="mb-40 up_st_admin_visitor">
        <div class="container-fluid p-0">
            <div class="row justify-content-center">
                <div class="col-12">
                    <div class="box_header common_table_header">
                        <div class="main-title d-flex">
                            <h3 class="mb-0 mr-30" >{{ __('general.users') }}</h3>
                            <ul>
                                @if(permissionCheck('users.create'))
                                <li><a href="{{ route('users.create') }}" class="primary-btn radius_30px fix-gr-bg text-white"><i class="ti-plus"></i> {{ __('general.add_user') }}</a></li>
                                @endif
                            </ul>
                        </div>

                    </div>
                </div>
                <div class="col-lg-12">
                    <div class="QA_section QA_section_heading_custom check_box_table">
                        <div class="QA_table ">
                            <div class="">
                                <table class="table Crm_table_active">
                                    <thead>
                                    <tr>
                                        <th scope="col">{{ __('general.id') }}</th>
                                        <th scope="col">{{ __('general.name') }}</th>
                                        <th scope="col">{{ __('general.email') }}</th>
                                        <th scope="col">{{ __('general.action') }}</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @forelse($users as $index => $user)
                                        <tr>
                                            <th><a>{{ $index+1 }}</a></th>
                                            <td><a href="">{{ $user->name }}</a> </td>
                                            <td>{{ $user->email }}</td>
                                            <td>
                                                <div class="dropdown CRM_dropdown">
                                                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        {{ __('general.select') }}
                                                    </button>
                                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenu2">
                                                        <a class="dropdown-item" href="{{ route('users.show', $user->id) }}" type="button">{{ __('general.Edit') }}</a>
                                                        <a href="#" data-toggle="modal" data-target="#deleteAdmissionQueryModal{{$index}}" class="dropdown-item" type="button">{{ __('general.Delete') }}</a>

                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <div class="modal fade admin-query" id="deleteAdmissionQueryModal{{ $index }}">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">{{ __('general.Delete') }} {{ __('general.File') }}</h4>
                                                        <button type="button" class="close text-success" data-dismiss="modal">&times;
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="text-center">
                                                            <h4>{{ __('general.Are you sure to delete') }}?</h4>
                                                            <h5 class="text-danger">( {{ __('general.Delete Confirmation') }} )</h5>
                                                        </div>
                                                        <div class="mt-40 d-flex justify-content-between">
                                                            <button type="button" class="primary-btn tr-bg" data-dismiss="modal">{{ __('general.Cancel') }}</button>
                                                            <a href="{{ route('users.delete', $user->id) }}" class="primary-btn fix-gr-bg" type="submit">{{ __('general.Delete') }}</a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    @empty
                                    @endforelse
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>
@endsection
