@extends('backend.master')

@section('mainContent')
        <div class="common_grid_wrapper">
            <div class="white_box_30px">
                <div class="main-title mb-25"><h3 class="mb-0">{{ __('general.Profile Settings') }}</h3></div>
                <form action="{{ route('profile.update') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="row">
                        <div class="col-md-12">
                            <div class="primary_input mb-25">
                                <label class="primary_input_label" for="name">{{ __('general.name') }} <strong class="text-danger">*</strong></label>
                                <input class="primary_input_field" name="name" value="{{ $user->name }}" required type="text">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="primary_input mb-25">
                                <label class="primary_input_label" for="name">{{ __('general.email') }} <strong class="text-danger">*</strong></label>
                                <input class="primary_input_field" name="email" value="{{ $user->email }}" required type="text">
                            </div>
                        </div>
                        <p class="w-100 text-center"><span class="badge badge-info">{{ __('general.Current') }} {{ __('general.avatar') }}</span></p>
                        <p class="text-center w-100"><img height="100" width="100" src="{{ asset($user->avatar) }}" alt=""></p>
                        <div class="col-12 profile">
                            <div class="primary_input mb-35">
                                <label class="primary_input_label" for="">
                                    {{ __('general.Browse') }} {{ __('general.avatar') }}
                                </label>
                                <div class="primary_file_uploader">
                                    <input class="primary-input" type="text" id="php_file_input_ph" placeholder="" readonly="">
                                    <button class="primary_btn_2" type="button">
                                        <label class="primary_btn_2" for="php_file_input">Browse </label>
                                        <input type="file" class="d-none" name="image" id="php_file_input">
                                    </button>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 mb-10">
                            <div class="submit_btn text-center">
                                <button class="primary_btn_large" type="submit"><i class="ti-check"></i> {{ __('general.update') }}</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="white_box_30px">
                <div class="main-title mb-25"><h3 class="mb-0">{{ __('general.Change') }} {{ __('general.Password') }} </h3></div>
                <form action="{{ route('profile.update.password') }}" method="POST">
                    @csrf
                    <div class="row">
                        <div class="col-md-12">
                            <div class="primary_input mb-25">
                                <label class="primary_input_label" for="password-field">{{ __('general.Current') }} {{ __('general.Password') }} <strong class="text-danger">*</strong></label>
                                <div>
                                    <input required class="primary_input_field" name="current_password" placeholder="{{ __('general.Current') }} {{ __('general.Password') }}" id="password-field" type="password">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="primary_input mb-25">
                                <label class="primary_input_label" for="password-field2">{{ __('general.New') }} {{ __('general.Password') }}  <strong class="text-danger">*</strong></label>
                                <input required class="primary_input_field" name="password" placeholder="{{ __('general.Current') }} {{ __('general.Password') }} {{ __('general.min_8') }}" id="password-field2" type="password">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="primary_input mb-25">
                                <label class="primary_input_label" for="password-field3">{{ __('general.re_type') }} {{ __('general.Password') }} <strong class="text-danger">*</strong></label>
                                <input required class="primary_input_field" name="confirm_password" id="password-field3" placeholder="{{ __('general.re_type') }} {{ __('general.Password') }}" type="password">
                            </div>
                        </div>
                        <div class="col-12 mb-10">
                            <div class="submit_btn text-center">
                                <button class="primary_btn_large" type="submit"><i class="ti-check"></i> {{ __('general.update') }}</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
@endsection

@push('scripts')

@endpush
