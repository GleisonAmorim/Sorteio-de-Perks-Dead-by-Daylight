<?php
return [
    "Edit Timezone Info" => "Editar información de huso horario",

    "Timezone has been deleted Successfully" => "El huso horario se ha suprimido correctamente",

    "login" => "login",

    "list" => "Lista",

    "create" => "Crear",

    "browse" => "Examinar",

    "name" => "Nombre",

    "update" => "Actualización",

    "settings" => "Configuración",

    "files" => "Archivos",

    "file" => "Archivo",

    "new" => "Nuevo",

    "type" => "Tipo",

    "send" => "Enviar",

    "delete" => "Suprimir",

    "yes" => "Sí",

    "select" => "Seleccione",

    "no" => "No",

    "user" => "Usuario",

    "required" => "Obligatorio",

    "permission" => "Permiso",

    "remove" => "Eliminar",

    "start" => "Inicio",

    "to" => "A",

    "add" => "Añadir",

    "search" => "Búsqueda",

    "description" => "Descripción",

    "Title" => "Título",

    "Yes" => "Sí",

    "No" => "No",

    "Date" => "Fecha",

    "List" => "Lista",

    "Add" => "Añadir",

    "Make Default" => "Hacer predeterminado",

    "Course" => "Curso",

    "Quiz" => "Cuestionario",

    "Login" => "Iniciar sesión",

    "View Profile" => "Ver perfil",

    "My Profile" => "Mi perfil",

    "Profile Settings" => "Configuración del perfil",

    "Current" => "Actual",

    "Re-Type Password" => "Volver a escribir contraseña",

    "Type Password" => "Escriba la contraseña",

    "Remember Me" => "Recuerdame",

    "Login Details" => "Detalles de conexión",

    "Forget Password ?" => "¿olvidar la contraseña?",

    "Need an account?" => "¿Necesita una cuenta?",

    "Sign Up" => "Regístrate",

    "Sign Up Details" => "Detalles de registro",

    "You have already an account?" => "¿Ya tienes una cuenta?",

    "Send Reset Link" => "Enviar enlace de restablecimiento",

    "Reset Password" => "Restablecer contraseña",

    "Reset" => "Restablecer",

    "Set New Password" => "Establecer nueva contraseña",

    "Set Password" => "Establecer contraseña",

    "Start From" => "Iniciar desde",

    "Start At" => "Iniciar en",

    "To" => "A",

    "Free" => "Libre",

    "Off" => "Apagado",

    "On" => "En",

    "Social Link" => "Enlace social",

    "Active Status" => "Estado Activo",

    "Language List" => "Lista de idiomas",

    "Choose File" => "Seleccione Archivo",

    "Translation" => "Traducción",

    "Currency" => "Moneda",

    "Add New" => "Añadir nuevo",

    "ID" => "ID",

    "Details" => "Detalles",

    "Name" => "Nombre",

    "Action" => "Acción",

    "Edit" => "Editar",

    "Delete" => "Suprimir",

    "Select" => "Seleccione",

    "Save" => "Guardar",

    "Update" => "Actualización",

    "Live" => "Viva",

    "Sandbox" => "Sandbox",

    "Something Went Wrong" => "Algo Salió Mal",

    "Description" => "Descripción",

    "Model" => "Modelo",

    "Attempted At" => "Intentado en",

    "User" => "Usuario",

    "Activity Logs" => "Registros de actividad",

    "Type" => "Tipo",

    "Delete Confirmation" => "Confirmación de supresión",

    "Human Resource" => "Recurso humano",

    "Staff" => "Personal",

    "Staff List" => "Lista de personal",

    "Username" => "Nombre",

    "Email" => "Correo electrónico",

    "Phone" => "Teléfono",

    "Registered Date" => "Fecha de registro",

    "Status" => "Estado",

    "URL" => "URL",

    "Register" => "Registro",

    "Remove" => "Eliminar",

    "Staff Id" => "ID de personal",

    "Password" => "Contraseña",

    "Confirm Password" => "Confirmar contraseña",

    "Re-Password" => "Volver a la contraseña",

    "Browse" => "Examinar",

    "Avatar" => "Avatar",

    "Edit Staff Info" => "Editar información de personal",

    "Staff info has been updated Successfully" => "La información del personal se ha actualizado correctamente",

    "Staff has been added Successfully" => "El personal se ha añadido satisfactoriamente",

    "View" => "Vista",

    "Staff Info" => "Información del personal",

    "Close" => "Cierre",

    "Staff ID" => "ID de personal",

    "Password did not match with your account password." => "La contraseña no coincide con la contraseña de su cuenta.",

    "Put Your password" => "Ponga su contraseña",

    "Staff has been deleted Successfully" => "El personal se ha suprimido correctamente",

    "Language" => "Lengua",

    "Variant" => "Variante",

    "Add Variant" => "Añadir variante",

    "Publish" => "Publicación",

    "Published" => "Publicado",

    "Variation Values" => "Valores de variación",

    "Add Value" => "Añadir valor",

    "Edit Variant" => "Editar variante",

    "Unit Type" => "Tipo de unidad",

    "Add Unit Type" => "Añadir tipo de unidad",

    "Edit Unit Type" => "Editar tipo de unidad",

    "Brand" => "Marca",

    "Add Brand" => "Añadir marca",

    "Edit Brand" => "Editar marca",

    "Add Model" => "Añadir modelo",

    "Edit Model" => "Modelo de edición",

    "Category" => "Categoría",

    "Add Category" => "Añadir categoría",

    "Code" => "Código",

    "Add as Sub Category" => "Añadir como subcategoría",

    "Select parent Category" => "Seleccionar categoría padre",

    "Edit Category" => "Editar categoría",

    "Add New Product" => "Añadir producto nuevo",

    "Product Name" => "Nombre del producto",

    "Product SKU" => "Código de artículo",

    "Barcode Type" => "Código de barras",

    "Unit" => "Unidad",

    "Sub Category" => "Subcategoría",

    "Add File" => "Añadir archivo",

    "Manage Stock" => "Gestionar existencias",

    "Alert Quantity" => "Cantidad de alerta",

    "Variation" => "Variación",

    "Add Variation" => "Añadir variación",

    "Add Product" => "Añadir producto",

    "Edit Product" => "Editar producto",

    "Employee Id" => "ID de empleado",

    "Address" => "Dirección",

    "New Price Group" => "Nuevo grupo de precios",

    "Export" => "Exportación",

    "SL" => "SL",

    "Cancel" => "Cancelar",

    "About" => "Acerca de",

    "letter" => "carta",

    "date" => "fecha",

    "Image" => "Imagen",

    "File Not Found" => "Archivo no encontrado",

    "Download" => "Descargar",

    "Are you sure to delete ?" => "¿Está seguro de suprimir?",

    "Are you sure to" => "¿Está seguro de que",

    "Are you sure to enable this ?" => "¿Está seguro de habilitar esto?",

    "Are You Sure To Change Status ?" => "¿está Seguro De Cambiar El Estado?",

    "Are You Sure To Remove This?" => "¿está Seguro De Eliminar Esto?",

    "Role" => "Función",

    "Success" => "Éxito",

    "Failed" => "Error",

    "Dashboard" => "Dashboard",

    "User Logs" => "Registros de usuario",

    "Question & Answer" => "Pregunta y respuesta",

    "Comments" => "Observaciones",

    "Replies" => "Respuestas",

    "Commented By" => "Comentado por",

    "Submitted" => "Presentado",

    "Enable" => "Habilitar",

    "Disable" => "Inhabilitar",

    "Active" => "Activo",

    "Deactive" => "Desactivo",

    "Inactive" => "Inactivo",

    "Email Address" => "Dirección electrónica",

    "Instagram URL" => "URL de Instagram",

    "Youtube URL" => "URL de Youtube",

    "LinkedIn URL" => "URL de LinkedIn",

    "Twitter URL" => "URL de Twitter",

    "Facebook URL" => "URL de Facebook",

    "Date of Birth" => "Fecha de nacimiento",

    "Change Status" => "Cambiar estado",

    "Start Date" => "Fecha de inicio",

    "End Date" => "Fecha final",

    "Filter History" => "Historial de filtros",

    "Reject" => "Rechazar",

    "Reason" => "Motivo",

    "Payouts" => "Pagos",

    "Author" => "Autor",

    "Available" => "Disponible",

    "Issue Date" => "Fecha de emisión",

    "Duration" => "Duración",

    "Change" => "Cambio",

    "Deactivate" => "Desactivar",

    "Files" => "Archivos",

    "File" => "Archivo",

    "Send" => "Enviar",

    "Paid" => "Pagada",

    "Waiting" => "Esperando",

    "Info" => "Info",

    "Zip Code" => "Código postal",

    "Country" => "País",

    "City" => "Ciudad",

    "Submit" => "Presentar",

    "Error" => "Error",

    "Warning" => "Advertencia",

    "Used" => "Utilizado",

    "Join For Free" => "Unirse por libre",

    "Enter Email" => "Introduzca el correo",

    "Enter Password" => "Introduzca la contraseña",

    "Enter Phone Number" => "Especifique el número de teléfono",

    "Enter Confirm Password" => "Especifique la contraseña de confirmación",

    "Update Profile" => "Actualizar perfil",

    "Review" => "Revisión",

    "Log in with Facebook" => "Inicie sesión con Facebook",

    "Log in with Google" => "Inicie sesión con Google",

    "Or" => "O",

    "Keep me up to date on WCHAT" => "Mantenerme al día en WCHAT",

    "Required" => "Obligatorio",

    "New" => "Nuevo",

    "Instructor Payout" => "Pago de instructor",

    "Time Left" => "Tiempo dejado",

    "No Item found" => "No se ha encontrado elemento",

    "Total Price" => "Precio total",

    "Discount or coupon info" => "Información de descuento o cupón",

    "Checkout" => "Extracción",

    "Apply" => "Aplicar",

    "Course Schedule" => "Planificación del curso",

    "Add To Cart" => "Añadir a la cesta",

    "Buy Now" => "Comprar ahora",

    "Lessons" => "Lecciones",

    "Bookmarks" => "Marcadores",

    "Deposit" => "Depósito",

    "Referral" => "Remisión",

    "My Cart" => "Mi carrito",

    "Purchase History" => "Historial de compras",

    "My Courses" => "Mis Cursos",

    "Live Classes" => "Clases vivas",

    "Already Enrolled" => "Ya inscrito",

    "Student Enrolled" => "Estudiante matriculado",

    "Already Submitted" => "Ya presentado",

    "Correct Answer" => "Respuesta correcta",

    "Wrong Answer" => "Respuesta equivocada",

    "Skip" => "Omitir",

    "Next" => "Siguiente",

    "Previous" => "Anterior",

    "Course File" => "Archivo del curso",

    "Share" => "Cuota",

    "Course Files" => "Archivos Del Curso",

    "Course Review" => "Revisión del curso",

    "Start Date & Time" => "Fecha y hora de inicio",

    "At" => "En",

    "Show" => "Mostrar",

    "Drip Content" => "Contenido de goteo",

    "Specific Date" => "Fecha específica",

    "Days After Enrollment" => "Días después de la inscripción",

    "Show All" => "Mostrar todo",

    "Show After Unlock" => "Mostrar después del desbloqueo",

    "Aws S3 Setting" => "Ajuste S3 De Aws",

    "Access Key Id" => "Id de clave de acceso",

    "Secret Key" => "Clave secreta",

    "Default Region" => "Región predeterminada",

    "AWS Bucket" => "Grupo AWS",

    "Module Manager" => "Gestor de módulos",

    "Payment Type" => "Tipo de pago",

    "Blogs" => "Blogs",

    "Star" => "Estrella",

    "Total Courses" => "Cursos totales",

    "Discount" => "Descuento",

    "Logo" => "Logotipo",

    "My Quizzes" => "Mis cuestionarios",

    "Enroll Now" => "Inscríbase ahora",

    "Added To Cart" => "Añadido Al Carro",

    "Logged In Devices" => "Conectado En Dispositivos",

    "Purchase Price" => "Precio de compra",

    "Pay" => "Retribución",

    "Welcome" => "Bienvenido",

    "Send Email" => "Enviar correo electrónico",

    "Minimum 8 characters" => "Mínimo de 8 caracteres",

    "Status has been changed" => "El estado ha cambiado",

    "For the demo version, you cannot change this" => "Para la versión de demostración, no puede cambiar esto",

    "Video File" => "Archivo de vídeo",

    "Browse Video file" => "Buscar archivo de vídeo",

    "Select Date" => "Fecha de selección",

    "Days" => "Días",

    "Operation successful" => "Operación satisfactoria",

    "Operation failed" => "Error de operación",

    "Quick Search" => "Búsqueda rápida",

    "Copy" => "Copia",

    "Excel" => "Excel",

    "CSV" => "CSV",

    "PDF" => "PDF",

    "Print" => "Imprimir",

    "No data available in the table" => "No hay datos disponibles en la tabla",

    "Successfully Assign" => "Asignar correctamente",

    "Make Paid" => "Hacer de pago",

    "Request For Paid" => "Solicitud De Pago",

    "End Date & Time" => "Fecha y hora de finalización",

    "Short Description" => "Breve descripción",

    "Website" => "Página web",

    "Browse file" => "Buscar archivo",

    "failed" => "Estas credenciales no coinciden con nuestros registros.",

    "Create" => "Crear",

    "Time" => "Tiempo",

    "Start" => "Inicio",

    "view_settings" => "Valores de vista",

    "functional_settings" => "Configuración funcional",

    "color" => "Color",

    "agents" => "Agentes",

    "intro_text" => "Introducción Texto",

    "single_agent" => "Agente único",

    "multi_agent" => "Agente múltiple",

    "availability" => "Disponibilidad",

    "only_mobile" => "Sólo móvil",

    "only_desktop" => "Sólo Desktop",

    "both" => "Ambos",

    "showing_page" => "Mostrar página",

    "only_homepage" => "Sólo Página de inicio",

    "all_page" => "Sólo Página de inicio",

    "popup_open_initially" => "Abrir ventana emergente inicialmente",

    "agent_type" => "Tipo de agente",

    "homepage_url" => "URL de página de inicio",

    "whatsapp_support" => "Soporte de WhatsApp",

    "primary_number" => "Número primario",

    "agent" => "Agente",

    "create_agent" => "Crear agente",

    "update_agent" => "Agente de actualización",

    "number" => "Número",

    "add_agent" => "Añadir agente",

    "designation" => "Designación",

    "avatar" => "Avatar",

    "status" => "Estado",

    "active" => "Activo",

    "inactive" => "En-Activo",

    "browse_avatar" => "Examinar Avatar",

    "always_available" => "Siempre disponible",

    "analytics" => "Análisis",

    "rtl_ltl" => "RTL/LTL",

    "code" => "Código",

    "Default password will be" => "La contraseña predeterminada será",

    "native_name" => "Nombre nativo",

    "key" => "Clave",

    "value" => "Valor",

    "edit_language_info" => "Editar información de idioma",

    "users" => "Usuarios",

    "Whatsapp support icon position" => "Posición icono de soporte de Whatsapp",

    "copy_script" => "Copie este script y péguelo en su sitio web antes de que finalice la etiqueta del cuerpo.",

    "update_user" => "Actualizar usuario",

    "email" => "Correo electrónico",

    "language_list" => "Lista de idiomas",

    "new_language" => "Nueva lengua",

    "translation" => "Traducción",

    "create_user" => "Crear usuario",

    "System Settings" => "Configuración del sistema",

    "assign" => "Asignar",

    "add_user" => "Añadir usuario",

    "icon_position" => "Posición del icono de Whatsapp",

    "bottom_left" => "Inferior izquierda",

    "bottom_right" => "Derecho inferior",

    "margin_from_bottom" => "Margen De Fondo",

    "margin_from_right" => "Margen De Derecho",

    "margin_from_left" => "Margen De Izquierda",

    "role_permission" => "Permiso de rol",

    "layout_settings" => "Configuración de diseño",

    "choose_layout" => "Seleccione Formato",

    "show_unavailable_agent_in_popup" => "Mostrar agente no disponible en ventana emergente",

    "end" => "Fin",

    "time" => "Tiempo",

    "Apply All Days" => "Aplicar todos los días",

    "Are you sure to delete" => "¿Está seguro de suprimir?",

    "id" => "ID",

    "ip" => "IP",

    "browser" => "Navegador",

    "operating_system" => "Sistema operativo",

    "messages" => "Mensajes",

    "with_country_code" => "Con el código de país se debe",

    "total_click" => "Total de clics",

    "clicks" => "Clicks",

    "click_from_mobile" => "Haga clic en Desde móvil",

    "click_from_desktop" => "Haga clic en Desde escritorio",

    "action" => "Acción",

    "welcome_message" => "Mensaje de bienvenida",

    "your_scripts" => "Sus scripts",

    "Sanitize No" => "Sanear No",

    "Sanitize Yes" => "Sanear Sí",

    "3DS Yes" => "3DS Sí",

    "3DS No" => "3DS No",

    "Module Verification" => "Verificación del módulo",

    "Envato Email Address" => "Dirección de correo electrónico de Envío",

    "Envato Purchase Code" => "Código de compra de Envío",

    "Verifying" => "Verificación",

    "None" => "Ninguno",

    "Subscription Api Key" => "Clave de API de suscripción",

    "Subscription Method" => "Método de suscripción",

    "Watch Now" => "Mira ahora",

    "Continue Watch" => "Continue Watch",

    "End" => "Fin",

    "TimeZone" => "Huso horario",

    "Backup" => "Copia",

    "Upload SQL File" => "Cargar archivo SQL",

    "Database Backup List" => "Lista de copias de seguridad",

    "Generate New Backup" => "Generar nueva copia de seguridad",

    "File Name" => "Nombre de archivo",

    "Theme" => "Tema",

    "Reset To Default" => "Restablecer A Valor Predeterminado",

    "Mode" => "Modo",

    "Sub Title" => "Subtítulo",

    "Timetable" => "Calendario",

    "System Activated Date" => "Fecha de activación del sistema",

    "Install Domain" => "Dominio de instalación",

    "Purchase code" => "Código de compra",

    "Curl Enable" => "Curl Enable",

    "PHP Version" => "Versión de PHP",

    "Check update" => "Comprobar actualización",

    "Software Version" => "Versión de software",

    "About System" => "Acerca de System",

    "Upload From Local Directory" => "Subir Desde Directorio Local",

    "Update System" => "Sistema de actualización",

    "min_8" => "Mínimo de 8 caracteres",

    "re_type" => "Volver a escribir",

    "update_system" => "Sistema de actualización",

    "general_settings" => "Configuración general",

    "Timezone Name" => "Nombre de huso horario",

    "Timezone Code" => "Código de huso horario",

    "Advanced Filter" => "Filtro avanzado",

    "upload" => "Carga",

    "change_logo" => "Cambiar logotipo",

    "change_fav" => "Cambio Fav",

    "Delete confirmation message" => "Mensaje de confirmación de supresión",

    "assign_permission" => "Asignar permiso",

    "role" => "Función",

    "total_user" => "Total Usuario",

    "total_agent" => "Total Agente",

    "Unique Guest User" => "Usuario invitado exclusivo",

    "Filter" => "Filtro",

    "Timezone List" => "Lista de zonas horarias",

    "submit" => "Presentar",

    "Email Configuration" => "Configuración del correo",

    "Send Test Mail" => "Enviar correo de prueba",

    "Send a Test Email to" => "Enviar un correo electrónico de prueba a",

    "Predefined Footer" => "Pie de página predefinido",

    "Predefined Header" => "Cabecera predefinida",

    "Email Signature" => "Firma electrónica",

    "Sender Email" => "Correo electrónico remitente",

    "Sender Name" => "Nombre del remitente",

    "Email Protocol" => "Correo electrónico",

    "Mail Engine" => "Motor de correo",

    "From Name" => "De Nombre",

    "From Mail" => "De Correo",

    "Mail Host" => "Host de correo",

    "Mail Port" => "Puerto de correo",

    "Mail Username" => "Nombre de usuario",

    "Mail Password" => "Contraseña de correo",

    "Mail Encryption" => "Cifrado de correo",

    "Email Charset" => "Charset de correo electrónico",

    "Email Setup" => "Configuración del correo",

    "whatsapp bubble logo" => "Logo de burbuja de Whatsapp",

    "System Last Update" => "Última actualización del sistema",

    "hi_modal" => "¡Hola! Bienvenido ¿Cómo puedo ayudarte?",

    "Logout" => "Cierre",

    "Confirmation" => "Confirmación",

    "In-active" => "Activo",

    "disabled" => "disabled",

    "Verify Your Email Address" => "Verifique Su Dirección De Correo Electrónico",

    "Click here to request another" => "Pulse aquí para solicitar otro",

    "Before proceeding, please check your email for a verification link. If you did not receive the email" => "Antes de proceder, compruebe su correo electrónico para ver un enlace de verificación. Si no ha recibido el correo electrónico",

    "usA fresh verification link has been sent to your email address.er" => "Se ha enviado un nuevo enlace de verificación a su dirección de correo electrónico.",

    "Super Admin" => "Super Admin",

    "Send Reset Password Link" => "Enviar enlace de restablecimiento de contraseña",

    "Please confirm your password before continuing" => "Confirme su contraseña antes de continuar",

    "Forget Password" => "Olvidar la contraseña",

    "SMTP" => "SMTP",

    "Php Mail" => "Correo de PHP",

    "Email Text" => "Correo electrónico",

    "whatsapp_chat" => "Chat de Whatsapp",

    "To Mail" => "Correo electrónico",

    "site_title" => "Título del sitio",

    "copy_right" => "Copiar texto correcto",

    "Mail Driver" => "Controlador de correo",

];
