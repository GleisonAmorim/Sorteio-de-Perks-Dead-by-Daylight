<?php
return [
    "Edit Timezone Info" => "Editer les informations de fuseau horaire",

    "Timezone has been deleted Successfully" => "Le fuseau horaire a été supprimé",

    "login" => "Connexion",

    "failed" => "Ces données d'identification ne correspondent pas à nos enregistrements.",

    "Blogs" => "Blogues",

    "List" => "Liste",

    "Create" => "Créer",

    "Show" => "Afficher",

    "Title" => "Titre",

    "Description" => "Description",

    "Status" => "Statut",

    "Image" => "Image",

    "SL" => "SL",

    "Dashboard" => "Tableau de bord",

    "Enable" => "Activer",

    "Disable" => "Désactiver",

    "Duration" => "Durée",

    "Logo" => "Logo",

    "Browse" => "Parcourir",

    "Update" => "Mise à jour",

    "ID" => "ID",

    "Password" => "Mot de passe",

    "Add" => "Ajouter",

    "Yes" => "Oui",

    "No" => "Non",

    "Save" => "Sauvegarder",

    "Date" => "Date",

    "Time" => "Heure",

    "Start" => "Démarrer",

    "Select" => "Sélectionner",

    "View" => "Afficher",

    "Edit" => "Editer",

    "Delete" => "Supprimer",

    "Cancel" => "Annuler",

    "Name" => "Nom",

    "Details" => "Détails",

    "Close" => "Fermer",

    "Make Default" => "Définir par défaut",

    "Course" => "Cours",

    "Quiz" => "Jeu-questionnaire",

    "Send Email" => "Envoyer un courrier électronique",

    "list" => "Liste",

    "create" => "Créer",

    "browse" => "Parcourir",

    "name" => "Nom",

    "update" => "Mise à jour",

    "settings" => "Paramètres",

    "files" => "Fichiers",

    "file" => "Fichier",

    "new" => "Nouveau",

    "type" => "Type",

    "send" => "Envoyer",

    "delete" => "Supprimer",

    "yes" => "Oui",

    "select" => "Sélectionner",

    "no" => "Non",

    "user" => "Utilisateur",

    "required" => "Obligatoire",

    "permission" => "Droit",

    "remove" => "Supprimer",

    "start" => "Démarrer",

    "to" => "Vers",

    "add" => "Ajouter",

    "search" => "Rechercher",

    "description" => "Description",

    "Logout" => "Déconnexion",

    "Active" => "Actif",

    "Login" => "Connexion",

    "View Profile" => "Afficher le profil",

    "My Profile" => "Mon profil",

    "Profile Settings" => "Paramètres de profil",

    "Current" => "Courant",

    "Re-Type Password" => "Nouveau type de mot de passe",

    "Type Password" => "Mot de passe type",

    "Remember Me" => "Se souvenir de moi",

    "Login Details" => "Détails de connexion",

    "Forget Password ?" => "Mot de passe oublié?",

    "Need an account?" => "Besoin d'un compte?",

    "Sign Up" => "Se connecter",

    "Sign Up Details" => "Détails de la connexion",

    "You have already an account?" => "Vous avez déjà un compte?",

    "Send Reset Link" => "Envoyer le lien de réinitialisation",

    "Reset Password" => "Réinitialiser le mot",

    "Reset" => "Réinitialiser",

    "Set New Password" => "Définir un nouveau mot de passe",

    "Set Password" => "Définir mot de passe",

    "Start From" => "Début à partir de",

    "Start At" => "Démarrer à",

    "To" => "Vers",

    "Free" => "Libérez",

    "Off" => "Désactivé",

    "On" => "Sur",

    "Social Link" => "Lien social",

    "Active Status" => "Statut actif",

    "Language List" => "Liste des langues",

    "Choose File" => "Choisir un fichier",

    "Translation" => "Traduction",

    "Currency" => "Devise",

    "Add New" => "Ajouter nouveau",

    "Action" => "Action",

    "Live" => "Live",

    "Sandbox" => "Bac à sable",

    "Something Went Wrong" => "Quelque chose de Went Wrong",

    "Model" => "Modèle",

    "Attempted At" => "Tentative de",

    "User" => "Utilisateur",

    "Activity Logs" => "Journaux d'activité",

    "Type" => "Type",

    "Delete Confirmation" => "Confirmation de suppression",

    "Human Resource" => "Ressource humaine",

    "Staff" => "Personnel",

    "Staff List" => "Liste du personnel",

    "Username" => "Nom d'utilisateur",

    "Email" => "Courrier électronique",

    "Phone" => "Téléphone",

    "Registered Date" => "Date d'enregistrement",

    "URL" => "URL",

    "Register" => "Inscription",

    "Remove" => "Supprimer",

    "Staff Id" => "ID personnel",

    "Confirm Password" => "Confirmer mot de",

    "Re-Password" => "Re-mot de passe",

    "Avatar" => "Avatar",

    "Edit Staff Info" => "Editer les informations du personnel",

    "Staff info has been updated Successfully" => "L'information du personnel a été mise à jour avec succès",

    "Staff has been added Successfully" => "Le personnel a été ajouté avec succès",

    "Staff Info" => "Informations sur le personnel",

    "Staff ID" => "ID personnel",

    "Password did not match with your account password." => "Le mot de passe ne correspond pas à votre mot de passe de compte.",

    "Put Your password" => "Mettre votre mot de passe",

    "Staff has been deleted Successfully" => "Le personnel a été supprimé",

    "Language" => "Langue",

    "Variant" => "Variante",

    "Add Variant" => "Ajouter une variante",

    "Publish" => "Publier",

    "Published" => "Publié",

    "Variation Values" => "Valeurs de variation",

    "Add Value" => "Ajouter une valeur",

    "Edit Variant" => "Editer la variante",

    "Unit Type" => "Type d'unité",

    "Add Unit Type" => "Ajouter un type d'unité",

    "Edit Unit Type" => "Editer le type d'unité",

    "Brand" => "Marque",

    "Add Brand" => "Ajouter une marque",

    "Edit Brand" => "Editer la marque",

    "Add Model" => "Ajouter un modèle",

    "Edit Model" => "Editer le modèle",

    "Category" => "Catégorie",

    "Add Category" => "Ajouter une catégorie",

    "Code" => "Code",

    "Add as Sub Category" => "Ajouter en tant que sous-catégorie",

    "Select parent Category" => "Sélectionner une catégorie parent",

    "Edit Category" => "Editer une catégorie",

    "Add New Product" => "Ajouter un nouveau produit",

    "Product Name" => "Nom du produit",

    "Product SKU" => "SKU du produit",

    "Barcode Type" => "Type de code à barres",

    "Unit" => "Unité",

    "Sub Category" => "Sous-catégorie",

    "Add File" => "Ajouter un fichier",

    "Manage Stock" => "Gérer le stock",

    "Alert Quantity" => "Quantité d'alerte",

    "Variation" => "Variation",

    "Add Variation" => "Ajouter une variante",

    "Add Product" => "Ajouter un produit",

    "Edit Product" => "Editer le produit",

    "Employee Id" => "ID employé",

    "Address" => "Adresse",

    "New Price Group" => "Nouveau groupe de prix",

    "Export" => "Exportation",

    "About" => "A propos",

    "letter" => "Lettre",

    "date" => "Date",

    "File Not Found" => "Fichier introuvable",

    "Download" => "Télécharger",

    "Are you sure to delete ?" => "Etes-vous sûr de supprimer?",

    "Are you sure to" => "Etes-vous sûr de",

    "Are you sure to enable this ?" => "Etes-vous sûr de l'activer?",

    "Are You Sure To Change Status ?" => "Êtes-vous sûr de changer le statut?",

    "Are You Sure To Remove This?" => "Are You Sure To Remove This?",

    "Role" => "Rôle",

    "Success" => "Succès",

    "Failed" => "Echec",

    "User Logs" => "Journaux utilisateur",

    "Question & Answer" => "Question et réponse",

    "Comments" => "Commentaires",

    "Replies" => "Réponses",

    "Commented By" => "Commenté par",

    "Submitted" => "Soumis",

    "Deactive" => "Deactif",

    "Inactive" => "Inactif",

    "Email Address" => "Adresse électronique",

    "Instagram URL" => "URL Instagram",

    "Youtube URL" => "URL Youtube",

    "LinkedIn URL" => "URL LinkedIn",

    "Twitter URL" => "URL Twitter",

    "Facebook URL" => "URL Facebook",

    "Date of Birth" => "Date de naissance",

    "Change Status" => "Modifier le statut",

    "Start Date" => "Date de début",

    "End Date" => "Date de fin",

    "Filter History" => "Historique des filtres",

    "Reject" => "Rejeter",

    "Reason" => "Raison",

    "Payouts" => "Payements",

    "Author" => "Auteur",

    "Available" => "Disponible",

    "Issue Date" => "Date d'émission",

    "Change" => "Changement",

    "Deactivate" => "Désactiver",

    "Files" => "Fichiers",

    "File" => "Fichier",

    "Send" => "Envoyer",

    "Paid" => "Payé",

    "Waiting" => "En attente",

    "Info" => "Infos",

    "Zip Code" => "Code postal",

    "Country" => "Pays",

    "City" => "Ville",

    "Submit" => "Soumettre",

    "Error" => "Erreur",

    "Warning" => "Avertissement",

    "Used" => "Utilisé",

    "Join For Free" => "Jointure pour Free",

    "Enter Email" => "Entrer un e-mail",

    "Enter Password" => "Entrez mot de passe",

    "Enter Phone Number" => "Entrer le numéro de téléphone",

    "Enter Confirm Password" => "Entrez confirmation du mot de passe",

    "Update Profile" => "Mettre à jour profil",

    "Review" => "Révision",

    "Log in with Facebook" => "Se connecter avec Facebook",

    "Log in with Google" => "Se connecter avec Google",

    "Or" => "Ou",

    "Keep me up to date on WCHAT" => "Garder-moi jusqu'à ce jour sur WCHAT",

    "Required" => "Obligatoire",

    "New" => "Nouveau",

    "Instructor Payout" => "Payeur du formateur",

    "Time Left" => "Heure de gauche",

    "No Item found" => "Aucun élément trouvé",

    "Total Price" => "Prix total",

    "Discount or coupon info" => "Informations de remise ou de coupon",

    "Checkout" => "Extraire",

    "Apply" => "Appliquer",

    "Course Schedule" => "Calendrier des cours",

    "Add To Cart" => "Ajouter au panier",

    "Buy Now" => "Acheter maintenant",

    "Lessons" => "Leçons",

    "Bookmarks" => "Signets",

    "Deposit" => "Dépôt",

    "Referral" => "Référencement",

    "My Cart" => "Mon panier",

    "Purchase History" => "Historique des achats",

    "My Courses" => "Mes cours",

    "Live Classes" => "Classes de Live",

    "Already Enrolled" => "Déjà intégré",

    "Student Enrolled" => "Étudiant enroulé",

    "Already Submitted" => "Déjà soumis",

    "Correct Answer" => "Réponse correcte",

    "Wrong Answer" => "Réponse incorrecte",

    "Skip" => "Sauter",

    "Next" => "Suivant",

    "Previous" => "Précédent",

    "Course File" => "Fichier de cours",

    "Share" => "Partager",

    "Course Files" => "Fichiers de cours",

    "Course Review" => "Revue du cours",

    "Start Date & Time" => "Date et heure de début",

    "At" => "À",

    "Drip Content" => "Contenu de Drip",

    "Specific Date" => "Date spécifique",

    "Days After Enrollment" => "Jours après l'inscription",

    "Show All" => "Afficher tout",

    "Show After Unlock" => "Afficher après déverrouillage",

    "Aws S3 Setting" => "Paramètre Aws S3",

    "Access Key Id" => "ID clé d'accès",

    "Secret Key" => "Clé secrète",

    "Default Region" => "Région par défaut",

    "AWS Bucket" => "Bucket AWS",

    "Module Manager" => "Gestionnaire de modules",

    "Payment Type" => "Type de paiement",

    "Star" => "Étoile",

    "Total Courses" => "Total des cours",

    "Discount" => "Remise",

    "My Quizzes" => "Mes Quizzzes",

    "Enroll Now" => "Inscrire maintenant",

    "Added To Cart" => "Ajouté au panier",

    "Logged In Devices" => "Unités de connexion",

    "Purchase Price" => "Prix d'achat",

    "Pay" => "Payer",

    "Welcome" => "Bienvenue",

    "Minimum 8 characters" => "8 caractères au minimum",

    "Status has been changed" => "Le statut a été modifié",

    "For the demo version, you cannot change this" => "Pour la version de démonstration, vous ne pouvez pas modifier cette",

    "Video File" => "Fichier vidéo",

    "Browse Video file" => "Parcourir le fichier vidéo",

    "Select Date" => "Sélectionner une date",

    "Days" => "Jours",

    "Operation successful" => "Opération réussie",

    "Operation failed" => "Echec de l'opération",

    "Quick Search" => "Recherche rapide",

    "Copy" => "Copier",

    "Excel" => "Excel",

    "CSV" => "CSV",

    "PDF" => "PDF",

    "Print" => "Imprimer",

    "No data available in the table" => "Aucune donnée disponible dans la table",

    "Successfully Assign" => "Affecter avec succès",

    "Make Paid" => "Rendre payé",

    "Request For Paid" => "Demande de paya",

    "End Date & Time" => "Date et heure de fin",

    "Short Description" => "Description courte",

    "Website" => "Site Web",

    "Browse file" => "Parcourir le fichier",

    "Advanced Filter" => "Filtre avancé",

    "Filter" => "Filtrer",

    "view_settings" => "Paramètres de vue",

    "functional_settings" => "Paramètres fonctionnels",

    "color" => "Couleur",

    "agents" => "Agents",

    "intro_text" => "Introduction Texte",

    "single_agent" => "Agent unique",

    "multi_agent" => "Agent multiple",

    "availability" => "Disponibilité",

    "only_mobile" => "Uniquement mobile",

    "only_desktop" => "Bureau uniquement",

    "both" => "Les deux",

    "showing_page" => "Affichage de la page",

    "only_homepage" => "Page d'accueil uniquement",

    "all_page" => "Toutes les pages",

    "popup_open_initially" => "Ouvrir l'ouverture initiale",

    "agent_type" => "Type d'agent",

    "homepage_url" => "URL de la page d'accueil",

    "whatsapp_support" => "Support WhatsApp",

    "primary_number" => "Numéro principal",

    "agent" => "Agent",

    "create_agent" => "Créer un agent",

    "update_agent" => "Mettre à jour agent",

    "number" => "Numéro",

    "add_agent" => "Ajouter un agent",

    "designation" => "Désignation",

    "avatar" => "Avatar",

    "status" => "Statut",

    "active" => "Actif",

    "inactive" => "En cours",

    "browse_avatar" => "Parcourir Avatar",

    "always_available" => "Toujours disponible",

    "analytics" => "Analyse",

    "rtl_ltl" => "RTL / LTL",

    "code" => "Code",

    "Default password will be" => "Le mot de passe par défaut sera",

    "native_name" => "Nom natif",

    "key" => "Clé",

    "value" => "Valeur",

    "edit_language_info" => "Editer les informations de langue",

    "users" => "Utilisateurs",

    "Whatsapp support icon position" => "Position de l'icône de support Whatsapp",

    "copy_script" => "Copiez ce script et collez-le sur votre site Web avant la fin de la balise de corps.",

    "update_user" => "Mise à jour utilisateur",

    "email" => "Courrier électronique",

    "language_list" => "Liste des langues",

    "new_language" => "Nouvelle langue",

    "translation" => "Traduction",

    "create_user" => "Créer un utilisateur",

    "System Settings" => "Paramètres système",

    "assign" => "Affecter",

    "add_user" => "Ajouter un utilisateur",

    "icon_position" => "Position de l'icône Whatsapp",

    "bottom_left" => "Gauche inférieure",

    "bottom_right" => "En bas à droite",

    "margin_from_bottom" => "Marge du bas",

    "margin_from_right" => "Marge de droite",

    "margin_from_left" => "Marge de gauche",

    "role_permission" => "Droit de rôle",

    "layout_settings" => "Paramètre de présentation",

    "choose_layout" => "Choisissez Mise en page",

    "show_unavailable_agent_in_popup" => "Afficher l'agent non disponible dans popup",

    "end" => "Fin",

    "time" => "Heure",

    "Apply All Days" => "Appliquer tous les jours",

    "Are you sure to delete" => "Etes-vous sûr de supprimer",

    "id" => "ID",

    "ip" => "IP",

    "browser" => "Navigateur",

    "operating_system" => "Système d'exploitation",

    "messages" => "Messages",

    "with_country_code" => "Le code pays doit être",

    "total_click" => "Total des clics",

    "clicks" => "Clics",

    "click_from_mobile" => "Cliquez sur Mobile",

    "click_from_desktop" => "Cliquez sur A partir du bureau",

    "action" => "Action",

    "welcome_message" => "Message d'accueil",

    "your_scripts" => "Vos scripts",

    "Sanitize No" => "Sanitize Non",

    "Sanitize Yes" => "Sanitize Oui",

    "3DS Yes" => "3DS Oui",

    "3DS No" => "3DS Non",

    "Module Verification" => "Vérification du module",

    "Envato Email Address" => "Adresse électronique Envato",

    "Envato Purchase Code" => "Code d'achat Envato",

    "Verifying" => "Vérification",

    "None" => "Néant",

    "Subscription Api Key" => "Clé Api d'abonnement",

    "Subscription Method" => "Méthode d'abonnement",

    "Watch Now" => "Watch Now",

    "Continue Watch" => "Poursuivre la surveillance",

    "End" => "Fin",

    "TimeZone" => "Fuseau horaire",

    "Backup" => "Sauvegarde",

    "Upload SQL File" => "Télécharger le fichier SQL",

    "Database Backup List" => "Liste sauvegarde de base de données",

    "Generate New Backup" => "Générer une nouvelle sauvegarde",

    "File Name" => "Nom de fichier",

    "Theme" => "Thème",

    "Reset To Default" => "Réinitialiser par défaut",

    "Mode" => "Mode",

    "Sub Title" => "Sous-titre",

    "Timetable" => "Calendrier",

    "System Activated Date" => "Date d'activation du système",

    "Install Domain" => "Domaine d'installation",

    "Purchase code" => "Code d'achat",

    "Curl Enable" => "Activation de Curl",

    "PHP Version" => "Version PHP",

    "Check update" => "Mettre à jour la",

    "Software Version" => "Version du logiciel",

    "About System" => "A propos du système",

    "Upload From Local Directory" => "Télécharger à partir du répertoire local",

    "Update System" => "Mise à jour système",

    "min_8" => "Minimum 8 caractères",

    "re_type" => "Ré-type",

    "update_system" => "Mise à jour système",

    "Email Configuration" => "Configuration du courrier électronique",

    "Send Test Mail" => "Envoyer un courrier test",

    "Send a Test Email to" => "Envoyer un e-mail de test à",

    "Predefined Footer" => "Pied de page prédéfini",

    "Predefined Header" => "En-tête prédéfini",

    "Email Signature" => "Signature électronique",

    "Sender Email" => "Adresse électronique de l'expéditeur",

    "Sender Name" => "Nom de l'expéditeur",

    "Email Protocol" => "Protocole de courrier électronique",

    "Mail Engine" => "Moteur de messagerie",

    "From Name" => "Du nom",

    "From Mail" => "A partir du courrier",

    "Mail Host" => "Hôte de messagerie",

    "Mail Port" => "Port du courrier",

    "Mail Username" => "Nom d'utilisateur du courrier",

    "Mail Password" => "Mot de passe courrier",

    "Mail Encryption" => "Chiffrement du courrier",

    "Email Charset" => "Jeu de caractères de courrier électronique",

    "general_settings" => "Paramètres généraux",

    "Email Setup" => "Configuration du courrier électronique",

    "Timezone Name" => "Nom du fuseau horaire",

    "Timezone Code" => "Code de fuseau horaire",

    "upload" => "Télécharger",

    "change_logo" => "Modifier le logo",

    "change_fav" => "Changer de Fav",

    "Delete confirmation message" => "Supprimer le message de confirmation",

    "assign_permission" => "Affecter une autorisation",

    "role" => "Rôle",

    "total_user" => "Utilisateur total",

    "total_agent" => "Agent total",

    "Unique Guest User" => "Utilisateur invité unique",

    "Timezone List" => "Liste des fuseaux horaires",

    "whatsapp bubble logo" => "Logo de la bulle Whatsapp",

    "System Last Update" => "Dernière mise à jour du système",

    "submit" => "Soumettre",

    "hi_modal" => "Salut ! Bienvenue Comment puis-je vous aider?",

    "Confirmation" => "Confirmation",

    "In-active" => "En cours",

    "disabled" => "Désactivé",

    "Verify Your Email Address" => "Vérification de votre adresse électronique",

    "Click here to request another" => "Cliquez ici pour demander une autre",

    "Before proceeding, please check your email for a verification link. If you did not receive the email" => "Avant de poursuivre, veuillez consulter votre courriel pour obtenir un lien de vérification. Si vous n'avez pas reçu le courrier électronique",

    "usA fresh verification link has been sent to your email address.er" => "Un lien de vérification a été envoyé à votre adresse électronique.",

    "Super Admin" => "Super Admin",

    "Send Reset Password Link" => "Lien Envoyer le mot de passe de réinitialisation",

    "Please confirm your password before continuing" => "Veuillez confirmer votre mot de passe avant de continuer",

    "Forget Password" => "Mot de passe oublié",

    "SMTP" => "SMTP",

    "Php Mail" => "Courrier Php",

    "Email Text" => "Texte du courrier électronique",

    "whatsapp_chat" => "Whatsapp Chat",

    "To Mail" => "Vers le courrier",

    "site_title" => "Titre du site",

    "copy_right" => "Copier le texte de droite",

    "Mail Driver" => "Pilote de messagerie",

];
