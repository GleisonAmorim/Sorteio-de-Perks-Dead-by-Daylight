<?php
return [
    "rtl_ltl" => "RTL/LTL",

    "code" => "โค้ด",

    "search" => "การค้นหา",

    "Timetable" => "ตารางเวลา",

    "System Activated Date" => "วันที่ที่เรียกใช้ระบบ",

    "Install Domain" => "ติดตั้งโดเมน",

    "Purchase code" => "รหัสการซื้อ",

    "Curl Enable" => "เปิดใช้งาน Curl",

    "PHP Version" => "เวอร์ชันของ PHP",

    "Check update" => "ตรวจสอบการอัพเดต",

    "Software Version" => "เวอร์ชันของซอฟต์แวร์",

    "About System" => "เกี่ยวกับระบบ",

    "Upload From Local Directory" => "อัพโหลดจากโลคัลไดเร็กทอรี",

    "Update System" => "อัพเดตระบบ",

    "Default password will be" => "รหัสผ่านดีฟอลต์จะเป็น",

    "native_name" => "ชื่อดั้งเดิม",

    "min_8" => "ค่าต่ำสุด 8 อักขระ",

    "re_type" => "พิมพ์ใหม่",

    "update_system" => "อัพเดตระบบ",

    "key" => "คีย์",

    "value" => "ค่า",

    "edit_language_info" => "แก้ไขข้อมูลภาษา",

    "users" => "ผู้ใช้",

    "Whatsapp support icon position" => "ตำแหน่งของไอคอนสนับสนุนแอ็พพลิเคชัน",

    "copy_script" => "คัดลอกสคริปต์นี้และวางลงในเว็บไซต์ของคุณก่อนที่แท็กเนื้อความจะสิ้นสุด",

    "update_user" => "อัพเดตผู้ใช้",

    "email" => "อีเมล",

    "language_list" => "รายการภาษา",

    "new_language" => "ภาษาใหม่",

    "translation" => "การแปล",

    "create_user" => "สร้างผู้ใช้",

    "System Settings" => "ค่าติดตั้งของระบบ",

    "assign" => "กำหนด",

    "permission" => "การให้สิทธิ์",

    "add_user" => "เพิ่มผู้ใช้",

    "icon_position" => "ตำแหน่งไอคอน Whats app",

    "bottom_left" => "ล่างซ้าย",

    "bottom_right" => "ล่างขวา",

    "margin_from_bottom" => "ระยะขอบจากด้านล่าง",

    "margin_from_right" => "ระยะขอบจากด้านขวา",

    "margin_from_left" => "ระยะขอบจากซ้าย",

    "role_permission" => "สิทธิของบทบาท",

    "layout_settings" => "ค่าติดตั้งโครงร่าง",

    "choose_layout" => "เลือกโครงร่าง",

    "show_unavailable_agent_in_popup" => "แสดงเอเจนต์ไม่พร้อมใช้งานในป็อปอัพ",

    "start" => "เริ่มต้น",

    "end" => "สิ้นสุด",

    "time" => "เวลา",

    "Apply All Days" => "ใช้วันทั้งหมด",

    "Are you sure to delete" => "คุณแน่ใจว่าต้องการลบ",

    "create" => "สร้าง",

    "select" => "เลือก",

    "id" => "ID",

    "ip" => "ยิปมัน",

    "browser" => "เบราว์เซอร์",

    "operating_system" => "ระบบปฏิบัติการ",

    "messages" => "ข้อความ",

    "with_country_code" => "ต้องมีรหัสประเทศ",

    "total_click" => "จำนวนคลิกทั้งหมด",

    "clicks" => "คลิก",

    "click_from_mobile" => "คลิกจากโทรศัพท์เคลื่อนที่",

    "click_from_desktop" => "คลิกจากเดสก์ท็อป",

    "action" => "การดำเนินการ",

    "welcome_message" => "ข้อความต้อนรับ",

    "your_scripts" => "สคริปต์ของคุณ",

    "Login" => "เข้าสู่ระบบ",

    "View Profile" => "ดูโปรไฟล์",

    "My Profile" => "ประวัติของฉัน",

    "Profile Settings" => "ค่าติดตั้งโปรไฟล์",

    "Current" => "ปัจจุบัน",

    "Re-Type Password" => "พิมพ์รหัสผ่านอีกครั้ง",

    "Type Password" => "พิมพ์รหัสผ่าน",

    "Remember Me" => "จดจำฉัน",

    "Login Details" => "รายละเอียดล็อกอิน",

    "Forget Password ?" => "ลืมรหัสผ่าน?",

    "Need an account?" => "ต้องการแอคเคาต์?",

    "Sign Up" => "ลงชื่อเข้าใช้",

    "Sign Up Details" => "รายละเอียดการลงชื่อเข้าใช้",

    "You have already an account?" => "คุณมีแอคเคาต์อยู่แล้วหรือไม่?",

    "Send Reset Link" => "ส่งลิงก์รีเซ็ต",

    "Reset Password" => "รีเซ็ตรหัสผ่าน",

    "Reset" => "รีเซ็ต",

    "Set New Password" => "ตั้งค่ารหัสผ่านใหม่",

    "Set Password" => "ตั้งค่ารหัสผ่าน",

    "Start From" => "เริ่มต้นจาก",

    "Start At" => "เริ่มต้นที่",

    "To" => "ไปยัง",

    "Free" => "ฟรี",

    "Off" => "ปิด",

    "On" => "เปิด",

    "Social Link" => "ลิงก์ทางสังคม",

    "Active Status" => "สถานะแอ็คทีฟ",

    "Language List" => "รายการภาษา",

    "Choose File" => "เลือกไฟล์",

    "Translation" => "การแปล",

    "Currency" => "สกุลเงิน",

    "Add New" => "เพิ่มใหม่",

    "ID" => "ID",

    "Title" => "ชื่อเรื่อง",

    "Details" => "รายละเอียด",

    "Name" => "ชื่อ",

    "Action" => "การดำเนินการ",

    "Edit" => "แก้ไข",

    "Delete" => "ลบ",

    "Select" => "เลือก",

    "Save" => "บันทึก",

    "Update" => "อัพเดต",

    "Live" => "สด",

    "Sandbox" => "แซนด์บ็อกซ์",

    "Something Went Wrong" => "บางสิ่งผิดปกติ",

    "Description" => "รายละเอียด",

    "Model" => "รุ่น",

    "Attempted At" => "พยายามที่",

    "User" => "ผู้ใช้",

    "Activity Logs" => "ไฟล์บันทึกกิจกรรม",

    "Type" => "ชนิด",

    "Delete Confirmation" => "การยืนยันการลบ",

    "Human Resource" => "ทรัพยากรบุคคล",

    "Staff" => "พนักงาน",

    "Staff List" => "รายชื่อพนักงาน",

    "Username" => "ชื่อผู้ใช้",

    "Email" => "อีเมล",

    "Phone" => "โทรศัพท์",

    "Registered Date" => "วันที่ที่ลงทะเบียน",

    "Status" => "สถานะ",

    "URL" => "URL",

    "Register" => "การลงทะเบียน",

    "Remove" => "ลบออก",

    "Staff Id" => "Id พนักงาน",

    "Password" => "รหัสผ่าน",

    "Confirm Password" => "ยืนยันรหัสผ่าน",

    "Re-Password" => "รหัสผ่านใหม่",

    "Browse" => "เรียกดู",

    "Avatar" => "ผู้อวตาร",

    "Edit Staff Info" => "แก้ไขข้อมูลพนักงาน",

    "Staff info has been updated Successfully" => "อัปเดตข้อมูลพนักงานเรียบร้อยแล้ว",

    "Staff has been added Successfully" => "เพิ่มทีมงานเสร็จเรียบร้อยแล้ว",

    "View" => "ดู",

    "Staff Info" => "ข้อมูลพนักงาน",

    "Close" => "ปิด",

    "Staff ID" => "รหัสพนักงาน",

    "Password did not match with your account password." => "รหัสผ่านไม่ตรงกับรหัสผ่านแอคเคาต์ของคุณ",

    "Put Your password" => "ใส่รหัสผ่านของคุณ",

    "Staff has been deleted Successfully" => "ลบทีมงานเรียบร้อยแล้ว",

    "Language" => "ภาษา",

    "Variant" => "ตัวแปร",

    "Add Variant" => "เพิ่มตัวแปร",

    "Publish" => "เผยแพร่",

    "Published" => "เผยแพร่แล้ว",

    "Variation Values" => "ค่าการแปรผัน",

    "Add Value" => "เพิ่มค่า",

    "Edit Variant" => "แก้ไขตัวแปร",

    "Unit Type" => "ชนิดหน่วย",

    "Add Unit Type" => "เพิ่มชนิดของยูนิต",

    "Edit Unit Type" => "แก้ไขชนิดหน่วย",

    "Brand" => "แบรนด์",

    "Add Brand" => "เพิ่มแบรนด์",

    "Edit Brand" => "แก้ไขตราสินค้า",

    "Add Model" => "เพิ่มโมเดล",

    "Edit Model" => "แก้ไขโมเดล",

    "Category" => "หมวดหมู่",

    "Add Category" => "เพิ่มหมวดหมู่",

    "Code" => "โค้ด",

    "Add as Sub Category" => "เพิ่มเป็นหมวดหมู่ย่อย",

    "Select parent Category" => "เลือกหมวดหมู่พาเรนต์",

    "Edit Category" => "แก้ไขหมวดหมู่",

    "Add New Product" => "เพิ่มผลิตภัณฑ์ใหม่",

    "Product Name" => "ชื่อผลิตภัณฑ์",

    "Product SKU" => "SKU ผลิตภัณฑ์",

    "Barcode Type" => "ชนิดบาร์โค้ด",

    "Unit" => "หน่วย",

    "Sub Category" => "หมวดหมู่ย่อย",

    "Add File" => "เพิ่มไฟล์",

    "Manage Stock" => "จัดการหุ้น",

    "Alert Quantity" => "ปริมาณการแจ้งเตือน",

    "Variation" => "การแปรผัน",

    "Add Variation" => "เพิ่มการเปลี่ยนแปลง",

    "Add Product" => "เพิ่มผลิตภัณฑ์",

    "Edit Product" => "แก้ไขผลิตภัณฑ์",

    "Employee Id" => "รหัสพนักงาน",

    "Address" => "แอดเดรส",

    "New Price Group" => "กลุ่มราคาใหม่",

    "Export" => "เอ็กซ์พอร์ต",

    "SL" => "สล.",

    "Cancel" => "ยกเลิก",

    "About" => "เกี่ยวกับ",

    "letter" => "ตัวอักษร",

    "date" => "วันที่",

    "Date" => "วันที่",

    "Image" => "รูปภาพ",

    "File Not Found" => "ไม่พบไฟล์",

    "Download" => "ดาวน์โหลด",

    "Are you sure to delete ?" => "คุณแน่ใจว่าต้องการลบ?",

    "Are you sure to" => "คุณแน่ใจว่า",

    "Are you sure to enable this ?" => "คุณแน่ใจว่าเปิดใช้งานสิ่งนี้หรือไม่?",

    "Are You Sure To Change Status ?" => "คุณแน่ใจที่จะเปลี่ยนสถานะหรือไม่?",

    "Are You Sure To Remove This?" => "คุณแน่ใจที่จะลบนี้หรือไม่?",

    "Role" => "บทบาท",

    "List" => "รายการ",

    "Add" => "เพิ่ม",

    "Success" => "สำเร็จ",

    "Failed" => "ล้มเหลว",

    "Dashboard" => "แดชบอร์ด",

    "User Logs" => "ล็อกของผู้ใช้",

    "Question & Answer" => "คำถาม & คำตอบ",

    "Comments" => "ความคิดเห็น",

    "Course" => "คอร์ส",

    "Replies" => "การตอบกลับ",

    "Commented By" => "แสดงโดย",

    "Submitted" => "ส่งแล้ว",

    "Enable" => "เปิดใช้งาน",

    "Disable" => "ปิดใช้งาน",

    "Active" => "แอ็คทีฟ",

    "Deactive" => "ไม่แอ็คทีฟ",

    "Inactive" => "ไม่ใช้งาน",

    "Email Address" => "อีเมลแอดเดรส",

    "Instagram URL" => "URL ของ Instagram",

    "Youtube URL" => "URL ของ Youtube",

    "LinkedIn URL" => "URL ของ LinkedIn",

    "Twitter URL" => "URL ของ Twitter",

    "Facebook URL" => "URL ของ Facebook",

    "Date of Birth" => "วันที่เกิด",

    "Change Status" => "เปลี่ยนสถานะ",

    "Start Date" => "วันที่เริ่มต้น",

    "End Date" => "วันที่สิ้นสุด",

    "Filter History" => "ประวัติตัวกรอง",

    "Reject" => "ปฏิเสธ",

    "Reason" => "เหตุผล",

    "Payouts" => "โครงร่าง",

    "Author" => "ผู้สร้าง",

    "Available" => "พร้อมใช้งาน",

    "Issue Date" => "วันที่ออก",

    "Duration" => "ระยะเวลา",

    "Change" => "เปลี่ยน",

    "Deactivate" => "ปิดใช้งาน",

    "Yes" => "ใช่",

    "Files" => "ไฟล์",

    "File" => "ไฟล์",

    "Send" => "ส่ง",

    "Paid" => "ชำระแล้ว",

    "Waiting" => "กำลังรอ",

    "Info" => "ข้อมูล",

    "Zip Code" => "รหัสไปรษณีย์",

    "Country" => "ประเทศ",

    "City" => "เมือง",

    "Submit" => "ส่ง",

    "Error" => "ข้อผิดพลาด",

    "Warning" => "คำเตือน",

    "Used" => "ใช้",

    "Join For Free" => "เข้าร่วมฟรี",

    "Enter Email" => "ป้อนอีเมล",

    "Enter Password" => "ป้อนรหัสผ่าน",

    "Enter Phone Number" => "ป้อนหมายเลขโทรศัพท์",

    "Enter Confirm Password" => "ป้อนยืนยันรหัสผ่าน",

    "Update Profile" => "อัพเดตโปรไฟล์",

    "Review" => "ตรวจทาน",

    "Log in with Facebook" => "ล็อกอินด้วย Facebook",

    "Log in with Google" => "ล็อกอินด้วย Google",

    "Or" => "หรือ",

    "Keep me up to date on WCHAT" => "ทำให้ฉันมีข้อมูลล่าสุดเกี่ยวกับ WCHAT",

    "Required" => "จำเป็น",

    "New" => "สร้างใหม่",

    "Instructor Payout" => "โครงร่างของผู้สอน",

    "Time Left" => "เวลาที่เหลือ",

    "No Item found" => "ไม่พบไอเท็ม",

    "Total Price" => "ราคารวม",

    "Discount or coupon info" => "ส่วนลดหรือข้อมูลคูปอง",

    "Checkout" => "เช็กเอาต์",

    "Apply" => "นำไปใช้",

    "Course Schedule" => "ตารางเวลาของคอร์ส",

    "Add To Cart" => "เพิ่มในรถเข็น",

    "Buy Now" => "ซื้อตอนนี้",

    "Lessons" => "บทเรียน",

    "Bookmarks" => "บุ๊กมาร์ก",

    "Deposit" => "เงินมัดจำ",

    "Referral" => "บุคคลอ้างอิง",

    "My Cart" => "รถเข็นของฉัน",

    "Purchase History" => "ประวัติการซื้อ",

    "My Courses" => "คอร์สของฉัน",

    "Live Classes" => "คลาส Live",

    "Already Enrolled" => "สมัครแล้ว",

    "Student Enrolled" => "นักเรียนที่ลงทะเบียนแล้ว",

    "Already Submitted" => "ส่งแล้ว",

    "'s Quiz" => "S การทายปัญหา",

    "Correct Answer" => "คำตอบที่ถูกต้อง",

    "Wrong Answer" => "ตอบผิด",

    "Skip" => "ข้าม",

    "Next" => "ถัดไป",

    "Previous" => "ก่อนหน้า",

    "Course File" => "ไฟล์คอร์ส",

    "Share" => "แบ่งใช้",

    "Course Files" => "ไฟล์คอร์ส",

    "Course Review" => "ตรวจทานคอร์ส",

    "Start Date & Time" => "วันที่ & เวลาเริ่มต้น",

    "At" => "ที่",

    "Show" => "แสดง",

    "Drip Content" => "เนื้อหาที่ดริส",

    "Specific Date" => "ระบุวันที่",

    "Days After Enrollment" => "จำนวนวันหลังจากการลงทะเบียน",

    "Show All" => "แสดงทั้งหมด",

    "Show After Unlock" => "แสดงหลังจากปลดล็อก",

    "Aws S3 Setting" => "ค่าติดตั้ง Aws S 3",

    "Access Key Id" => "ID คีย์การเข้าถึง",

    "Secret Key" => "คีย์ลับ",

    "Default Region" => "ภูมิภาคดีฟอลต์",

    "AWS Bucket" => "AWS Bucket",

    "Module Manager" => "ผู้จัดการโมดูล",

    "Payment Type" => "ประเภทของการชำระเงิน",

    "Blogs" => "บล็อก",

    "Star" => "ดาว",

    "Total Courses" => "วิชาทั้งหมด",

    "Discount" => "ส่วนลด",

    "Logo" => "โลโก้",

    "My Quizzes" => "แบบทดสอบของฉัน",

    "Enroll Now" => "ลงทะเบียนเดี๋ยวนี้",

    "Added To Cart" => "เพิ่มไปยัง Cart",

    "Logged In Devices" => "อุปกรณ์ที่บันทึกไว้",

    "Purchase Price" => "ราคาซื้อ",

    "Pay" => "จ่าย",

    "Welcome" => "ยินดีต้อนรับ",

    "Send Email" => "ส่งอีเมล",

    "Minimum 8 characters" => "จำนวนอักขระสูงสุด 8 ตัว",

    "Status has been changed" => "สถานะเปลี่ยนแปลงแล้ว",

    "For the demo version, you cannot change this" => "สำหรับเวอร์ชันโปรแกรมสาธิตคุณไม่สามารถเปลี่ยนได้",

    "Video File" => "ไฟล์วิดีโอ",

    "Browse Video file" => "เรียกดูไฟล์วิดีโอ",

    "Select Date" => "เลือกวันที่",

    "Days" => "วัน",

    "Operation successful" => "การดำเนินการเสร็จสมบูรณ์",

    "Operation failed" => "การดำเนินการล้มเหลว",

    "Quick Search" => "การค้นหาแบบด่วน",

    "Copy" => "คัดลอก",

    "Excel" => "เอกเซล",

    "CSV" => "CSV",

    "PDF" => "DF DF",

    "Print" => "พิมพ์",

    "No data available in the table" => "ไม่มีข้อมูลอยู่ในตาราง",

    "Successfully Assign" => "มอบหมายเสร็จเรียบร้อยแล้ว",

    "Make Paid" => "ชำระเงินการชำระเงิน",

    "Request For Paid" => "คำร้องขอสำหรับการชำระเงิน",

    "End Date & Time" => "วันที่ & เวลาสิ้นสุด",

    "Short Description" => "คำอธิบายแบบย่อ",

    "No" => "ไม่",

    "Website" => "เว็บไซต์",

    "Browse file" => "เรียกดูไฟล์",

    "Sanitize No" => "ไม่ระดับความสำคัญ",

    "Sanitize Yes" => "ใช้สุขาภิบาลใช่",

    "3DS Yes" => "3DS ใช่",

    "3DS No" => "หมายเลข 3DS",

    "Module Verification" => "ตรวจสอบโมดูล",

    "Envato Email Address" => "Envato Email Address",

    "Envato Purchase Code" => "Envato Purchase Code",

    "Verifying" => "การตรวจสอบ",

    "None" => "ไม่มี",

    "Subscription Api Key" => "คีย์ Api การสมัครสมาชิก",

    "Subscription Method" => "วิธีการสมัครสมาชิก",

    "Watch Now" => "ดูตอนนี้",

    "Continue Watch" => "ติดตามต่อ",

    "Time" => "เวลา",

    "Start" => "เริ่มต้น",

    "End" => "สิ้นสุด",

    "TimeZone" => "เขตเวลา",

    "Backup" => "สำรองข้อมูล",

    "Upload SQL File" => "อัพโหลดไฟล์ SQL",

    "Database Backup List" => "รายการสำรองข้อมูลฐานข้อมูล",

    "Generate New Backup" => "สร้างการสำรองข้อมูลใหม่",

    "File Name" => "ชื่อไฟล์",

    "Make Default" => "ทำให้เป็นค่าเริ่มต้น",

    "Theme" => "ธีม",

    "Reset To Default" => "รีเซ็ตเป็นดีฟอลต์",

    "Mode" => "โหมด",

    "Sub Title" => "หัวเรื่องย่อย",

    "view_settings" => "การตั้งค่ามุมมอง",

    "functional_settings" => "ค่าติดตั้งการทำงาน",

    "color" => "สี",

    "update" => "อัพเดต",

    "settings" => "การตั้งค่า",

    "agents" => "เอเจนต์",

    "intro_text" => "ข้อความแนะนำ",

    "single_agent" => "เอเจนต์เดี่ยว",

    "multi_agent" => "หลายเอเจนต์",

    "availability" => "ความพร้อมใช้งาน",

    "only_mobile" => "เฉพาะโมบายล์",

    "only_desktop" => "เดสก์ท็อปเท่านั้น",

    "both" => "ทั้งสองอย่าง",

    "showing_page" => "กำลังแสดงหน้า",

    "only_homepage" => "โฮมเพจเท่านั้น",

    "all_page" => "หน้าทั้งหมด",

    "popup_open_initially" => "การเปิดแบบป็อปอัพเมื่อเริ่มต้น",

    "yes" => "ใช่",

    "agent_type" => "ชนิดเอเจนต์",

    "homepage_url" => "Url โฮมเพจ",

    "no" => "ไม่",

    "whatsapp_support" => "การสนับสนุน Whats",

    "primary_number" => "หมายเลขหลัก",

    "agent" => "ตัวแทน",

    "create_agent" => "สร้างเอเจนต์",

    "update_agent" => "อัพเดต Agent",

    "number" => "หมายเลข",

    "add_agent" => "เพิ่มเอเจนต์",

    "name" => "ชื่อ",

    "designation" => "การลาออก",

    "avatar" => "ผู้อวตาร",

    "status" => "สถานะ",

    "active" => "แอ็คทีฟ",

    "inactive" => "In-แอ็คทีฟ",

    "browse_avatar" => "เรียกดู avatar",

    "always_available" => "พร้อมใช้งานเสมอ",

    "analytics" => "การวิเคราะห์",

];
