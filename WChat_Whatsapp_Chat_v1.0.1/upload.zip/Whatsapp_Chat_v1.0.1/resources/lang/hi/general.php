<?php
return [
    "rtl_ltl" => "RTL/LTL",

    "code" => "कोड",

    "search" => "ढूंढें",

    "Timetable" => "समयसारिणी",

    "System Activated Date" => "तंत्र सक्रिय दिनांक",

    "Install Domain" => "डोमेन संस्थापित करें",

    "Purchase code" => "खरीद कोड",

    "Curl Enable" => "Cl सक्षम करें",

    "PHP Version" => "पीएचपी संस्करण",

    "Check update" => "अद्यतन जाँचें",

    "Software Version" => "सॉफ्टवेयर संस्करण",

    "About System" => "सिस्टम के बारे",

    "Upload From Local Directory" => "स्थानीय निर्देशिका से अपलोड करें",

    "Update System" => "अद्यतन प्रणाली",

    "Default password will be" => "तयशुदा कूटशब्द होगा",

    "native_name" => "मूल नाम",

    "min_8" => "न्यूनतम 8 अक्षर",

    "re_type" => "फिर से टाइप करें",

    "update_system" => "अद्यतन प्रणाली",

    "key" => "कुंजी",

    "value" => "मान",

    "edit_language_info" => "भाषा जानकारी संपादित करें",

    "users" => "उपयोक्ता",

    "Whatsapp support icon position" => "Wathsapp समर्थन प्रतीक स्थिति",

    "copy_script" => "इस स्क्रिप्ट को कॉपी करें और शरीर टैग समाप्त होने से पहले अपनी वेबसाइट पर पेस्ट करें.",

    "update_user" => "अद्यतन प्रयोक्ता",

    "email" => "ईमेल",

    "language_list" => "भाषा सूची",

    "new_language" => "नई भाषा",

    "translation" => "अनुवाद",

    "create_user" => "उपयोगकर्ता बनाएँ",

    "System Settings" => "तंत्र विन्यास",

    "assign" => "सुपुर्द करना",

    "permission" => "अनुमति",

    "add_user" => "उपयोक्ता जोड़ें",

    "icon_position" => "प्रतीक स्थिति",

    "bottom_left" => "निचला बायाँ",

    "bottom_right" => "निचला दायाँ",

    "margin_from_bottom" => "तल से हाशिया",

    "margin_from_right" => "दाएँ से हाशिया",

    "margin_from_left" => "बायीं ओर से हाशिया",

    "role_permission" => "भूमिका की अनुमति",

    "start" => "प्रारंभ",

    "end" => "अंत:",

    "time" => "समय",

    "Apply All Days" => "सभी दिन लागू करें",

    "Are you sure to delete" => "क्या आप सुनिश्चित करने के लिए सुनिश्चित हैं",

    "create" => "बनाएँ",

    "select" => "चुनें",

    "with_country_code" => "देश कोड के साथ अनिवार्य है",

    "welcome_message" => "संदेश स्वागत",

    "your_scripts" => "आपकी स्क्रिप्ट्स",

    "Login" => "लॉगइन",

    "View Profile" => "प्रोफ़ाइल देखें",

    "My Profile" => "मेरा प्रोफ़ाइल",

    "Profile Settings" => "प्रोफ़ाइल विन्यास",

    "Current" => "वर्तमान",

    "Re-Type Password" => "फिर से कूटशब्द",

    "Type Password" => "पासवर्ड टाइप करें",

    "Remember Me" => "मुझे याद रखें",

    "Login Details" => "लॉगिन विवरण",

    "Forget Password ?" => "पासवर्ड भूल गए?",

    "Need an account?" => "खाता की आवश्यकता है?",

    "Sign Up" => "साइन अप करें",

    "Sign Up Details" => "साइन अप विवरण",

    "You have already an account?" => "आप पहले से ही खाता है?",

    "Send Reset Link" => "रीसेट लिंक भेजें",

    "Reset Password" => "कूटशब्द रीसेट करें",

    "Reset" => "रीसेट करें",

    "Set New Password" => "नया पासवर्ड सेट करें",

    "Set Password" => "पासवर्ड सेट करें",

    "Start From" => "से प्रारंभ करें",

    "Start At" => "पर प्रारंभ करें",

    "To" => "के लिए",

    "Free" => "मुक्त",

    "Off" => "बंद",

    "On" => "पर",

    "Social Link" => "सामाजिक लिंक",

    "Active Status" => "सक्रिय स्थिति",

    "Language List" => "भाषा सूची",

    "Choose File" => "फ़ाइल चुनें",

    "Translation" => "अनुवाद",

    "Currency" => "मुद्रा",

    "Add New" => "नया जोड़ें",

    "ID" => "आईडी",

    "Title" => "शीर्षक",

    "Details" => "विवरण",

    "Name" => "नाम",

    "Action" => "क्रिया",

    "Edit" => "संपादित करें",

    "Delete" => "मिटाएँ",

    "Select" => "चुनें",

    "Save" => "सहेजें",

    "Update" => "अद्यतन",

    "Live" => "जीना",

    "Sandbox" => "सैंडबॉक्स",

    "Something Went Wrong" => "कुछ गलत हो गया",

    "Description" => "वर्णन",

    "Model" => "मॉडल",

    "Attempted At" => "पर प्रयास किया",

    "User" => "उपयोक्ता",

    "Activity Logs" => "गतिविधि लॉग",

    "Type" => "क़िस्म",

    "Delete Confirmation" => "पुष्टि मिटाएँ (D)",

    "Human Resource" => "मानव संसाधन",

    "Staff" => "स्टाफ",

    "Staff List" => "स्टाफ सूची",

    "Username" => "उपयोक्ता नाम",

    "Email" => "ईमेल",

    "Phone" => "फोन",

    "Registered Date" => "पंजीकृत तिथि",

    "Status" => "स्थिति",

    "URL" => "यूआरएल",

    "Register" => "रजिस्टर",

    "Remove" => "हटाएँ",

    "Staff Id" => "स्टाफ आईडी",

    "Password" => "पासवर्ड",

    "Confirm Password" => "कूटशब्द पुष्टि करें",

    "Re-Password" => "फिर से कूटशब्द",

    "Browse" => "ब्राउज़ करें",

    "Avatar" => "अवतार",

    "Edit Staff Info" => "स्टाफ जानकारी संपादित करें",

    "Staff info has been updated Successfully" => "स्टाफ सूचना को सफलतापूर्वक अद्यतन किया गया है",

    "Staff has been added Successfully" => "स्टाफ को सफलतापूर्वक जोड़ा गया है ।",

    "View" => "दृश्य",

    "Staff Info" => "स्टाफ जानकारी",

    "Close" => "बंद करें",

    "Staff ID" => "स्टाफ आईडी",

    "Password did not match with your account password." => "पासवर्ड आपके खाते के पासवर्ड के साथ मेल नहीं खाता है.",

    "Put Your password" => "अपना कूट-शब्द रखो",

    "Staff has been deleted Successfully" => "स्टाफ को सफलतापूर्वक नष्ट कर दिया गया है",

    "Language" => "भाषा",

    "Variant" => "वेरिएंट",

    "Add Variant" => "वेरिएंट जोड़ें",

    "Publish" => "प्रकाशित करें",

    "Published" => "प्रकाशित",

    "Variation Values" => "विविधता मूल्य",

    "Add Value" => "मान जोड़ें",

    "Edit Variant" => "वेरिएंट संपादित करें",

    "Unit Type" => "इकाई प्रकार",

    "Add Unit Type" => "इकाई प्रकार जोड़ें",

    "Edit Unit Type" => "इकाई क़िस्म संपादित करें",

    "Brand" => "ब्रांड",

    "Add Brand" => "ब्रांड जोड़ें",

    "Edit Brand" => "ब्रांड संपादित करें",

    "Add Model" => "मॉडल जोड़ें",

    "Edit Model" => "मॉडल संपादित करें",

    "Category" => "श्रेणी",

    "Add Category" => "श्रेणी जोड़ें",

    "Code" => "कोड",

    "Add as Sub Category" => "उप श्रेणी के रूप में जोड़ें",

    "Select parent Category" => "जनक श्रेणी चुनें",

    "Edit Category" => "श्रेणी संपादित करें",

    "Add New Product" => "नया उत्पाद जोड़ें",

    "Product Name" => "उत्पाद नाम",

    "Product SKU" => "उत्पाद SKU",

    "Barcode Type" => "बारकोड प्रकार",

    "Unit" => "इकाई",

    "Sub Category" => "उप श्रेणी",

    "Add File" => "फ़ाइल जोड़ें",

    "Manage Stock" => "स्टॉक प्रबंधित करें",

    "Alert Quantity" => "सचेत मात्रा",

    "Variation" => "विभिन्नता",

    "Add Variation" => "भिन्नता जोड़ें",

    "Add Product" => "उत्पाद जोड़ें",

    "Edit Product" => "उत्पाद संपादित करें",

    "Employee Id" => "कर्मचारी आईडी",

    "Address" => "पता",

    "New Price Group" => "नया मूल्य समूह",

    "Export" => "निर्यात",

    "SL" => "एसएल",

    "Cancel" => "रद्द करें",

    "About" => "लगभग",

    "letter" => "पत्र",

    "date" => "तारीख",

    "Date" => "तिथि",

    "Image" => "छवि",

    "File Not Found" => "फ़ाइल नहीं मिला",

    "Download" => "डाउनलोड करें",

    "Are you sure to delete ?" => "क्या आप डिलीट कर रहे हैं?",

    "Are you sure to" => "क्या आप सुनिश्चित हैं कि",

    "Are you sure to enable this ?" => "क्या आप यह सक्षम करने के लिए सुनिश्चित हैं?",

    "Are You Sure To Change Status ?" => "क्या आप स्थिति बदलने के लिए सुनिश्चित हैं?",

    "Are You Sure To Remove This?" => "क्या आप सुनिश्चित हैं कि यह हटाने के लिए है?",

    "Role" => "भूमिका",

    "List" => "सूची",

    "Add" => "जोड़ें",

    "Success" => "सफलता",

    "Failed" => "असफल",

    "Dashboard" => "डैशबोर्ड",

    "User Logs" => "उपयोक्ता लॉग",

    "Question & Answer" => "प्रश्न और उत्तर",

    "Comments" => "टिप्पणी",

    "Course" => "कोर्स",

    "Replies" => "जवाब",

    "Commented By" => "द्वारा टिप्पणी",

    "Submitted" => "प्रस्तुत",

    "Enable" => "सक्षम करें",

    "Disable" => "निष्क्रिय करें",

    "Active" => "सक्रिय",

    "Deactive" => "निष्क्रिय",

    "Inactive" => "निष्क्रिय",

    "Email Address" => "ईमेल पता",

    "Instagram URL" => "इंस्टाग्राम यूआरएल",

    "Youtube URL" => "यूट्यूब URL",

    "LinkedIn URL" => "लिंकेडेइन यूआरएल",

    "Twitter URL" => "ट्वीटर यूआरएल",

    "Facebook URL" => "फेसबुक URL",

    "Date of Birth" => "जन्म तिथि",

    "Change Status" => "स्थिति बदलें",

    "Start Date" => "प्रारंभ तिथि",

    "End Date" => "समाप्ति तिथि",

    "Filter History" => "इतिहास फिल्टर",

    "Reject" => "अस्वीकार करें",

    "Reason" => "कारण",

    "Payouts" => "पायआउट",

    "Author" => "लेखक",

    "Available" => "उपलब्ध",

    "Issue Date" => "तिथि जारी करें",

    "Duration" => "अवधि",

    "Change" => "परिवर्तन",

    "Deactivate" => "निष्क्रिय करें",

    "Yes" => "हाँ",

    "Files" => "फ़ाइलें",

    "File" => "फ़ाइल",

    "Send" => "भेजें",

    "Paid" => "प्रदत्त",

    "Waiting" => "प्रतीक्षारत",

    "Info" => "जानकारी",

    "Zip Code" => "ज़िप कोड",

    "Country" => "देश",

    "City" => "शहर",

    "Submit" => "सबमिट",

    "Error" => "त्रुटि",

    "Warning" => "चेतावनी",

    "Used" => "प्रयुक्त",

    "Join For Free" => "मुक्त के लिए शामिल हों",

    "Enter Email" => "ईमेल दर्ज करें",

    "Enter Password" => "कूटशब्द दाखिल करें",

    "Enter Phone Number" => "फोन नंबर भरें",

    "Enter Confirm Password" => "कूटशब्द दाखिल करें",

    "Update Profile" => "प्रोफ़ाइल अद्यतन करें",

    "Review" => "समीक्षा",

    "Log in with Facebook" => "फेसबुक के साथ लॉग इन करें",

    "Log in with Google" => "गूगल के साथ लॉग इन करें",

    "Or" => "या",

    "Keep me up to date on WCHAT" => "मुझे इनफिक्स करने के लिए डेट पर रखें",

    "Required" => "आवश्यक",

    "New" => "नया",

    "Instructor Payout" => "अनुदेशक पाबाहर",

    "Time Left" => "बायाँ समय",

    "No Item found" => "कोई मद नहीं मिला",

    "Total Price" => "कुल मूल्य",

    "Discount or coupon info" => "छूट या कूपन जानकारी",

    "Checkout" => "चेकआउट",

    "Apply" => "लागू करें",

    "Course Schedule" => "कोर्स अनुसूची",

    "Add To Cart" => "कार्ट में जोड़ें",

    "Buy Now" => "अब खरीदें",

    "Lessons" => "पाठन",

    "Bookmarks" => "पसंद",

    "Deposit" => "जमा करना",

    "Referral" => "रेफर",

    "My Cart" => "मेरी गाड़ी",

    "Purchase History" => "क्रय इतिहास",

    "My Courses" => "मेरे पाठ्यक्रम",

    "Live Classes" => "लाइव क्लासेस",

    "Already Enrolled" => "नामांकित हो चुका है",

    "Student Enrolled" => "विद्यार्थी नामांकित",

    "Already Submitted" => "पहले से ही प्रस्तुत किया",

    "'s Quiz" => "के-क्विज",

    "Correct Answer" => "सही उत्तर",

    "Wrong Answer" => "गलत उत्तर",

    "Skip" => "छोड़ें",

    "Next" => "अगला",

    "Previous" => "पिछला",

    "Course File" => "कोर्स फ़ाइल",

    "Share" => "साझा करें",

    "Course Files" => "कोर्स फ़ाइलें",

    "Course Review" => "कोर्स की समीक्षा",

    "Start Date & Time" => "तिथि व समय प्रारंभ करें",

    "At" => "पर",

    "Show" => "दिखाएँ",

    "Drip Content" => "ड्रिप सामग्री",

    "Specific Date" => "विशिष्ट दिनांक",

    "Days After Enrollment" => "नामांकन के कुछ दिन बाद",

    "Show All" => "सभी दिखाएँ",

    "Show After Unlock" => "अनलॉक करने के बाद दिखाएँ",

    "Aws S3 Setting" => "के बारे में S3 सेटिंग",

    "Access Key Id" => "पहुँच कुंजी Id",

    "Secret Key" => "गुप्त कुंजी",

    "Default Region" => "डिफ़ॉल्ट क्षेत्र",

    "AWS Bucket" => "एडब्ल्यूएस बाल्टी",

    "Module Manager" => "मॉड्यूल प्रबंधक",

    "Payment Type" => "भुगतान प्रकार",

    "Blogs" => "चिट्ठों",

    "Star" => "ताराकार",

    "Total Courses" => "कुल पाठ्यक्रम",

    "Discount" => "बट्टा",

    "Logo" => "लोगो",

    "My Quizzes" => "मेरी क्विज़ेज़",

    "Enroll Now" => "अब नामांकन",

    "Added To Cart" => "गाड़ी में जोड़ा गया",

    "Logged In Devices" => "उपकरणों में लॉग इन करें",

    "Purchase Price" => "क्रय मूल्य",

    "Pay" => "वेतन",

    "Welcome" => "स्वागतयोग्य",

    "Send Email" => "ईमेल भेजें",

    "Minimum 8 characters" => "न्यूनतम 8 अक्षर",

    "Status has been changed" => "प्रस्थिति बदल दिया गया है",

    "For the demo version, you cannot change this" => "डेमो संस्करण के लिए, आप यह नहीं बदल सकते हैं",

    "Video File" => "वीडियो फ़ाइल",

    "Browse Video file" => "वीडियो फ़ाइल ब्राउज़ करें",

    "Select Date" => "तिथि चुनें",

    "Days" => "दिन",

    "Operation successful" => "ऑपरेशन सफल",

    "Operation failed" => "ऑपरेशन असफल",

    "Quick Search" => "त्वरित खोज",

    "Copy" => "नक़ल",

    "Excel" => "एक्सेल",

    "CSV" => "CSV",

    "PDF" => "पीडीएफ़",

    "Print" => "छापें",

    "No data available in the table" => "तालिका में कोई डेटा उपलब्ध नहीं",

    "Successfully Assign" => "सफलतापूर्वक आबंटित",

    "Make Paid" => "भुगतान किया",

    "Request For Paid" => "भुगतान के लिए अनुरोध",

    "End Date & Time" => "तारीख़ व समय समाप्त करें",

    "Short Description" => "संक्षिप्त विवरण",

    "No" => "नहीं",

    "Website" => "वेबसाइट",

    "Browse file" => "फ़ाइल ब्राउज़ करें",

    "Sanitize No" => "सैनिटिज़े",

    "Sanitize Yes" => "Santizze हाँ",

    "3DS Yes" => "3DS हाँ",

    "3DS No" => "3DS कोई",

    "Module Verification" => "मॉड्यूल सत्यापन",

    "Envato Email Address" => "लि. ईमेल पता",

    "Envato Purchase Code" => "लि. तो खरीद कोड",

    "Verifying" => "सत्यापित करें",

    "None" => "कुछ नहीं",

    "Subscription Api Key" => "सब्सक्रिप्शन Api कुंजी",

    "Subscription Method" => "सदस्यता विधि",

    "Watch Now" => "अभी देखो",

    "Continue Watch" => "जारी रखें",

    "Time" => "समय",

    "Start" => "प्रारंभ",

    "End" => "अंत:",

    "TimeZone" => "समय क्षेत्र",

    "Backup" => "बैकअप",

    "Upload SQL File" => "एसक्यूएल फ़ाइल अपलोड करें",

    "Database Backup List" => "डाटाबेस बैकअप सूची",

    "Generate New Backup" => "नया बैकअप बनाएँ",

    "File Name" => "फ़ाइल नाम",

    "Make Default" => "डिफ़ॉल्ट बनाएँ",

    "Theme" => "प्रसंग",

    "Reset To Default" => "डिफ़ॉल्ट पर रीसेट करें",

    "Mode" => "मोड",

    "Sub Title" => "उप शीर्षक",

    "view_settings" => "दृश्य विन्यास",

    "functional_settings" => "कार्यात्मक विन्यास",

    "color" => "रंग",

    "update" => "अद्यतन",

    "settings" => "विन्यास",

    "agents" => "एजेंट",

    "intro_text" => "परिचय पाठ",

    "single_agent" => "एकल एजेंट",

    "multi_agent" => "एकाधिक एजेंट",

    "availability" => "उपलब्धता",

    "only_mobile" => "केवल मोबाइल",

    "only_desktop" => "सिर्फ डेस्कटॉप",

    "both" => "दोनों",

    "showing_page" => "पृष्ठ प्रदर्शित करें",

    "only_homepage" => "सिर्फ होम पेज",

    "all_page" => "सभी पृष्ठ",

    "popup_open_initially" => "प्रारंभ प्रारंभ में पॉपअप खोलें",

    "yes" => "हाँ",

    "agent_type" => "एजेंट प्रकार",

    "homepage_url" => "होम पृष्ठ यूआरएल",

    "no" => "नहीं",

    "whatsapp_support" => "WathsApp समर्थन",

    "primary_number" => "प्राथमिक संख्या",

    "agent" => "एजेंट",

    "create_agent" => "एजेंट बनाएँ",

    "update_agent" => "अपडेट एजेंट",

    "number" => "संख्या",

    "add_agent" => "एजेंट जोड़ें",

    "name" => "नाम",

    "designation" => "पदनाम",

    "avatar" => "अवतार",

    "status" => "स्थिति",

    "active" => "सक्रिय",

    "inactive" => "में-सक्रिय",

    "browse_avatar" => "अवतार ब्राउज़ करें",

    "always_available" => "हमेशा उपलब्ध",

    "analytics" => "विश्लेषणात्मक",

    "layout_settings" => "अभिन्यास विन्यास",

    "choose_layout" => "खाका चुनें",

    "show_unavailable_agent_in_popup" => "पॉपअप में अनुपलब्ध एजेंट दिखाएँ",

    "id" => "आईडी",

    "ip" => "आईपी",

    "browser" => "ब्राउज़र",

    "operating_system" => "प्रचालन तंत्र",

    "messages" => "संदेश",

    "total_click" => "कुल क्लिक",

    "clicks" => "क्लिक्स",

    "click_from_mobile" => "मोबाइल से क्लिक करें",

    "click_from_desktop" => "डेस्कटॉप से क्लिक करें",

    "action" => "क्रिया",

];
