<?php
return [
    "Edit Timezone Info" => "Sunting Info Zona Waktu",

    "Timezone has been deleted Successfully" => "Zona waktu telah dihapus dengan sukses",

    "login" => "Login",

    "view_settings" => "Pengaturan Tampilan",

    "functional_settings" => "Pengaturan Fungsional",

    "color" => "Warna",

    "update" => "Perbarui",

    "settings" => "Pengaturan",

    "agents" => "Agen",

    "intro_text" => "Teks Pengantar",

    "single_agent" => "Agen Tunggal",

    "multi_agent" => "Beberapa Agen",

    "availability" => "Ketersediaan",

    "only_mobile" => "Hanya Mobile",

    "only_desktop" => "Hanya Desktop",

    "both" => "Dua-duanya",

    "showing_page" => "Menampilkan halaman",

    "only_homepage" => "Hanya Halaman Beranda",

    "all_page" => "Semua Halaman",

    "popup_open_initially" => "Popup Buka Awalnya",

    "yes" => "Iya.",

    "agent_type" => "Tipe Agen",

    "homepage_url" => "Url Halaman Beranda",

    "no" => "Tidak ada",

    "whatsapp_support" => "WhatsApp Support",

    "primary_number" => "Nomor Primer",

    "agent" => "Agen",

    "create_agent" => "Buat Agen",

    "update_agent" => "Perbarui Agen",

    "number" => "Nomor",

    "add_agent" => "Tambah Agen",

    "name" => "Nama",

    "designation" => "Penetapan",

    "avatar" => "Avatar",

    "status" => "Status",

    "active" => "Aktif",

    "inactive" => "Di-Aktif",

    "browse_avatar" => "Browse Avatar",

    "always_available" => "Selalu Tersedia",

    "analytics" => "Analitik",

    "layout_settings" => "Pengaturan Tata Letak",

    "choose_layout" => "Pilih Tata Letak",

    "show_unavailable_agent_in_popup" => "Tampilkan agen yang tidak tersedia di popup",

    "id" => "ID",

    "ip" => "IP",

    "browser" => "Peramban",

    "operating_system" => "Sistem Operasi",

    "messages" => "Pesan",

    "total_click" => "Klik Total",

    "clicks" => "Klik",

    "click_from_mobile" => "Klik Dari Mobile",

    "click_from_desktop" => "Klik Dari Desktop",

    "action" => "Aksi",

    "rtl_ltl" => "RTL/LTL",

    "code" => "Kode",

    "Default password will be" => "Sandi default akan",

    "native_name" => "Nama Asli",

    "key" => "Kunci",

    "value" => "Nilai",

    "edit_language_info" => "Sunting Info Bahasa",

    "users" => "Pengguna",

    "Whatsapp support icon position" => "Posisi ikon dukungan whatsapp",

    "copy_script" => "Salin script ini dan tempelkan ke situs web Anda sebelum tag tubuh berakhir.",

    "update_user" => "Perbarui",

    "email" => "Surel",

    "language_list" => "Daftar Bahasa",

    "new_language" => "Bahasa Baru",

    "translation" => "Translasi",

    "create_user" => "Buat Pengguna",

    "System Settings" => "Pengaturan Sistem",

    "assign" => "Tetapkan",

    "permission" => "Izin",

    "add_user" => "Tambah Pengguna",

    "icon_position" => "Posisi Ikon Whatsapp",

    "bottom_left" => "Kiri Bawah",

    "bottom_right" => "Kanan Bawah",

    "margin_from_bottom" => "Marjin Dari Bawah",

    "margin_from_right" => "Marjin Dari Kanan",

    "margin_from_left" => "Marjin Dari Kiri",

    "role_permission" => "Izin Peran",

    "start" => "Mulai",

    "end" => "Akhir",

    "time" => "Waktu",

    "Apply All Days" => "Terapkan Semua Hari",

    "Are you sure to delete" => "Apakah Anda yakin untuk menghapus file ini?",

    "create" => "Buat",

    "select" => "Pilih",

    "with_country_code" => "Dengan Kode Negara harus",

    "welcome_message" => "Pesan Selamat Datang",

    "your_scripts" => "Skrip Anda",

    "Login" => "Log Masuk",

    "View Profile" => "Lihat Profil",

    "My Profile" => "Profil Saya",

    "Profile Settings" => "Pengaturan Profil",

    "Current" => "Saat ini",

    "Re-Type Password" => "Ulang Tipe Kata Sandi",

    "Type Password" => "Ketik Kata Sandi",

    "Remember Me" => "Ingat Saya",

    "Login Details" => "Detail Login",

    "Forget Password ?" => "Lupa Sandi?",

    "Need an account?" => "Perlu akun?",

    "Sign Up" => "Sign Up",

    "Sign Up Details" => "Tanda Tanda:",

    "You have already an account?" => "Kau sudah punya akun?",

    "Send Reset Link" => "Kirim Link Reset",

    "Reset Password" => "Reset Kata Sandi",

    "Reset" => "Atur Ulang",

    "Set New Password" => "Atur Kata Sandi Baru",

    "Set Password" => "Atur Kata Sandi",

    "Start From" => "Mulai Dari",

    "Start At" => "Mulai Pada",

    "To" => "Untuk",

    "Free" => "Bebas",

    "Off" => "Off",

    "On" => "Pada",

    "Social Link" => "Tautan Sosial",

    "Active Status" => "Status Aktif",

    "Language List" => "Daftar Bahasa",

    "Choose File" => "Pilih Berkas",

    "Translation" => "Translasi",

    "Currency" => "Mata Uang",

    "Add New" => "Tambah Baru",

    "ID" => "ID",

    "Title" => "Judul",

    "Details" => "Detailnya",

    "Name" => "Nama",

    "Action" => "Aksi",

    "Edit" => "Sunting",

    "Delete" => "Hapus",

    "Select" => "Pilih",

    "Save" => "Simpan",

    "Update" => "Perbarui",

    "Live" => "Hiduplah",

    "Sandbox" => "Kotak pasir",

    "Something Went Wrong" => "Ada Sesuatu Yang Salah.",

    "Description" => "Deskripsi",

    "Model" => "Model",

    "Attempted At" => "Diupayakan",

    "User" => "Pengguna",

    "Activity Logs" => "Log Aktivitas",

    "Type" => "Tipe",

    "Delete Confirmation" => "Hapus Konfirmasi",

    "Human Resource" => "Sumber Daya Manusia",

    "Staff" => "Staf",

    "Staff List" => "Daftar Staf",

    "Username" => "Nama pengguna",

    "Email" => "Surel",

    "Phone" => "Telepon",

    "Registered Date" => "Tanggal Terdaftar",

    "Status" => "Status",

    "URL" => "URL",

    "Register" => "Register",

    "Remove" => "Hapus",

    "Staff Id" => "ID staf",

    "Password" => "Kata Sandi",

    "Confirm Password" => "Konfirmasi Kata Sandi",

    "Re-Password" => "Ulang Kata Sandi",

    "Browse" => "Telusuri",

    "Avatar" => "Avatar",

    "Edit Staff Info" => "Sunting Info Staf",

    "Staff info has been updated Successfully" => "Informasi staf telah diperbarui dengan sukses.",

    "Staff has been added Successfully" => "Staf telah ditambahkan.",

    "View" => "Tilik",

    "Staff Info" => "Info Staf",

    "Close" => "Tutup",

    "Staff ID" => "ID staf",

    "Password did not match with your account password." => "Sandi tidak cocok dengan kata sandi akun Anda.",

    "Put Your password" => "Masukkan kata sandi Anda",

    "Staff has been deleted Successfully" => "Staf telah dihapus.",

    "Language" => "Bahasa",

    "Variant" => "Varian",

    "Add Variant" => "Tambah Varian",

    "Publish" => "Terbitkan",

    "Published" => "Dipublikasikan",

    "Variation Values" => "Nilai Variasi",

    "Add Value" => "Tambah Nilai",

    "Edit Variant" => "Sunting Varian",

    "Unit Type" => "Unit Tipe",

    "Add Unit Type" => "Tambah Tipe Unit",

    "Edit Unit Type" => "Sunting Tipe Unit",

    "Brand" => "Merek",

    "Add Brand" => "Tambah Merek",

    "Edit Brand" => "Sunting Merek",

    "Add Model" => "Tambah Model",

    "Edit Model" => "Sunting Model",

    "Category" => "Kategori",

    "Add Category" => "Tambah Kategori",

    "Code" => "Kode",

    "Add as Sub Category" => "Tambahkan sebagai Sub Kategori",

    "Select parent Category" => "Pilih kategori induk",

    "Edit Category" => "Sunting Kategori",

    "Add New Product" => "Tambah Produk Baru",

    "Product Name" => "Nama Produk:",

    "Product SKU" => "SKU Produk",

    "Barcode Type" => "Tipe Barcode",

    "Unit" => "Unit",

    "Sub Category" => "Sub Kategori",

    "Add File" => "Tambah File",

    "Manage Stock" => "Kelola Stok",

    "Alert Quantity" => "Jumlah Peringatan",

    "Variation" => "Variasi",

    "Add Variation" => "Tambah Variasi",

    "Add Product" => "Tambah Produk",

    "Edit Product" => "Sunting Produk",

    "Employee Id" => "ID Karyawan:",

    "Address" => "Alamat",

    "New Price Group" => "Grup Harga Baru",

    "Export" => "Ekspor",

    "SL" => "SL",

    "Cancel" => "Batalkan",

    "About" => "Tentang",

    "letter" => "Surat",

    "date" => "Tanggal",

    "Date" => "Tanggal",

    "Image" => "Gambar",

    "File Not Found" => "Berkas Tidak Ditemukan",

    "Download" => "Unduh",

    "Are you sure to delete ?" => "Apakah Anda yakin akan menghapus?",

    "Are you sure to" => "Apakah Anda yakin",

    "Are you sure to enable this ?" => "Apakah kau yakin untuk mengaktifkan ini?",

    "Are You Sure To Change Status ?" => "Apakah Anda Yakin Untuk Mengubah Status?",

    "Are You Sure To Remove This?" => "Apakah Anda Yakin Untuk Menghapus Ini?",

    "Role" => "Peran",

    "List" => "Daftar",

    "Add" => "Tambahkan",

    "Success" => "Sukses",

    "Failed" => "Gagal",

    "Dashboard" => "Dasbor",

    "User Logs" => "Log Pengguna",

    "Question & Answer" => "Pertanyaan & Jawaban",

    "Comments" => "Komentar",

    "Course" => "Kursus",

    "Replies" => "Balasan",

    "Commented By" => "Dikomentari Oleh",

    "Submitted" => "Diwakilkan",

    "Enable" => "Fungsikan",

    "Disable" => "Nonaktifkan",

    "Active" => "Aktif",

    "Deactive" => "Deaktif",

    "Inactive" => "Tidak aktif",

    "Email Address" => "Alamat Email:",

    "Instagram URL" => "URL Instagram",

    "Youtube URL" => "URL youtube",

    "LinkedIn URL" => "LinkedIn URL",

    "Twitter URL" => "URL Twitter",

    "Facebook URL" => "URL Facebook",

    "Date of Birth" => "Tanggal lahir",

    "Change Status" => "Ubah Status",

    "Start Date" => "Mulai Tanggal Mulai",

    "End Date" => "Tanggal Berakhir",

    "Filter History" => "Filter Riwayat",

    "Reject" => "Tolak",

    "Reason" => "Alasan",

    "Payouts" => "Pembayaran",

    "Author" => "Penulis",

    "Available" => "Tersedia",

    "Issue Date" => "Tanggal Masalah",

    "Duration" => "Durasi",

    "Change" => "Ubah",

    "Deactivate" => "Nonaktifkan",

    "Yes" => "Iya.",

    "Files" => "Berkas",

    "File" => "Berkas",

    "Send" => "Kirim",

    "Paid" => "Dibayar",

    "Waiting" => "Menunggu",

    "Info" => "Info",

    "Zip Code" => "Kode Zip",

    "Country" => "Negara",

    "City" => "Kota",

    "Submit" => "Kirim",

    "Error" => "Galat",

    "Warning" => "Peringatan",

    "Used" => "Digunakan",

    "Join For Free" => "Bergabung Untuk Bebas",

    "Enter Email" => "Masukkan Email",

    "Enter Password" => "Masukkan Kata Sandi",

    "Enter Phone Number" => "Masukkan Nomor Telepon",

    "Enter Confirm Password" => "Masukkan Kata Sandi Konfirmasi",

    "Update Profile" => "Perbarui Profil",

    "Review" => "Tinjum",

    "Log in with Facebook" => "Log in dengan Facebook",

    "Log in with Google" => "Log in dengan Google",

    "Or" => "Atau",

    "Keep me up to date on WCHAT" => "Keep me up to date on WCHAT",

    "Required" => "Diperlukan",

    "New" => "Baru",

    "Instructor Payout" => "Instruktur Payout",

    "Time Left" => "Waktu Tersisa",

    "No Item found" => "Item tidak ditemukan",

    "Total Price" => "Total Harga",

    "Discount or coupon info" => "Informasi diskon atau kupon",

    "Checkout" => "Checkout",

    "Apply" => "Terapkan",

    "Course Schedule" => "Jadwal Kursus",

    "Add To Cart" => "Tambahkan Ke Keranjang Belanja",

    "Buy Now" => "Beli Sekarang",

    "Lessons" => "Pelajaran",

    "Bookmarks" => "Markah",

    "Deposit" => "Deposit",

    "Referral" => "Rujukan?",

    "My Cart" => "Keranjang Saya",

    "Purchase History" => "Riwayat Pembelian",

    "My Courses" => "Kursus Saya",

    "Live Classes" => "Kelas Hidup",

    "Already Enrolled" => "Sudah Terdaftar",

    "Student Enrolled" => "Siswa Terdaftar",

    "Already Submitted" => "Sudah Diajukan",

    "Correct Answer" => "Jawaban Benar",

    "Wrong Answer" => "Jawaban salah",

    "Skip" => "Lewati",

    "Next" => "Berikutnya",

    "Previous" => "Sebelumnya",

    "Course File" => "Berkas Course",

    "Share" => "Bagikan",

    "Course Files" => "Berkas Course",

    "Course Review" => "Tinjauan Kursus",

    "Start Date & Time" => "Mulai Tanggal & Waktu",

    "At" => "Pada pukul",

    "Show" => "Tampilkan",

    "Drip Content" => "Konten drip",

    "Specific Date" => "Tanggal Spesifik",

    "Days After Enrollment" => "Hari Setelah Pendaftaran",

    "Show All" => "Tampilkan Semua",

    "Show After Unlock" => "Tampilkan Setelah Membuka Kunci",

    "Aws S3 Setting" => "Pengaturan Aws S3",

    "Access Key Id" => "Akses Kunci Akses",

    "Secret Key" => "Kunci Rahasia",

    "Default Region" => "Daerah Standar",

    "AWS Bucket" => "AWS Bucket",

    "Module Manager" => "Manajer Modul",

    "Payment Type" => "Tipe Pembayaran",

    "Blogs" => "Blog",

    "Star" => "Bintang",

    "Total Courses" => "Total Kursus",

    "Discount" => "Diskon",

    "Logo" => "Logo",

    "My Quizzes" => "Quizzes-ku",

    "Enroll Now" => "Enroll Sekarang",

    "Added To Cart" => "Ditambahkan Ke Keranjang",

    "Logged In Devices" => "Di Divais Di Perangkat",

    "Purchase Price" => "Harga pembelian",

    "Pay" => "Bayar",

    "Welcome" => "Selamat Datang",

    "Send Email" => "Kirim Email",

    "Minimum 8 characters" => "Minimum 8 karakter",

    "Status has been changed" => "Status telah diubah",

    "For the demo version, you cannot change this" => "Untuk versi demo, Anda tidak dapat mengubah",

    "Video File" => "Berkas Video",

    "Browse Video file" => "Telusuri berkas Video",

    "Select Date" => "Pilih Tanggal",

    "Days" => "Hari",

    "Operation successful" => "Operasi berhasil",

    "Operation failed" => "Operasi gagal",

    "Quick Search" => "Pencarian Cepat",

    "Copy" => "Salin",

    "Excel" => "Excel",

    "CSV" => "CSV",

    "PDF" => "PDF",

    "Print" => "Cetak",

    "No data available in the table" => "Tidak ada data yang tersedia di dalam tabel",

    "Successfully Assign" => "Berhasil Menetapkan",

    "Make Paid" => "Buat Dibayar",

    "Request For Paid" => "Permintaan Untuk Dibayar",

    "End Date & Time" => "Tanggal Akhir & Waktu",

    "Short Description" => "Deskripsi Pendek",

    "No" => "Tidak ada",

    "Website" => "Situs web",

    "Browse file" => "Telusuri berkas",

    "Sanitize No" => "Sanitize Tidak",

    "Sanitize Yes" => "Sanitize Ya",

    "3DS Yes" => "3DS Ya",

    "3DS No" => "3DS Tidak",

    "Module Verification" => "Verifikasi Modul",

    "Envato Email Address" => "Alamat Email Envato",

    "Envato Purchase Code" => "Kode Pembelian Envato",

    "Verifying" => "Verifikasi",

    "None" => "Tidak ada",

    "Subscription Api Key" => "Kunci Api Berlangganan",

    "Subscription Method" => "Metode Berlangganan",

    "Watch Now" => "Tonton Sekarang",

    "Continue Watch" => "Lanjutkan Menonton",

    "Time" => "Waktu",

    "Start" => "Mulai",

    "End" => "Akhir",

    "TimeZone" => "Zona Waktu",

    "Backup" => "Backup",

    "Upload SQL File" => "Unggah file SQL",

    "Database Backup List" => "Daftar Cadangan Basis Data",

    "Generate New Backup" => "Buat Backup Baru",

    "File Name" => "Nama Berkas",

    "Make Default" => "Buat Standar",

    "Theme" => "Tema",

    "Reset To Default" => "Atur Ulang Ke Standar",

    "Mode" => "Mode",

    "Sub Title" => "Sub Judul",

    "search" => "Cari",

    "Timetable" => "Tabel Waktu",

    "System Activated Date" => "Tanggal Diaktifkan Sistem",

    "Install Domain" => "Instal Domain",

    "Purchase code" => "Kode pembelian",

    "Curl Enable" => "Curl Aktifkan",

    "PHP Version" => "Versi PHP",

    "Check update" => "Periksa pemutakhiran",

    "Software Version" => "Versi Perangkat Lunak",

    "About System" => "Tentang Sistem",

    "Upload From Local Directory" => "Unggah Dari Direktori Lokal",

    "Update System" => "Pembaruan Sistem",

    "min_8" => "Karakter minimum 8",

    "re_type" => "Tipe Ulang",

    "update_system" => "Pembaruan Sistem",

    "general_settings" => "Pengaturan Umum",

    "Timezone Name" => "Nama Zona Waktu",

    "Timezone Code" => "Kode zona waktu",

    "Advanced Filter" => "Filter Lanjutan",

    "upload" => "Unggahan",

    "change_logo" => "Ubah Logo",

    "change_fav" => "Ubah Fav",

    "Delete confirmation message" => "Hapus pesan konfirmasi",

    "assign_permission" => "Tetapkan Izin",

    "user" => "Pengguna",

    "role" => "Peran",

    "total_user" => "Total Pengguna",

    "total_agent" => "Total Agen",

    "Unique Guest User" => "Pengguna Tamu yang Unik",

    "Filter" => "Filter",

    "Timezone List" => "Daftar Zona Waktu",

    "submit" => "Kirim",

    "Quiz" => "Kuis",

    "Email Configuration" => "Konfigurasi Email",

    "Send Test Mail" => "Kirim Surat Tes",

    "Send a Test Email to" => "Kirim Email Tes ke",

    "Predefined Footer" => "Footer yang Ditentukan",

    "Predefined Header" => "Header Yang Ditentukan Sebelumnya",

    "Email Signature" => "Tanda Tangan Email",

    "Sender Email" => "Email Pengirim",

    "Sender Name" => "Nama pengirim:",

    "Email Protocol" => "Protokol Email",

    "Mail Engine" => "Mesin Surat",

    "From Name" => "Dari Nama",

    "From Mail" => "Dari Surat",

    "Mail Host" => "Host Surat",

    "Mail Port" => "Port Surat",

    "Mail Username" => "Nama pengguna Surat",

    "Mail Password" => "Kata sandi surel",

    "Mail Encryption" => "Enkripsi Surat",

    "Email Charset" => "Email Email:",

    "Email Setup" => "Pengaturan Email",

    "whatsapp bubble logo" => "Whatsapp bubble logo",

    "System Last Update" => "Pembaruan Sistem Terakhir",

    "hi_modal" => "-Hai! Selamat datang, apa yang bisa saya bantu?",

    "Logout" => "Logout",

    "Confirmation" => "Konfirmasi",

    "In-active" => "In-active",

    "disabled" => "$dinonaktifkan",

    "Verify Your Email Address" => "Verifikasi Alamat Email Anda",

    "Click here to request another" => "Klik di sini untuk meminta bantuan lain.",

    "Before proceeding, please check your email for a verification link. If you did not receive the email" => "Sebelum melanjutkan, silakan cek email Anda untuk tautan verifikasi. Jika Anda tidak menerima email",

    "usA fresh verification link has been sent to your email address.er" => "Sebuah link verifikasi segar telah dikirim ke alamat email Anda.",

    "Super Admin" => "Admin Super",

    "Send Reset Password Link" => "Kirim Ulang Tautan Sandi",

    "Please confirm your password before continuing" => "Harap konfirmasi kata sandi Anda sebelum melanjutkan.",

    "Forget Password" => "Lupakan Kata Sandi",

    "SMTP" => "SMTP",

    "Php Mail" => "Surat Php",

    "Email Text" => "Teks Email:",

    "whatsapp_chat" => "Whatsapp Chat",

    "To Mail" => "Untuk Mail",

    "site_title" => "Judul Situs",

    "copy_right" => "Salin Teks Kanan",

    "Mail Driver" => "Driver Surat",

];
