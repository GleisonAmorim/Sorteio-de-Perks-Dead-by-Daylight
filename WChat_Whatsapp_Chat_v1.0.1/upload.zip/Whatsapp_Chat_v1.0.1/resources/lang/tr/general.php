<?php
return [
    "rtl_ltl" => "RTL/LTL",

    "code" => "Kod",

    "Timetable" => "Zaman Çizelgesi",

    "System Activated Date" => "Sistemin Etkinleştirdiği Tarih",

    "Install Domain" => "Etki Alanı Kur",

    "Purchase code" => "Satın alma kodu",

    "Curl Enable" => "Curl Etkinleştirme",

    "PHP Version" => "PHP Sürümü",

    "Check update" => "Güncellemeyi denetle",

    "Software Version" => "Yazılım Sürümü",

    "About System" => "Sistem Hakkında",

    "Upload From Local Directory" => "Yerel Dizinden Yükle",

    "Update System" => "Sistemi Güncelle",

    "Default password will be" => "Varsayılan parola",

    "native_name" => "Yerel Ad",

    "min_8" => "En az 8 karakter",

    "re_type" => "Yeniden Tip",

    "update_system" => "Sistemi Güncelle",

    "key" => "Anahtar",

    "value" => "Değer",

    "edit_language_info" => "Dil Bilgilerini Düzenle",

    "users" => "Kullanıcılar",

    "Whatsapp support icon position" => "Whatsapp desteği simgesi konumu",

    "copy_script" => "Bu komut dosyasını kopyalayın ve gövde etiketi uçmadan önce web sitenize yapıştırın.",

    "update_user" => "Kullanıcıyı Güncelle",

    "email" => "Eposta",

    "language_list" => "Dil Listesi",

    "new_language" => "Yeni Dil",

    "translation" => "Çeviri",

    "create_user" => "Kullanıcı Yarat",

    "System Settings" => "Sistem Ayarları",

    "assign" => "Ata",

    "add_user" => "Kullanıcı Ekle",

    "icon_position" => "Whatsapp Simge Konumu",

    "bottom_left" => "Alt Sol",

    "bottom_right" => "Alt Sağ",

    "margin_from_bottom" => "Alttan Kenar Boşluğu",

    "margin_from_right" => "Sağ Kenar Boşluğu",

    "margin_from_left" => "Sol Kenar Boşluğu",

    "role_permission" => "Rol İzni",

    "layout_settings" => "Düzen Ayarı",

    "choose_layout" => "Düzen Seç",

    "show_unavailable_agent_in_popup" => "Kullanılamayan aracıyı açılır pencerede göster",

    "end" => "Bitiş",

    "time" => "Saat",

    "Apply All Days" => "Tüm Günleri Uygula",

    "Are you sure to delete" => "Silineceğinden emin misiniz?",

    "id" => "Kimlik",

    "ip" => "IP",

    "browser" => "Tarayıcı",

    "operating_system" => "İşletim Sistemi",

    "messages" => "İletiler",

    "with_country_code" => "With Country Code is Olmalıdır",

    "total_click" => "Toplam tıklatma sayısı",

    "clicks" => "Tıklatma sayısı",

    "click_from_mobile" => "Mobile ' den Tıklat",

    "click_from_desktop" => "Masaüstünden Tıklat",

    "action" => "Eylem",

    "welcome_message" => "Hoş Geldiniz İletisi",

    "your_scripts" => "Komut Dosyalarınız",

    "Sanitize No" => "Hayır.",

    "Sanitize Yes" => "Evet Gibi",

    "3DS Yes" => "3DS Evet",

    "3DS No" => "3DS Hayır",

    "Module Verification" => "Modül Doğrulaması",

    "Envato Email Address" => "Envato E-posta Adresi",

    "Envato Purchase Code" => "Envato Satınalma Kodu",

    "Verifying" => "Doğrulanıyor",

    "Subscription Api Key" => "Abonelik Api Anahtarı",

    "Subscription Method" => "Abonelik Yöntemi",

    "Watch Now" => "Şimdi İzleyin",

    "Continue Watch" => "Izlemeye Devam et",

    "End" => "Bitiş",

    "TimeZone" => "SaatDilimi",

    "Backup" => "Yedekle",

    "Upload SQL File" => "SQL Dosyasını Karşıya Yükle",

    "Database Backup List" => "Veritabanı Yedekleme Listesi",

    "Generate New Backup" => "Yeni Yedekleme Oluştur",

    "File Name" => "Dosya Adı",

    "Theme" => "Tema",

    "Reset To Default" => "Varsayılana Geri Çevir",

    "Mode" => "Mod",

    "Blogs" => "Web Günlükleri",

    "List" => "Liste",

    "Create" => "Oluştur",

    "Show" => "Göster",

    "Title" => "Unvan",

    "Description" => "Açıklama",

    "Status" => "Durum",

    "Image" => "Resim",

    "SL" => "SL",

    "Dashboard" => "Gösterge Panosu",

    "Enable" => "Etkinleştir",

    "Disable" => "Geçersiz Kıl",

    "Duration" => "Süre",

    "Logo" => "Logo",

    "Browse" => "Göz At",

    "Update" => "Güncelleştir",

    "ID" => "Kimlik",

    "Password" => "Parola",

    "Add" => "Ekle",

    "Yes" => "Evet",

    "No" => "Hayır",

    "Save" => "Kaydet",

    "Date" => "Tarih",

    "Time" => "Saat",

    "Start" => "Başlat",

    "Select" => "Seç",

    "View" => "Görüntüle",

    "Edit" => "Düzenle",

    "Delete" => "Sil",

    "Cancel" => "İptal",

    "Name" => "Ad",

    "Details" => "Ayrıntılar",

    "Close" => "Durum",

    "failed" => "Bu kimlik bilgileri kayıtlarımızla eşleşmiyor.",

    "Make Default" => "Varsayılanı yap",

    "Course" => "Kurs",

    "list" => "Liste",

    "create" => "Oluştur",

    "browse" => "Göz At",

    "name" => "Ad",

    "update" => "Güncelleştir",

    "settings" => "Ayarlar",

    "files" => "Dosyalar",

    "file" => "Dosya",

    "new" => "Yeni",

    "type" => "Tip",

    "send" => "Gönder",

    "delete" => "Sil",

    "yes" => "Evet",

    "select" => "Seç",

    "no" => "Hayır",

    "user" => "Kullanıcı",

    "required" => "Gerekli",

    "permission" => "İzin",

    "remove" => "Kaldır",

    "start" => "Başlat",

    "to" => "Hedef",

    "add" => "Ekle",

    "search" => "Ara",

    "description" => "Açıklama",

    "Send Email" => "Eposta Gönder",

    "Language" => "Dil",

    "Type" => "Tip",

    "Category" => "Kategori",

    "URL" => "URL Adresi",

    "Publish" => "Yayınla",

    "Code" => "Kod",

    "Active" => "Etkin",

    "Role" => "Rol",

    "Add New" => "Yeni Ekle",

    "My Courses" => "Kurslarım",

    "Sub Category" => "Alt Kategori",

    "Discount" => "İndirim",

    "Course File" => "Kurs Dosyası",

    "My Quizzes" => "Benim Quizz'lerim",

    "Video File" => "Video Dosyası",

    "Browse Video file" => "Video dosyasına göz at",

    "Start Date" => "Başlangıç Tarihi",

    "End Date" => "Bitiş Tarihi",

    "Inactive" => "Etkin Değil",

    "Checkout" => "Dışarı Al",

    "Discount or coupon info" => "İndirim ya da kupon bilgileri",

    "My Cart" => "Sepetim",

    "Apply" => "Uygula",

    "Author" => "Yazar",

    "My Profile" => "Profilim",

    "Bookmarks" => "Yer İşaretleri",

    "About" => "Hakkında",

    "Sub Title" => "Alt Başlık",

    "Country" => "Ülke",

    "Change" => "Değişiklik",

    "Date of Birth" => "Doğum Tarihi",

    "phone" => "Telefon",

    "address" => "Adres",

    "previous" => "Önceki",

    "next" => "Sonraki;",

    "Login" => "Oturum Aç",

    "View Profile" => "Profili Görüntüle",

    "Profile Settings" => "Tanıtım Ayarları",

    "Current" => "Geçerli",

    "Re-Type Password" => "Parolayı Yeniden Yaz",

    "Type Password" => "Parolayı Yazın",

    "Remember Me" => "Beni Anımsa",

    "Login Details" => "Oturum Açma Ayrıntıları",

    "Forget Password ?" => "Parolayı unutun mu?",

    "Need an account?" => "Hesap mı lazım?",

    "Sign Up" => "Oturum Açın",

    "Sign Up Details" => "Oturum açma ayrıntıları",

    "You have already an account?" => "Zaten bir hesabınız var mı?",

    "Send Reset Link" => "İlk Durum Bağlantısını Gönder",

    "Reset Password" => "Parolayı Sıfırla",

    "Reset" => "Sıfırla",

    "Set New Password" => "Yeni Parolayı Ayarla",

    "Set Password" => "Parola Ayarla",

    "Start From" => "Başlangıç Başlangıcı",

    "Start At" => "Başlangıç:",

    "To" => "Hedef",

    "Free" => "Ücretsiz",

    "Off" => "Kapalı",

    "On" => "Açık",

    "Social Link" => "Sosyal Bağlantı",

    "Active Status" => "Etkin Durum",

    "Language List" => "Dil Listesi",

    "Choose File" => "Dosya Seç",

    "Translation" => "Çeviri",

    "Currency" => "Para Birimi",

    "Action" => "Eylem",

    "Live" => "Canlı",

    "Sandbox" => "Kum Havuzu",

    "Something Went Wrong" => "Bir şeyler Yanlış Gitti.",

    "Model" => "Model",

    "Attempted At" => "Denenen",

    "User" => "Kullanıcı",

    "Activity Logs" => "Etkinlik Günlükleri",

    "Delete Confirmation" => "Silme Doğrulaması",

    "Human Resource" => "İnsan Kaynakları",

    "Staff" => "Personel",

    "Staff List" => "Personel Listesi",

    "Username" => "Kullanıcı Adı",

    "Email" => "Eposta",

    "Phone" => "Telefon",

    "Registered Date" => "Kaydolduğu Tarih",

    "Register" => "Kaydol",

    "Remove" => "Kaldır",

    "Staff Id" => "Personel Tanıtıcısı",

    "Confirm Password" => "Parolayı Doğrulayın",

    "Re-Password" => "Yeniden Parola",

    "Avatar" => "Avatar",

    "Edit Staff Info" => "Personel Bilgilerini Düzenle",

    "Staff info has been updated Successfully" => "Personel bilgileri başarıyla güncellendi",

    "Staff has been added Successfully" => "Personel Başarıyla Eklendi",

    "Staff Info" => "Personel Bilgileri",

    "Staff ID" => "Personel Tanıtıcısı",

    "Password did not match with your account password." => "Parola, hesap parolanizla eşleşmedi.",

    "Put Your password" => "Parolanızı girin",

    "Staff has been deleted Successfully" => "Personel Başarıyla Silindi",

    "Variant" => "Çeşitleme",

    "Add Variant" => "Çeşitleme Ekle",

    "Published" => "Yayınlandı",

    "Variation Values" => "Değişken Değerleri",

    "Add Value" => "Değer Ekle",

    "Edit Variant" => "Çeşitleme Düzenle",

    "Unit Type" => "Birim Tipi",

    "Add Unit Type" => "Birim Tipi Ekle",

    "Edit Unit Type" => "Birim Tipini Düzenle",

    "Brand" => "Marka",

    "Add Brand" => "Marka Ekle",

    "Edit Brand" => "Markayı Düzenle",

    "Add Model" => "Model Ekle",

    "Edit Model" => "Modeli Düzenle",

    "Add Category" => "Kategori Ekle",

    "Add as Sub Category" => "Alt Kategori Olarak Ekle",

    "Select parent Category" => "Üst Kategori Seçin",

    "Edit Category" => "Kategoriyi Düzenle",

    "Add New Product" => "Yeni Ürün Ekle",

    "Product Name" => "Ürün Adı",

    "Product SKU" => "Ürün Saklama Kodu",

    "Barcode Type" => "Barkod Tipi",

    "Unit" => "Birim",

    "Add File" => "Dosya Ekle",

    "Manage Stock" => "Stoğu Yönet",

    "Alert Quantity" => "Uyarı Miktarı",

    "Variation" => "Çeşitleme",

    "Add Variation" => "Varyasyon Ekle",

    "Add Product" => "Ürün Ekle",

    "Edit Product" => "Ürünü Düzenle",

    "Employee Id" => "Çalışan Kimliği",

    "Address" => "Adres",

    "New Price Group" => "Yeni Fiyat Grubu",

    "Export" => "Dışa Aktar",

    "letter" => "mektup",

    "date" => "tarih",

    "File Not Found" => "Dosya Bulunamadı",

    "Download" => "Karşıdan Yükle",

    "Are you sure to delete ?" => "Sileceğinden emin misiniz?",

    "Are you sure to" => "Bundan emin misiniz?",

    "Are you sure to enable this ?" => "Bunu etkinleştirdiğinizden emin misiniz?",

    "Are You Sure To Change Status ?" => "Durumu Değiştirdiğinizden Emin Misiniz?",

    "Are You Sure To Remove This?" => "Bunu Kaldırdığınızdan Emin Misiniz?",

    "Success" => "Başarılı",

    "Failed" => "Başarısız oldu",

    "User Logs" => "Kullanıcı Günlükleri",

    "Question & Answer" => "Soru ve Yanıt",

    "Comments" => "Açıklamalar",

    "Replies" => "Yanıtlar",

    "Commented By" => "Yorumlayan",

    "Submitted" => "Gönderildi",

    "Deactive" => "Devre dışı",

    "Email Address" => "Eposta Adresi",

    "Instagram URL" => "Instagram URL Adresi",

    "Youtube URL" => "Youtube URL 'si",

    "LinkedIn URL" => "LinkedIn URL Adresi",

    "Twitter URL" => "Twitter URL 'si",

    "Facebook URL" => "Facebook URL 'si",

    "Change Status" => "Durumu Değiştir",

    "Filter History" => "Süzgeç Geçmişi",

    "Reject" => "Reddet",

    "Reason" => "Neden",

    "Payouts" => "Ödemelemeler",

    "Available" => "Kullanılabilir",

    "Issue Date" => "Çıkış Tarihi",

    "Deactivate" => "Etkinliğini Kaldır",

    "Files" => "Dosyalar",

    "File" => "Dosya",

    "Send" => "Gönder",

    "Paid" => "Ödendi",

    "Waiting" => "Bekleniyor",

    "Info" => "Bilgi",

    "Zip Code" => "Posta Kodu",

    "City" => "İlçe",

    "Submit" => "Gönder",

    "Error" => "Hata",

    "Warning" => "Uyarı",

    "Used" => "Kullanılan",

    "Join For Free" => "Ücretsiz Olarak Katıl",

    "Enter Email" => "Eposta Girin",

    "Enter Password" => "Parola Girin",

    "Enter Phone Number" => "Telefon Numarasını Girin",

    "Enter Confirm Password" => "Parolayı Doğrulayın",

    "Update Profile" => "Profili Güncelleştir",

    "Review" => "İncele",

    "Log in with Facebook" => "Facebook ile oturum açın",

    "Log in with Google" => "Google ile oturum açın",

    "Or" => "Ya da",

    "Keep me up to date on WCHAT" => "Beni WCHAT ile çıkmak için güncel tut",

    "Required" => "Gerekli",

    "New" => "Yeni",

    "Instructor Payout" => "Eğitmen Ödeme",

    "Time Left" => "Kalan Zaman",

    "No Item found" => "Öğe bulunamadı",

    "Total Price" => "Toplam Fiyat",

    "Course Schedule" => "Kurs Zamanlaması",

    "Add To Cart" => "Alışveriş Sepetine Ekle",

    "Buy Now" => "Şimdi Satın al",

    "Lessons" => "Dersler",

    "Deposit" => "Depozito",

    "Referral" => "Başvuru kaynağı",

    "Purchase History" => "Satın Alma Geçmişi",

    "Live Classes" => "Canlı Sınıflar",

    "Already Enrolled" => "Önceden Kaydoldu",

    "Student Enrolled" => "Öğrenci Kaydoldu",

    "Already Submitted" => "Önceden Gönderildi",

    "Quiz" => "Quiz",

"Correct Answer" => "Yanıtı Düzelt",

"Wrong Answer" => "Yanlış Yanıt",

"Skip" => "Atla",

"Next" => "Sonraki",

"Previous" => "Önceki",

"Share" => "Paylaş",

"Course Files" => "Kurs Dosyaları",

"Course Review" => "Kurs İncelemesi",

"Start Date & Time" => "Başlangıç Tarihi ve Saati",

"At" => "Saat",

"Drip Content" => "Damla İçeriği",

"Specific Date" => "Belirli Tarih",

"Days After Enrollment" => "Kayıt Sonrası Gün Sayısı",

"Show All" => "Tümünü Göster",

"Show After Unlock" => "Kilidinden Sonra Göster",

"Aws S3 Setting" => "Aws S3 Ayarı",

"Access Key Id" => "Erişim Anahtarı Tanıtıcısı",

"Secret Key" => "Gizli Anahtar",

"Default Region" => "Varsayılan Bölge",

"AWS Bucket" => "AWS Saklama Kabı",

"Module Manager" => "Birim Yöneticisi",

"Payment Type" => "Ödeme Tipi",

"Star" => "Yıldız",

"Total Courses" => "Toplam Kurslar",

"Enroll Now" => "Şimdi Kaydet",

"Added To Cart" => "Alışveriş Sepetine Eklendi",

"Logged In Devices" => "Oturum Açan Aygıtlar",

"Purchase Price" => "Satın Alma Fiyatı",

"Pay" => "Öde",

"Welcome" => "Hoş Geldiniz",

"Minimum 8 characters" => "En az 8 karakter",

"Status has been changed" => "Durum değiştirildi",

"For the demo version, you cannot change this" => "Gösterim sürümü için bu sürümü değiştiremezsiniz",

"Select Date" => "Tarih Seç",

"Days" => "Gün",

"Operation successful" => "İşlem başarılı oldu",

"Operation failed" => "İşlem başarısız oldu",

"Quick Search" => "Hızlı Arama",

"Copy" => "Kopyala",

"Excel" => "Excel",

"CSV" => "CSV",

"PDF" => "PDF",

"Print" => "Yazdır",

"No data available in the table" => "Tabloda kullanılabilir veri yok",

"Successfully Assign" => "Başarıyla Ata",

"Make Paid" => "Ödeme yap",

"Request For Paid" => "Ödenmiş İçin İstek",

"End Date & Time" => "Bitiş Tarihi ve Saati",

"Short Description" => "Kısa Tanım",

"Website" => "Web Sitesi",

"Browse file" => "Dosyaya göz at",

"Operation Failed" => "İşlem Başarısız Oldu",

"dashboard" => "Gösterge Panosu",

"or" => "ya da",

"Add to Cart" => "Alışveriş Sepetine Ekle",

"None" => "Yok",

"lessons" => "dersler",

"Browser" => "Tarayıcı",

"view_settings" => "Görünüm Ayarları",

"functional_settings" => "İşlevsel Ayarlar",

"color" => "Renk",

"agents" => "Aracılar",

"intro_text" => "Giriş Metni",

"single_agent" => "Tek Aracı",

"multi_agent" => "Birden Çok Aracı",

"availability" => "Kullanılabilirlik",

"only_mobile" => "Yalnızca Mobil",

"only_desktop" => "Yalnızca Masaüstü",

"both" => "Her İkisi",

"showing_page" => "Gösterilen Sayfa",

"only_homepage" => "Yalnızca Ana Sayfa",

"all_page" => "Tüm Sayfa",

"popup_open_initially" => "Beliren Aç Başlangıçta",

"agent_type" => "Aracı Tipi",

"homepage_url" => "Giriş Sayfası Url 'si",

"whatsapp_support" => "Whatsapp Desteği",

"primary_number" => "Birincil Numara",

"agent" => "Görevli",

"create_agent" => "Aracı Oluştur",

"update_agent" => "Aracıyı Güncelle",

"number" => "Sayı",

"add_agent" => "Aracı Ekle",

"designation" => "Belirleme",

"avatar" => "Avatar",

"status" => "Durum",

"active" => "Etkin",

"inactive" => "Etkin-Etkin",

"browse_avatar" => "Kullanıcı Listesi",

"always_available" => "Her Zaman Kullanılabilir",

"analytics" => "Analitik",

];
