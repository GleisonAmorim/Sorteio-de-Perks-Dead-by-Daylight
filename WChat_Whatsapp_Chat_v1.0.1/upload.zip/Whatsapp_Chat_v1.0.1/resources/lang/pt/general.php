<?php
return [
    "rtl_ltl" => "RTL/LTL",

    "code" => "Código",

    "search" => "Pesquisa",

    "Timetable" => "Calendário",

    "System Activated Date" => "Data Ativada do Sistema",

    "Install Domain" => "Domínio de Instalação",

    "Purchase code" => "Código de compra",

    "Curl Enable" => "Ativação de Curl",

    "PHP Version" => "Versão do PHP",

    "Check update" => "Atualização de verificação",

    "Software Version" => "Versão do Software",

    "About System" => "Sobre o Sistema",

    "Upload From Local Directory" => "Upload Do Diretório Local",

    "Update System" => "Sistema de atualização",

    "Default password will be" => "A senha padrão será",

    "native_name" => "Nome Nativo",

    "min_8" => "Mínimo de 8 caractere",

    "re_type" => "Re-Tipo",

    "update_system" => "Sistema de atualização",

    "key" => "Chave",

    "value" => "Valor",

    "edit_language_info" => "Editar Idioma Info",

    "users" => "Usuários",

    "Whatsapp support icon position" => "Posição do ícone de suporte do Whatsap",

    "copy_script" => "Copie este script e cole-o em seu website antes que a tag body termine.",

    "update_user" => "Atualizar Usuário",

    "email" => "E-mail",

    "language_list" => "Lista de idiomas",

    "new_language" => "Nova Idioma",

    "translation" => "Tradução",

    "create_user" => "Criar Usuário",

    "System Settings" => "Configurações do Sistema",

    "assign" => "Designar",

    "permission" => "Permissão",

    "add_user" => "Adicionar Usuário",

    "icon_position" => "Posição Do Ícone Whatsapp",

    "bottom_left" => "Esquerda De Fundo",

    "bottom_right" => "Direito de Fundo",

    "margin_from_bottom" => "Margem De Baixo",

    "margin_from_right" => "Margem Da Direita",

    "margin_from_left" => "Margem Da Esquerda",

    "role_permission" => "Permissão De Função",

    "layout_settings" => "Configuração do Layout",

    "choose_layout" => "Escolher Layout",

    "show_unavailable_agent_in_popup" => "Mostrar agente indisponível em popup",

    "start" => "Início",

    "end" => "Fim",

    "time" => "Tempo",

    "Apply All Days" => "Aplicar Todos Os Dias",

    "Are you sure to delete" => "Você tem certeza de excluir",

    "create" => "Criar",

    "select" => "Selecionar",

    "id" => "ID",

    "ip" => "IP",

    "browser" => "Navegador",

    "operating_system" => "Sistema de Operação",

    "messages" => "Mensagens",

    "with_country_code" => "Com o Código do País deve-se",

    "total_click" => "Total de Clicks",

    "clicks" => "Cliques",

    "click_from_mobile" => "Clique De Móvel",

    "click_from_desktop" => "Clique De Desktop",

    "action" => "Ação",

    "welcome_message" => "Mensagem de boas-vindas",

    "your_scripts" => "Seus Scripts",

    "Login" => "Login",

    "View Profile" => "Perfil da Visualização",

    "My Profile" => "Meu Perfil",

    "Profile Settings" => "Configurações do Perfil",

    "Current" => "Corrente",

    "Re-Type Password" => "Re-Type Password",

    "Type Password" => "Senha do Tipo",

    "Remember Me" => "Lembre-Me",

    "Login Details" => "Detalhes de Login",

    "Forget Password ?" => "Esquecer Senha?",

    "Need an account?" => "Precisa de uma conta?",

    "Sign Up" => "Cadine Up",

    "Sign Up Details" => "Detalhes do Assinante",

    "You have already an account?" => "Você já tem uma conta?",

    "Send Reset Link" => "Enviar Link Reset",

    "Reset Password" => "Alterar Senha",

    "Reset" => "Reajuste",

    "Set New Password" => "Definir Nova Senha",

    "Set Password" => "Configurar Senha",

    "Start From" => "Início De",

    "Start At" => "Início Em",

    "To" => "Para",

    "Free" => "Livre",

    "Off" => "Desligado",

    "On" => "Em",

    "Social Link" => "Link Social",

    "Active Status" => "Status Ativo",

    "Language List" => "Lista de idiomas",

    "Choose File" => "Escolher Arquivo",

    "Translation" => "Tradução",

    "Currency" => "Moeda",

    "Add New" => "Adicionar Novo",

    "ID" => "ID",

    "Title" => "Título",

    "Details" => "Detalhes",

    "Name" => "Nome",

    "Action" => "Ação",

    "Edit" => "Editar",

    "Delete" => "Excluir",

    "Select" => "Selecionar",

    "Save" => "Salvar",

    "Update" => "Atualização",

    "Live" => "Ao vivo",

    "Sandbox" => "Sandbox",

    "Something Went Wrong" => "Algo Deu Errado",

    "Description" => "Descrição",

    "Model" => "Modelo",

    "Attempted At" => "Tentativa De No",

    "User" => "Usuário",

    "Activity Logs" => "Logs De Atividades",

    "Type" => "Tipo",

    "Delete Confirmation" => "Confirmar Confirmação",

    "Human Resource" => "Recurso Humano",

    "Staff" => "Equipe",

    "Staff List" => "Lista de Pessoal",

    "Username" => "Nome do usuário",

    "Email" => "E-mail",

    "Phone" => "Telefone",

    "Registered Date" => "Data registrada",

    "Status" => "Status",

    "URL" => "URL",

    "Register" => "Registo",

    "Remove" => "Remover",

    "Staff Id" => "Id do Pessoal",

    "Password" => "Senha",

    "Confirm Password" => "Confirmar Senha",

    "Re-Password" => "Re-Senha",

    "Browse" => "Navegar",

    "Avatar" => "Avatar",

    "Edit Staff Info" => "Página de Edição Info",

    "Staff info has been updated Successfully" => "Info staff foi atualizado com sucesso",

    "Staff has been added Successfully" => "Equipe foi incluída Sucesso",

    "View" => "Visualização",

    "Staff Info" => "Equipe Info",

    "Close" => "Fechar",

    "Staff ID" => "ID da equipe",

    "Password did not match with your account password." => "A senha não combinou com a sua senha de conta.",

    "Put Your password" => "Coloque Sua senha",

    "Staff has been deleted Successfully" => "Equipe foi excluída Sucesso",

    "Language" => "Idioma",

    "Variant" => "Variante",

    "Add Variant" => "Adicionar Variante",

    "Publish" => "Publicar",

    "Published" => "Publicado",

    "Variation Values" => "Valores De Variação",

    "Add Value" => "Adicionar Valor",

    "Edit Variant" => "Editar Variante",

    "Unit Type" => "Tipo de Unidade",

    "Add Unit Type" => "Adicionar Tipo de Unidade",

    "Edit Unit Type" => "Tipo de Unidade Edição",

    "Brand" => "Marca",

    "Add Brand" => "Adicionar Marca",

    "Edit Brand" => "Editar Marca",

    "Add Model" => "Adicionar Modelo",

    "Edit Model" => "Modelo editar",

    "Category" => "Categoria",

    "Add Category" => "Adicionar Categoria",

    "Code" => "Código",

    "Add as Sub Category" => "Adicionar como Sub Categoria",

    "Select parent Category" => "Selecionar categoria pai",

    "Edit Category" => "Editar Categoria",

    "Add New Product" => "Adicionar Novo Produto",

    "Product Name" => "Nome do Produto",

    "Product SKU" => "SKU do Produto",

    "Barcode Type" => "Tipo de Barcódigo",

    "Unit" => "Unidade",

    "Sub Category" => "Sub Categoria",

    "Add File" => "Adicionar Arquivo",

    "Manage Stock" => "Gerenciar Ações",

    "Alert Quantity" => "Quantidade De Alerta",

    "Variation" => "Variação",

    "Add Variation" => "Adicionar Variação",

    "Add Product" => "Adicionar Produto",

    "Edit Product" => "Editar Produto",

    "Employee Id" => "Id do funcionário",

    "Address" => "Endereço",

    "New Price Group" => "Novo Grupo de Preços",

    "Export" => "Exportação",

    "SL" => "SL",

    "Cancel" => "Cancelar",

    "About" => "Sobre",

    "letter" => "carta",

    "date" => "data",

    "Date" => "Data",

    "Image" => "Imagem",

    "File Not Found" => "Arquivo Não Encontrado",

    "Download" => "Download",

    "Are you sure to delete ?" => "Você tem certeza de excluir?",

    "Are you sure to" => "Você tem certeza de",

    "Are you sure to enable this ?" => "Tem certeza de ativar isso?",

    "Are You Sure To Change Status ?" => "Você Tem Certeza De Alterar O Status?",

    "Are You Sure To Remove This?" => "Você Tem Certeza De Remover Isso?",

    "Role" => "Função",

    "List" => "Lista",

    "Add" => "Adicionar",

    "Success" => "Sucesso",

    "Failed" => "Falha",

    "Dashboard" => "Painel",

    "User Logs" => "Logs Do Usuário",

    "Question & Answer" => "Pergunta & Resposta",

    "Comments" => "Comentários",

    "Course" => "Curso",

    "Replies" => "Respostas",

    "Commented By" => "Comentado Por",

    "Submitted" => "Enviado",

    "Enable" => "Ativar",

    "Disable" => "Desativar",

    "Active" => "Ativo",

    "Deactive" => "Desativo",

    "Inactive" => "Inativo",

    "Email Address" => "Endereço de e-mail",

    "Instagram URL" => "URL do Instagram",

    "Youtube URL" => "URL do Youtube",

    "LinkedIn URL" => "URL do LinkedIn",

    "Twitter URL" => "URL do Twitter",

    "Facebook URL" => "URL do Facebook",

    "Date of Birth" => "Data de Nascimento",

    "Change Status" => "Alterar Status",

    "Start Date" => "Data de Início",

    "End Date" => "Data de encerramento",

    "Filter History" => "Filtrar Histórico",

    "Reject" => "Rejeitar",

    "Reason" => "Razão",

    "Payouts" => "Pagamentos",

    "Author" => "Autor",

    "Available" => "Disponível",

    "Issue Date" => "Data de emissão",

    "Duration" => "Duração",

    "Change" => "Mudança",

    "Deactivate" => "Desativar",

    "Yes" => "Sim",

    "Files" => "Arquivos",

    "File" => "Arquivo",

    "Send" => "Enviar",

    "Paid" => "Pago",

    "Waiting" => "Esperando",

    "Info" => "Info",

    "Zip Code" => "CEP",

    "Country" => "País",

    "City" => "Cidade",

    "Submit" => "Enviar",

    "Error" => "Erro",

    "Warning" => "Aviso",

    "Used" => "Usado",

    "Join For Free" => "Junção Para Livre",

    "Enter Email" => "Entrar Email",

    "Enter Password" => "Inserir Senha",

    "Enter Phone Number" => "Digitar Número de Telefone",

    "Enter Confirm Password" => "Inserir Confirmar Senha",

    "Update Profile" => "Perfil da atualização",

    "Review" => "Revisão",

    "Log in with Facebook" => "Faça login com o Facebook",

    "Log in with Google" => "Faça login com o Google",

    "Or" => "Ou",

    "Keep me up to date on WCHAT" => "Mantenha-me atualizado sobre o WCHAT",

    "Required" => "Necessário",

    "New" => "Novo",

    "Instructor Payout" => "Instrutor Payout",

    "Time Left" => "Tempo de Esquerda",

    "No Item found" => "Nenhum Item encontrado",

    "Total Price" => "Preço Total",

    "Discount or coupon info" => "Desconto ou cupom info",

    "Checkout" => "Checkout",

    "Apply" => "Aplicar",

    "Course Schedule" => "Planejamento do Cur",

    "Add To Cart" => "Adicionar Ao Carrinho",

    "Buy Now" => "Comprar Agora",

    "Lessons" => "Lições",

    "Bookmarks" => "Indicadores",

    "Deposit" => "Depósito",

    "Referral" => "Indicação",

    "My Cart" => "Meu Carrinho",

    "Purchase History" => "Histórico de compra",

    "My Courses" => "Meus Cursos",

    "Live Classes" => "Classes ao vivo",

    "Already Enrolled" => "Já Cadastrado",

    "Student Enrolled" => "Aluno Cadastrado",

    "Already Submitted" => "Já Enviado",

    "'s Quiz" => "Quiz",

    "Correct Answer" => "Resposta correta",

    "Wrong Answer" => "Resposta errada",

    "Skip" => "Ir",

    "Next" => "Próximo",

    "Previous" => "Anterior",

    "Course File" => "Arquivo do curso",

    "Share" => "Compartilhar",

    "Course Files" => "Arquivos do curso",

    "Course Review" => "Revisão do curso",

    "Start Date & Time" => "Data & Hora de Início",

    "At" => "Em",

    "Show" => "Mostrar",

    "Drip Content" => "Conteúdo de Drip",

    "Specific Date" => "Data específica",

    "Days After Enrollment" => "Dias Após a Inscrição",

    "Show All" => "Mostrar Tudo",

    "Show After Unlock" => "Mostrar Após Desbloquear",

    "Aws S3 Setting" => "Garras S3 Configuração",

    "Access Key Id" => "Id do Chave de Acesso",

    "Secret Key" => "Chave secreta",

    "Default Region" => "Região Padrão",

    "AWS Bucket" => "Balde AWS",

    "Module Manager" => "Gerente de Módulo",

    "Payment Type" => "Tipo de pagamento",

    "Blogs" => "Blogs",

    "Star" => "Estrela",

    "Total Courses" => "Total De Cursos",

    "Discount" => "Desconto",

    "Logo" => "Logotipo",

    "My Quizzes" => "Meus Quizzes",

    "Enroll Now" => "Cadas-Se Agora",

    "Added To Cart" => "Adicionado Ao Carrinho",

    "Logged In Devices" => "Conectado Em Dispositivos",

    "Purchase Price" => "Preço Comprar",

    "Pay" => "Pagamento",

    "Welcome" => "Bem-vindo",

    "Send Email" => "Enviar Email",

    "Minimum 8 characters" => "Mínimo de 8 caracteres",

    "Status has been changed" => "O status foi alterado",

    "For the demo version, you cannot change this" => "Para a versão demo, não é possível alterar esta",

    "Video File" => "Arquivo de vídeo",

    "Browse Video file" => "Navegar no arquivo de Video",

    "Select Date" => "Selecionar Data",

    "Days" => "Dias",

    "Operation successful" => "Operação bem-sucedida",

    "Operation failed" => "Operação falhou",

    "Quick Search" => "Pesquisa rápida",

    "Copy" => "Copiar",

    "Excel" => "Excel",

    "CSV" => "CSV",

    "PDF" => "PDF",

    "Print" => "Imprimir",

    "No data available in the table" => "Nenhum dado disponível na tabela",

    "Successfully Assign" => "Designar Com Sucesso",

    "Make Paid" => "Fazer Pago",

    "Request For Paid" => "Pedido De Pagamento",

    "End Date & Time" => "Data e Hora de Festa",

    "Short Description" => "Descrição curta",

    "No" => "Não",

    "Website" => "Website",

    "Browse file" => "Navegar em arquivo",

    "Sanitize No" => "Sanitize Não",

    "Sanitize Yes" => "Sanitize Sim",

    "3DS Yes" => "3DS Sim",

    "3DS No" => "3DS Não",

    "Module Verification" => "Verificação Do Módulo",

    "Envato Email Address" => "Endereço De Email Do Envato",

    "Envato Purchase Code" => "Código De Compra Do Envato",

    "Verifying" => "Verificando",

    "None" => "Nenhum",

    "Subscription Api Key" => "Chave Api de Assinatura",

    "Subscription Method" => "Método de Assinatura",

    "Watch Now" => "Assista Agora",

    "Continue Watch" => "Continuar Assista",

    "Time" => "Tempo",

    "Start" => "Início",

    "End" => "Fim",

    "TimeZone" => "TimeZone",

    "Backup" => "Backup",

    "Upload SQL File" => "Upload de Arquivo SQL",

    "Database Backup List" => "Lista de Backup de Bancos",

    "Generate New Backup" => "Gerar Novo Backup",

    "File Name" => "Nome do Arquivo",

    "Make Default" => "Fazer Padrão",

    "Theme" => "Tema",

    "Reset To Default" => "Reajuste Para Padrão",

    "Mode" => "Modo",

    "Sub Title" => "Sub Título",

    "view_settings" => "Configurações da Visualização",

    "functional_settings" => "Configurações funcionais",

    "color" => "Cor",

    "update" => "Atualização",

    "settings" => "Configurações",

    "agents" => "Agentes",

    "intro_text" => "Texto de Introdução",

    "single_agent" => "Agente Único",

    "multi_agent" => "Vários Agente",

    "availability" => "Disponibilidade",

    "only_mobile" => "Apenas Mobile",

    "only_desktop" => "Apenas Desktop",

    "both" => "Ambos",

    "showing_page" => "Mostrando Página",

    "only_homepage" => "Apenas Página Inicial",

    "all_page" => "Toda a Página",

    "popup_open_initially" => "Popup Aberto Inicialmente",

    "yes" => "Sim",

    "agent_type" => "Tipo de Agente",

    "homepage_url" => "Página Inicial da Página inicial",

    "no" => "Não",

    "whatsapp_support" => "Suporte ao WhatsApp",

    "primary_number" => "Número Principal",

    "agent" => "Agente",

    "create_agent" => "Criar Agente",

    "update_agent" => "Agente de atualização",

    "number" => "Número",

    "add_agent" => "Adicionar Agente",

    "name" => "Nome",

    "designation" => "Designação",

    "avatar" => "Avatar",

    "status" => "Status",

    "active" => "Ativo",

    "inactive" => "Em-Ativo",

    "browse_avatar" => "Pular Avatar",

    "always_available" => "Sempre Disponível",

    "analytics" => "Analítica",

];
