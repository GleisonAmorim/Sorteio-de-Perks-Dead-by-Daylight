<?php
return [
    "Edit Timezone Info" => "টাইম-জোন তথ্য সম্পাদন করো",

    "Timezone has been deleted Successfully" => "টাইমজোন সফল ভাবে মুছে ফেলা হয়েছে",

    "Send Email" => "ই-মেইল পাঠাও",

    "list" => "তালিকা",

    "create" => "তৈরি করো",

    "browse" => "ব্রাউজ",

    "name" => "নাম:",

    "update" => "আপডেট",

    "settings" => "সেটিংস",

    "files" => "ফাইল",

    "file" => "ফাইল",

    "new" => "নতুন",

    "type" => "ধরন",

    "send" => "প্রেরণ",

    "delete" => "মুছে ফেলো",

    "yes" => "হ্যাঁ",

    "select" => "নির্বাচন করুন",

    "no" => "না",

    "user" => "ব্যবহারকারী",

    "required" => "আবশ্যক",

    "permission" => "অনুমতি",

    "remove" => "অপসারণ করো",

    "start" => "আরম্ভ",

    "to" => "এর জন্য",

    "add" => "যোগ করো",

    "search" => "অনুসন্ধান",

    "description" => "বর্ণনা",

    "Login" => "লগ-ইন",

    "View Profile" => "প্রোফাইল প্রদর্শন করো",

    "My Profile" => "আমার প্রোফাইল",

    "Profile Settings" => "প্রোফাইল সেটিংস",

    "Current" => "বর্তমান",

    "Re-Type Password" => "পাসওয়ার্ড পুনঃপ্রকৃতি",

    "Type Password" => "টাইপ পাসওয়ার্ড",

    "Remember Me" => "মনে রেখো",

    "Login Details" => "লগ-ইন বিবরণ",

    "Forget Password ?" => "পাসওয়ার্ড ভুলে যাও?",

    "Need an account?" => "অ্যাকাউন্ট নেয়া হয়েছে?",

    "Sign Up" => "স্বাক্ষর করো",

    "Sign Up Details" => "স্বাক্ষর আপ বিস্তারিত",

    "You have already an account?" => "আপনি ইতোমধ্যেই একটি অ্যাকাউন্ট আছে?",

    "Send Reset Link" => "রিসেট লিঙ্ক পাঠাও",

    "Reset Password" => "পাসওয়ার্ড রিসেট করো",

    "Reset" => "রিসেট",

    "Set New Password" => "নতুন পাসওয়ার্ড নির্ধারণ করুন",

    "Set Password" => "পাসওয়ার্ড নির্ধারণ করুন",

    "Start From" => "থেকে আরম্ভ করা হবে",

    "Start At" => "আরম্ভ করো",

    "To" => "এর জন্য",

    "Free" => "মুক্ত",

    "Off" => "Off",

    "On" => "অন",

    "Social Link" => "সামাজিক লিঙ্ক",

    "Active Status" => "সক্রিয় অবস্থা",

    "Language List" => "ভাষা তালিকা",

    "Choose File" => "ফাইল নির্বাচন করুন",

    "Translation" => "অনুবাদ",

    "Currency" => "মুদ্রা",

    "Add New" => "নতুন যোগ করো",

    "ID" => "ID",

    "Title" => "শিরোনাম",

    "Details" => "বিস্তারিত বিবরণ",

    "Name" => "নাম:",

    "Action" => "কাজ",

    "Edit" => "সম্পাদনা",

    "Delete" => "মুছে ফেলো",

    "Select" => "নির্বাচন করুন",

    "Save" => "সংরক্ষণ করো",

    "Update" => "আপডেট",

    "Live" => "লাইভ",

    "Sandbox" => "স্যান্ডবক্স",

    "Something Went Wrong" => "Went Wrong কিছু",

    "Description" => "বর্ণনা",

    "Model" => "মডেল",

    "Attempted At" => "At Attempted",

    "User" => "ব্যবহারকারী",

    "Activity Logs" => "কার্যক্রমের লগ",

    "Type" => "ধরন",

    "Delete Confirmation" => "অনুমোদন মুছে ফেলো",

    "Human Resource" => "মানব সম্পদ",

    "Staff" => "স্টাফ",

    "Staff List" => "স্টাফ তালিকা",

    "Username" => "Username",

    "Email" => "ই-মেইল",

    "Phone" => "ফোন",

    "Registered Date" => "নিবন্ধিত তারিখ",

    "Status" => "অবস্থা",

    "URL" => "CITY NAME (OPTIONAL,",

    "Register" => "নিবন্ধন",

    "Remove" => "অপসারণ করো",

    "Staff Id" => "স্টাফ আইডি",

    "Password" => "পাসওয়ার্ড",

    "Confirm Password" => "পাসওয়ার্ড কনফার্ম করো",

    "Re-Password" => "পাসওয়ার্ড",

    "Browse" => "ব্রাউজ",

    "Avatar" => "অ্যাভাটার",

    "Edit Staff Info" => "স্টাফ ইনফো সম্পাদনা",

    "Staff info has been updated Successfully" => "স্টাফ ইনফো সাফল্যের সাথে হালনাগাদ করা হয়েছে",

    "Staff has been added Successfully" => "স্টাফ সাফল্যের সাথে যোগ করা হয়েছে",

    "View" => "ভিউ",

    "Staff Info" => "স্টাফ ইনফো",

    "Close" => "বন্ধ করো",

    "Staff ID" => "স্টাফ আইডি",

    "Password did not match with your account password." => "আপনার অ্যাকাউন্ট পাসওয়ার্ডের সাথে পাসওয়ার্ড মিলছিল না.",

    "Put Your password" => "আপনার পাসওয়ার্ড রাখুন",

    "Staff has been deleted Successfully" => "স্টাফ সফলভাবে মুছে ফেলা হয়েছে",

    "Language" => "ভাষা",

    "Variant" => "ভ্যারিয়েন্ট",

    "Add Variant" => "ভেরিয়েন্ট যোগ করো",

    "Publish" => "পাবলিশ",

    "Published" => "প্রকাশিত",

    "Variation Values" => "ভেরিয়েশন মান",

    "Add Value" => "মান যোগ করো",

    "Edit Variant" => "ভেরিয়েন্ট সম্পাদনা",

    "Unit Type" => "একক টাইপ",

    "Add Unit Type" => "একক টাইপ যোগ করো",

    "Edit Unit Type" => "ইউনিট ধরন সম্পাদন করো",

    "Brand" => "ব্র্যান্ড",

    "Add Brand" => "ব্রান্ড যোগ করো",

    "Edit Brand" => "ব্রান্ড সম্পাদন করো",

    "Add Model" => "মডেল যোগ করো",

    "Edit Model" => "মডেল সম্পাদন করো",

    "Category" => "শ্রেণীবিভাগ",

    "Add Category" => "শ্রেণীবিভাগ যোগ করো",

    "Code" => "কোড",

    "Add as Sub Category" => "সাব শ্রেণীবিভাগ হিসাবে যোগ করো",

    "Select parent Category" => "প্যারেন্ট শ্রেণীবিভাগ নির্বাচন করুন",

    "Edit Category" => "শ্রেণীবিভাগ",

    "Add New Product" => "নতুন প্রোডাক্ট যোগ করো",

    "Product Name" => "প্রোডাক্ট নেম",

    "Product SKU" => "প্রোডাক্ট এসকেইউ",

    "Barcode Type" => "বারকোড টাইপ",

    "Unit" => "Unit-name",

    "Sub Category" => "সাব শ্রেণীবিভাগ",

    "Add File" => "ফাইল যোগ করো",

    "Manage Stock" => "স্টক পরিচালনা করুন",

    "Alert Quantity" => "অ্যালার্ট কোয়ান্টিটি",

    "Variation" => "বৈচিত্র্য",

    "Add Variation" => "ভেরিয়েশন যোগ করো",

    "Add Product" => "প্রোডাক্ট যোগ করো",

    "Edit Product" => "প্রোডাক্ট সম্পাদন করো",

    "Employee Id" => "কর্মচারী Id",

    "Address" => "ঠিকানা",

    "New Price Group" => "নতুন প্রাইস গ্রুপ",

    "Export" => "রপ্তানি করো",

    "SL" => "SL",

    "Cancel" => "বাতিল করো",

    "About" => "পরিচিতি",

    "letter" => "চিঠি",

    "date" => "তারিখ",

    "Date" => "তারিখ",

    "Image" => "ছবি",

    "File Not Found" => "ফাইল পাওয়া যায়না",

    "Download" => "ডাউনলোড করুন",

    "Are you sure to delete ?" => "আপনি কি মুছে ফেলতে নিশ্চিত?",

    "Are you sure to" => "আপনি কি নিশ্চিত",

    "Are you sure to enable this ?" => "আপনি কি এটা সক্রিয় করতে নিশ্চিত?",

    "Are You Sure To Change Status ?" => "আপনি কি স্ট্যাটাস বদলাতে নিশ্চিত?",

    "Are You Sure To Remove This?" => "আপনি কি নিশ্চিত?",

    "Role" => "Role",

    "List" => "তালিকা",

    "Add" => "যোগ করো",

    "Success" => "সফল",

    "Failed" => "ব্যর্থ",

    "Dashboard" => "ড্যাশবোর্ড",

    "User Logs" => "ব্যবহারকারী লগ",

    "Question & Answer" => "প্রশ্নউত্তর",

    "Comments" => "মন্তব্য",

    "Course" => "কোর্স",

    "Replies" => "পুনরাবৃত্তি",

    "Commented By" => "@ info: status",

    "Submitted" => "Submitted",

    "Enable" => "সক্রিয় করো",

    "Disable" => "নিষ্ক্রিয় করো",

    "Active" => "সক্রিয়",

    "Deactive" => "নিষ্ক্রিয়",

    "Inactive" => "নিষ্ক্রিয়",

    "Email Address" => "ই-মেইল ঠিকানা",

    "Instagram URL" => "ইনস্টাগ্রাম ইউআরএল",

    "Youtube URL" => "ইউটিউব ইউ-আর-এল",

    "LinkedIn URL" => "LinkedIn URL",

    "Twitter URL" => "টুইটার ইউআরএল",

    "Facebook URL" => "ফেসবুক ইউআরএল",

    "Date of Birth" => "জন্ম তারিখ",

    "Change Status" => "অবস্থা পরিবর্তন করো",

    "Start Date" => "শুরু তারিখ",

    "End Date" => "শেষ তারিখ",

    "Filter History" => "ফিল্টার ইতিহাস",

    "Reject" => "প্রত্যাখ্যান করুন",

    "Reason" => "Reason",

    "Payouts" => "পে-আউট",

    "Author" => "লেখক",

    "Available" => "উপস্থিত",

    "Issue Date" => "ইস্যু তারিখ",

    "Duration" => "দূরত্ব",

    "Change" => "পরিবর্তন",

    "Deactivate" => "নিষ্ক্রিয় করো",

    "Yes" => "হ্যাঁ",

    "Files" => "ফাইল",

    "File" => "ফাইল",

    "Send" => "প্রেরণ",

    "Paid" => "Paid",

    "Waiting" => "অপেক্ষা করা হচ্ছে",

    "Info" => "তথ্যName",

    "Zip Code" => "জিপ কোড",

    "Country" => "দেশ",

    "City" => "City name (optional,",

    "Submit" => "সাবমিট",

    "Error" => "ত্রুটি",

    "Warning" => "সতর্কীকরণ",

    "Used" => "ব্যবহার করা হয়েছে",

    "Join For Free" => "বিনামূল্যের জন্য যোগ দিন",

    "Enter Email" => "ই-মেইল লিখুন",

    "Enter Password" => "পাসওয়ার্ড লিখুন",

    "Enter Phone Number" => "ফোন নম্বর লিখুন",

    "Enter Confirm Password" => "পাসওয়ার্ড কনফার্ম করুন",

    "Update Profile" => "প্রোফাইল আপডেট করো",

    "Review" => "রিভিউ",

    "Log in with Facebook" => "ফেসবুকের সাথে লগ",

    "Log in with Google" => "গুগলের সাথে লগ",

    "Or" => "অথবা",

    "Keep me up to date on WCHAT" => "ইনফিক্স-এ আমাকে ডেট করতে দিন",

    "Required" => "আবশ্যক",

    "New" => "নতুন",

    "Instructor Payout" => "Instructor Payout",

    "Time Left" => "সময় বামে",

    "No Item found" => "কোনো আইটেম পাওয়া যায়নি",

    "Total Price" => "মোট মূল্য",

    "Discount or coupon info" => "Discount বা কুপন তথ্য",

    "Checkout" => "চেকআউট",

    "Apply" => "প্রয়োগ করো",

    "Course Schedule" => "কোর্স সূচী",

    "Add To Cart" => "Cart-এ যোগ করো",

    "Buy Now" => "এখন বাজি",

    "Lessons" => "লেসনস",

    "Bookmarks" => "বুকমার্ক",

    "Deposit" => "ডিপোজিট",

    "Referral" => "রেফারেরাল",

    "My Cart" => "আমার কার্ট",

    "Purchase History" => "ইতিহাস পূরন করো",

    "My Courses" => "আমার কোর্স",

    "Live Classes" => "লাইভ ক্লাস",

    "Already Enrolled" => "অনুমোদনের জন্য প্রস্তুত করা হয়েছে",

    "Student Enrolled" => "স্টুডেন্ট এনলল",

    "Already Submitted" => "Already Submitted",

    "Correct Answer" => "সঠিক উত্তর",

    "Wrong Answer" => "Wrong উত্তর",

    "Skip" => "স্কিপ",

    "Next" => "পরবর্তী",

    "Previous" => "পূর্ববর্তী",

    "Course File" => "কোর্স ফাইল",

    "Share" => "Share",

    "Course Files" => "কোর্স ফাইল",

    "Course Review" => "কোর্স রিভিউ",

    "Start Date & Time" => "তারিখ & সময় আরম্ভ করো",

    "At" => "এদিকে",

    "Show" => "দেখাও",

    "Drip Content" => "ড্রাইপ বিষয়বস্তু",

    "Specific Date" => "নির্দিষ্ট তারিখ",

    "Days After Enrollment" => "এনরোলমেন্টের দিন",

    "Show All" => "সব দেখাও",

    "Show After Unlock" => "আনলক দেখাও",

    "Aws S3 Setting" => "Aws S3 সেটিং",

    "Access Key Id" => "প্রবেশাধিকার কী Id",

    "Secret Key" => "সিক্রেট কী",

    "Default Region" => "পূর্বনির্ধারিত অঞ্চল",

    "AWS Bucket" => "AWS Bucket",

    "Module Manager" => "মডিউল ব্যবস্থাপক",

    "Payment Type" => "পেমেন্ট ধরন",

    "Blogs" => "ব্লগস",

    "Star" => "তারাstar name",

    "Total Courses" => "মোট কোর্স",

    "Discount" => "ডিসকাউন্ট",

    "Logo" => "লোগো",

    "My Quizzes" => "আমার কুইজেস",

    "Enroll Now" => "Enroll Now",

    "Added To Cart" => "Cart-এ যোগ করা হয়েছে",

    "Logged In Devices" => "লগ-ইন ডিভাইস",

    "Purchase Price" => "পার্স প্রাইস",

    "Pay" => "City name (optional,",

    "Welcome" => "স্বাগতম",

    "Minimum 8 characters" => "সর্বনিম্ন ৮ অক্ষর",

    "Status has been changed" => "অবস্থা পরিবর্তন করা হয়েছে",

    "For the demo version, you cannot change this" => "ডেমো সংস্করণের জন্য, আপনি এই পরিবর্তন করতে পারবেন না",

    "Video File" => "ভিডিও ফাইল",

    "Browse Video file" => "ভিডিও ফাইল ব্রাউজ করুন",

    "Select Date" => "তারিখ নির্বাচন করুন",

    "Days" => "দিন",

    "Operation successful" => "অপারেশন সফল",

    "Operation failed" => "অপারেশন ব্যর্থ",

    "Quick Search" => "দ্রুত অনুসন্ধান",

    "Copy" => "অনুলিপি করুন",

    "Excel" => "এক্সেল",

    "CSV" => "CSV",

    "PDF" => "PDF",

    "Print" => "মুদ্রণ করুন",

    "No data available in the table" => "টেবিলে কোন তথ্য পাওয়া যায়নি",

    "Successfully Assign" => "@ info: status",

    "Make Paid" => "পেইড তৈরি করো",

    "Request For Paid" => "সাহায্যের জন্য অনুসন্ধান",

    "End Date & Time" => "সমাপ্তির তারিখ ও সময়",

    "Short Description" => "সংক্ষিপ্ত বিবরণ",

    "No" => "না",

    "Website" => "ওয়েবসাইট",

    "Browse file" => "ফাইল ব্রাউজ করুন",

    "view_settings" => "প্রদর্শন সংক্রান্ত বৈশিষ্ট্য",

    "functional_settings" => "ফাংশনাল সেটিংস",

    "color" => "রং",

    "intro_text" => "পরিচিতি টেক্সট",

    "single_agent" => "একক এজেন্ট",

    "multi_agent" => "একাধিক এজেন্ট",

    "availability" => "অ্যাভেলিবিলিটি",

    "only_mobile" => "শুধুমাত্র মোবাইল",

    "only_desktop" => "শুধুমাত্র ডেস্কটপ",

    "both" => "উভয়",

    "showing_page" => "পৃষ্ঠা শেখাও",

    "only_homepage" => "শুধুমাত্র হোম পেজ",

    "all_page" => "শুধুমাত্র হোম পেজ",

    "popup_open_initially" => "পপ-আপ ওপেন প্রাথমিকভাবে",

    "agents" => "এজেন্টস",

    "agent_type" => "এজেন্ট ধরন",

    "homepage_url" => "Home Page Url",

    "whatsapp_support" => "WhatsApp সাপোর্ট",

    "primary_number" => "প্রাথমিক সংখ্যা",

    "agent" => "এজেন্ট",

    "create_agent" => "এজেন্ট তৈরি করো",

    "update_agent" => "এজেন্ট আপডেট করো",

    "number" => "নম্বর:",

    "add_agent" => "এজেন্ট যোগ করো",

    "designation" => "Designation",

    "avatar" => "অ্যাভাটার",

    "status" => "অবস্থা",

    "active" => "সক্রিয়",

    "inactive" => "সক্রিয়",

    "browse_avatar" => "অবতার ব্রাউজ করুন",

    "always_available" => "সর্বদা উপস্থিত",

    "analytics" => "বিশ্লেষক",

    "Search" => "অনুসন্ধান",

    "None" => "কেউই",

    "failed" => "এই পরিচয়গুলো আমাদের রেকর্ডের সাথে মিলছে না.",

    "Product Sku" => "প্রোডাক্ট স্কু",

    "dashboard" => "Dashboard",

    "reset" => "আপনার পাসওয়ার্ড রিসেট করা হয়েছে!",

    "previous" => "& laquo; পূর্ববর্তী",

    "next" => "পরবর্তী & রাউকো;",

    "Value" => "মান",

    "Sl" => "Sl",

    "Color" => "রং",

    "Agent" => "এজেন্ট",

    "Permission" => "অনুমতি",

    "assign_permission" => "অনুমতি স্বাক্ষর",

    "role_permission" => "Role Permission",

    "Pdf" => "Pdf",

    "Time" => "সময়",

    "In-Active" => "সক্রিয়",

    "Browse File" => "ফাইল ব্রাউজ করুন",

    "Backup" => "ব্যাকআপ",

    "Url" => "City name (optional,",

    "action" => "কাজ",

    "Database Backup List" => "ডাটাবেজ ব্যাকআপ তালিকা",

    "Generate New Backup" => "নতুন ব্যাকআপ তৈরি করো",

    "DeActive" => "ডিএক্টিভ",

    "Upload SQL File" => "SQL ফাইল আপলোড করো",

    "Confirmation" => "অনুমোদন",

    "download" => "ডাউনলোড করুন",

    "sl" => "SL",

    "IP" => "IP",

    "Settings" => "সেটিংস",

    "success" => "সফল রং",

    "Forget Password" => "পাসওয়ার্ড ভুলে যাও",

    "InActive" => "সক্রিয়",

    "Make Default" => "ডিফল্ট মান",

    "Key" => "কী",

    "Sender Name" => "সেন্ডারের নাম",

    "Send Test Mail" => "টেস্ট মেইল প্রেরণ করুন",

    "Send a Test Email to" => "একটি টেস্টের ইমেইল প্রেরণ করুন",

    "Predefined Footer" => "পূর্বনির্ধারিত ফুটার",

    "Predefined Header" => "পূর্বনির্ধারিত শীর্ষচরণ",

    "Email Signature" => "ই-মেইল স্বাক্ষর",

    "Sender Email" => "সেন্ডার ই-মেইল",

    "Email Protocol" => "ই-মেইল প্রোটোকল",

    "Mail Engine" => "মেইল ইঞ্জিন",

    "From Name" => "নাম থেকে",

    "From Mail" => "মেইল থেকে",

    "Mail Host" => "মেইল হোস্ট",

    "Mail Port" => "মেইল পোর্ট",

    "Mail Username" => "মেইল Username",

    "Mail Password" => "মেইল পাসওয়ার্ড",

    "Mail Encryption" => "মেইল এনক্রিপশন",

    "Email Charset" => "ই-মেইল চারসেট",

    "SMTP" => "SMTP",

    "System Settings" => "সিস্টেম সেটিংস",

    "Upload From Local Directory" => "স্থানীয় ডিরেক্টরি থেকে আপলোড করা হবে",

    "About System" => "সিস্টেমের পরিচিতি",

    "Software Version" => "সফটওয়্যার সংস্করণ",

    "Check update" => "আপডেট পরীক্ষা করুন",

    "PHP Version" => "PHP সংস্করণ",

    "Curl Enable" => "কার্ল সক্রিয়",

    "Purchase code" => "সংকেত কোড",

    "Install Domain" => "ডোমেইন ইনস্টল করো",

    "System Activated Date" => "সিস্টেম সক্রিয় করা তারিখ",

    "warning" => "সতর্কীকরণ রং",

    "Reset To Default" => "ডিফল্টকে রিসেট করো",

    "deactive" => " নিষ্ক্রিয় ",

    "reject" => " প্রত্যাখ্যান করুন ",

    "welcome" => " স্বাগতম ",

    "email" => "ই-মেইল",

    "close" => "বন্ধ করো",

    "view" => "ভিউ",

    "edit" => "সম্পাদনা",

    "login" => "লগ-ইন",

    "days" => "দিন",

    "paid" => "Paid",

    "print" => "মুদ্রণ করুন",

    "info" => "তথ্যName",

    "category" => "শ্রেণীবিভাগ",

    "save" => "সংরক্ষণ করো",

    "image" => "ছবি",

    "cancel" => "বাতিল করো",

    "title" => "শিরোনাম",

    "url" => "City name (optional,",

    "time" => "সময়",

    "password" => "পাসওয়ার্ড",

    "website" => "ওয়েবসাইট",

    "code" => "কোড",

    "discount" => "ডিসকাউন্ট",

    "id" => "Id",

    "details" => "বিস্তারিত বিবরণ",

    "language" => "ভাষা",

    "about" => "পরিচিতি",

    "role" => "Role",

    "theme" => "থিম",

    "change" => "পরিবর্তন",

    "address" => "ঠিকানা",

    "phone" => "ফোন",

    "currency" => "মুদ্রা",

    "username" => "Username",

    "general_settings" => "সাধারণ সেটিং",

    "logo" => "লোগো",

    "author" => "লেখক",

    "review" => "রিভিউ",

    "current" => "বর্তমান",

    "users" => "ব্যবহারকারীগণ",

    "free" => "মুক্ত",

    "register" => "নিবন্ধন",

    "upload" => "আপলোড",

    "review " => "রিভিউ",

    "filter" => "ফিল্টার",

    "comments" => "মন্তব্য",

    "duration" => "সময়কাল",

    "pay" => "City name (optional,",

    "or" => "অথবা",

    "Theme" => "থিম",

    "star" => "তারাstar name",

    "backup" => "ব্যাকআপ",

    "country" => "দেশ",

    "submit" => "সাবমিট",

    "apply" => "প্রয়োগ করো",

    "city" => "City name (optional,",

    "ip" => "IP",

    "staff" => "স্টাফ",

    "submitted" => "Submitted",

    "deposit" => "ডিপোজিট",

    "disable" => "নিষ্ক্রিয় করো",

    "enable" => "সক্রিয় করো",

    "payouts" => "পে-আউট",

    "live" => "লাইভ",

    "sandbox" => "স্যান্ডবক্স",

    "role_permission " => "Role Permission",

    "general_settings " => "সাধারণ বৈশিষ্ট্য",

    "logout " => "লগ-আউট",

    "copy" => "অনুলিপি করুন",

    "error" => "ত্রুটি",

    "rtl_ltl" => "RTL/LTL",

    "native_name" => "নেটিভ নেম",

    "key" => "কী",

    "value" => "মান",

    "edit_language_info" => "ভাষা তথ্য সম্পাদন করো",

    "Whatsapp support icon position" => "Whatsapp সমর্থন আইকন অবস্থান",

    "copy_script" => "এই স্ক্রিপ্ট কপি করুন এবং শরীরের ট্যাগ শেষ হওয়ার আগে এটি আপনার ওয়েবসাইটে পেস্ট করুন.",

    "update_user" => "ব্যবহারকারীর আপডেট করুন",

    "language_list" => "ভাষা তালিকা",

    "new_language" => "নতুন ভাষা",

    "translation" => "অনুবাদ",

    "create_user" => "ব্যবহারকারী তৈরি করুন",

    "add_user" => "ব্যবহারকারী যোগ করো",

    "icon_position" => "Whatsapp আইকন অবস্থান",

    "bottom_left" => "নীচে বামে",

    "bottom_right" => "নীচে ডানদিকে",

    "margin_from_bottom" => "নীচে থেকে মার্জিন",

    "margin_from_right" => "ডানদিক থেকে মার্জিন",

    "margin_from_left" => "বাঁদিক থেকে মারজিন",

    "layout_settings" => "বহির্বিন্যাস",

    "choose_layout" => "বিন্যাস বেছে নিন",

    "show_unavailable_agent_in_popup" => "পপ-আপ-এ বিদ্যমান কোন এজেন্ট দেখাও",

    "browser" => "ব্রাউজার",

    "operating_system" => "অপারেটিং সিস্টেম",

    "messages" => "বার্তা",

    "with_country_code" => "দেশ কোড দিয়ে আবশ্যক",

    "total_click" => "মোট ক্লিক",

    "clicks" => "ক্লিক",

    "click_from_mobile" => "মোবাইল থেকে ক্লিক করুন",

    "click_from_desktop" => "ডেস্কটপ থেকে ক্লিক করুন",

    "welcome_message" => "স্বাগতম বার্তা",

    "your_scripts" => "আপনার স্ক্রিপ্ট",

    "Sanitize No" => "সানিটিজ না",

    "Sanitize Yes" => "সানিটিজ হ্যাঁ",

    "3DS Yes" => "৩ডিএস হ্যাঁ",

    "3DS No" => "৩ডিএস না",

    "Module Verification" => "মডিউল ভেরিফিকেশন",

    "Envato Email Address" => "এনভাটো ই-মেইল ঠিকানা",

    "Envato Purchase Code" => "Envato Purchase Code",

    "Verifying" => "Verifying",

    "Subscription Api Key" => "Subscription Api কী",

    "Subscription Method" => "সাবস্ক্রীপশন পদ্ধতি",

    "Watch Now" => "এখন দেখো",

    "Continue Watch" => "@ title: group",

    "Start" => "আরম্ভ",

    "End" => "শেষ",

    "TimeZone" => "টাইমজোন",

    "File Name" => "ফাইলের নাম",

    "Mode" => "মোড",

    "Sub Title" => "সাব টাইটেল",

    "Default password will be" => "ডিফল্ট পাসওয়ার্ড হবে",

    "assign" => "স্বাক্ষর",

    "end" => "শেষ",

    "Apply All Days" => "সব দিন প্রয়োগ করো",

    "Are you sure to delete" => "আপনি কি মুছে ফেলতে নিশ্চিত",

    "Timetable" => "টাইমটেবল",

    "Update System" => "সিস্টেম আপডেট করো",

    "min_8" => "সর্বনিম্ন ৮ অক্ষর",

    "re_type" => "পুনঃপ্রকৃতি",

    "update_system" => "সিস্টেম আপডেট করো",

    "Timezone Name" => "টাইমজোন নাম",

    "Timezone Code" => "টাইমজোন কোড",

    "Advanced Filter" => "অগ্রসর ফিল্টার",

    "change_logo" => "লোগো পরিবর্তন করো",

    "change_fav" => "Fav বদলাও",

    "Delete confirmation message" => "বার্তা মুছে ফেলুন",

    "total_user" => "মোট ব্যবহারকারী",

    "total_agent" => "মোট এজেন্ট",

    "Unique Guest User" => "একক অতিথি ব্যবহারকারী",

    "Filter" => "ফিল্টার",

    "Timezone List" => "টাইমজোন তালিকা",

    "Quiz" => "কুইজ",

    "Email Configuration" => "ই-মেইল কনফিগারেশন",

    "Email Setup" => "ই-মেইল সেটআপ",

    "whatsapp bubble logo" => "Whatsapp বুদবুদ লোগো",

    "System Last Update" => "সিস্টেম শেষ আপডেট",

    "logout" => "লগ-আউট",

    "Create" => "তৈরি করো",

    "UserName" => "UserName",

    "LogIn" => "লগ-ইন",

    "CheckOut" => "চেকআউট",

    "hi_modal" => "হাই! স্বাগতম, আমি কিভাবে সাহায্য করতে পারি?",

    "Logout" => "লগ-আউট",

    "In-active" => "সক্রিয়",

    "disabled" => "নিষ্ক্রিয়",

    "Verify Your Email Address" => "আপনার ই-মেইল ঠিকানা মুছে ফেলো",

    "Click here to request another" => "আরেকটি অনুরোধ করতে এখানে ক্লিক করুন",

    "Before proceeding, please check your email for a verification link. If you did not receive the email" => "অগ্রসর হওয়ার আগে, অনুগ্রহ করে একটি যাচাই লিংকের জন্য আপনার ই-মেইল পরীক্ষা করুন. আপনি যদি ই-মেইল গ্রহণ না করেন",

    "usA fresh verification link has been sent to your email address.er" => "একটি তাজা যাচাইকরণ লিংক আপনার ই-মেইল ঠিকানায় পাঠানো হয়েছে.",

    "Super Admin" => "সুপার অ্যাডমিন",

    "Send Reset Password Link" => "পাসওয়ার্ড লিঙ্ক রিসেট পাঠাও",

    "Please confirm your password before continuing" => "অনুগ্রহ করে আপনার পাসওয়ার্ড অব্যাহত রাখার পূর্বে নিশ্চিত করুন",

    "Php Mail" => "Php মেইল",

    "Email Text" => "ই-মেইল টেক্সট",

    "whatsapp_chat" => "Whatsapp Chat",

    "To Mail" => "মেইলের জন্য",

    "site_title" => "সাইট শিরোনাম",

    "copy_right" => "ডান টেক্সট অনুলিপি করুন",

    "Mail Driver" => "মেইল ড্রাইভার",

];
