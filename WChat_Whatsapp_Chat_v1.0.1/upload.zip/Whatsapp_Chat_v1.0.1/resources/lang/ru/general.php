<?php
return [
    "Edit Timezone Info" => "Изменить информацию часового пояса",

    "Timezone has been deleted Successfully" => "Часовой пояс успешно удален",

    "hi_modal" => "Привет! Добро пожаловать, как я могу вам помочь?",

    "Confirmation" => "Подтверждение",

    "In-active" => "Активно",

    "disabled" => "выключено",

    "Verify Your Email Address" => "Проверьте Адрес Электронной Почты",

    "Click here to request another" => "Щелкните здесь, чтобы запросить другую",

    "Before proceeding, please check your email for a verification link. If you did not receive the email" => "Прежде чем продолжить, проверьте свою электронную почту для ссылки на проверку. Если вы не получили сообщение электронной почты",

    "usA fresh verification link has been sent to your email address.er" => "На ваш адрес электронной почты была отправлна свежая ссылка на проверку.",

    "Super Admin" => "Суперадминистратор",

    "Send Reset Password Link" => "Отправить ссылку на сброс пароля",

    "Please confirm your password before continuing" => "Подтвердите пароль перед продолжением",

    "Forget Password" => "Забыть пароль",

    "SMTP" => "SMTP",

    "Php Mail" => "Почта php",

    "site_title" => "Название сайта",

    "copy_right" => "Копировать правый текст",

    "Mail Driver" => "Драйвер почты",

    "login" => "вход в систему",

    "Email Text" => "Текст электронной почты",

    "whatsapp_chat" => "Чат Whatsapp",

    "To Mail" => "По почте",

    "Blogs" => "Блоги",

    "List" => "Список",

    "Create" => "Создать",

    "Show" => "Показать",

    "Title" => "Название",

    "Description" => "Описание",

    "Status" => "Состояние",

    "Image" => "Изображение",

    "SL" => "SL",

    "Course" => "Курс",

    "Category" => "Категория",

    "Code" => "Код",

    "Add" => "Добавить",

    "Type" => "Тип",

    "Start Date" => "Начальная дата",

    "End Date" => "Конечная дата",

    "Active" => "Активно",

    "Inactive" => "Неактивно",

    "Role" => "Роль",

    "Checkout" => "Резервирование",

    "Discount or coupon info" => "Скидка или информация о купоне",

    "My Cart" => "Моя тележка",

    "Apply" => "Применить",

    "Dashboard" => "Сводная панель",

    "Enable" => "Включить",

    "Disable" => "Выключить",

    "Duration" => "Продолжительность",

    "Logo" => "Логотип",

    "Browse" => "Обзор",

    "Update" => "Обновить",

    "ID" => "ИД",

    "Password" => "Пароль",

    "Yes" => "Да",

    "No" => "Нет",

    "Save" => "Сохранить",

    "Date" => "Дата",

    "Time" => "Время",

    "Start" => "Начало",

    "Select" => "Выбрать",

    "View" => "Вид",

    "Edit" => "Изменить",

    "Delete" => "Удалить",

    "Cancel" => "Отмена",

    "Name" => "Имя",

    "Details" => "Сведения",

    "Close" => "Закрыть",

    "Logout" => "Выход из системы",

    "Language" => "Язык",

    "Advanced Filter" => "Расширенный фильтр",

    "Filter" => "Фильтр",

    "URL" => "URL",

    "Publish" => "Опубликовать",

    "Add New" => "Добавить новое",

    "My Courses" => "Мои курсы",

    "Sub Category" => "Подкатегория",

    "Discount" => "Скидка",

    "Course File" => "Файл курса",

    "My Quizzes" => "Мои Викторины",

    "Video File" => "Видеофайл",

    "Browse Video file" => "Просмотр видеофайла",

    "failed" => "Эти учетные данные не соответствуют нашим записям.",

    "Send Email" => "Отправить электронную почту",

    "Make Default" => "Сделать по умолчанию",

    "Quiz" => "Quiz",

    "list" => "Список",

    "create" => "Создать",

    "browse" => "Обзор",

    "name" => "Имя",

    "update" => "Обновить",

    "settings" => "Параметры",

    "files" => "Файлы",

    "file" => "Файл",

    "new" => "Новый",

    "type" => "Тип",

    "send" => "Отправить",

    "delete" => "Удалить",

    "yes" => "Да",

    "select" => "Выбрать",

    "no" => "Нет",

    "user" => "Пользователь",

    "required" => "Обязательный",

    "permission" => "Разрешение",

    "remove" => "Удалить",

    "start" => "Начало",

    "to" => "В",

    "add" => "Добавить",

    "search" => "Поиск",

    "description" => "Описание",

    "Login" => "Вход",

    "View Profile" => "Просмотреть профиль",

    "My Profile" => "Мой профиль",

    "Profile Settings" => "Параметры профайла",

    "Current" => "Текущий",

    "Re-Type Password" => "Повторный тип пароля",

    "Type Password" => "Введите пароль",

    "Remember Me" => "Запомнить меня",

    "Login Details" => "Сведения о регистрации",

    "Forget Password ?" => "Забыть пароль?",

    "Need an account?" => "Нужна учетная запись?",

    "Sign Up" => "Подпись вверх",

    "Sign Up Details" => "Сведения о подписке",

    "You have already an account?" => "У тебя уже есть счет?",

    "Send Reset Link" => "Отправить ссылку на сброс",

    "Reset Password" => "Сбросить пароль",

    "Reset" => "Сброс",

    "Set New Password" => "Задать новый пароль",

    "Set Password" => "Задать пароль",

    "Start From" => "Начать с",

    "Start At" => "Запустить в",

    "To" => "В",

    "Free" => "Свободно",

    "Off" => "Выкл",

    "On" => "Вс",

    "Social Link" => "Социальная ссылка",

    "Active Status" => "Активное состояние",

    "Language List" => "Список языков",

    "Choose File" => "Выбрать файл",

    "Translation" => "Письменный перевод",

    "Currency" => "Валюта",

    "Action" => "Действие",

    "Live" => "Жить",

    "Sandbox" => "Изолировать",

    "Something Went Wrong" => "Что-то пошло не так",

    "Model" => "Модель",

    "Attempted At" => "Попытка",

    "User" => "Пользователь",

    "Activity Logs" => "Журналы операций",

    "Delete Confirmation" => "Подтверждение удаления",

    "Human Resource" => "Человеческий ресурс",

    "Staff" => "Сотрудники",

    "Staff List" => "Список персонала",

    "Username" => "Имя пользователя",

    "Email" => "Электронная почта",

    "Phone" => "Телефон",

    "Registered Date" => "Дата регистрации",

    "Register" => "Зарегистрировать",

    "Remove" => "Удалить",

    "Staff Id" => "ID персонала",

    "Confirm Password" => "Подтверждение пароля",

    "Re-Password" => "Повторный пароль",

    "Avatar" => "Аватар",

    "Edit Staff Info" => "Изменить информацию о сотруднике",

    "Staff info has been updated Successfully" => "Информация о сотруднике успешно обновлена",

    "Staff has been added Successfully" => "Сотрудники успешно добавлены",

    "Staff Info" => "Информация о персонале",

    "Staff ID" => "ID персонала",

    "Password did not match with your account password." => "Пароль не совпадает с паролем учетной записи.",

    "Put Your password" => "Введите пароль",

    "Staff has been deleted Successfully" => "Сотрудники успешно удалены",

    "Variant" => "Вариант",

    "Add Variant" => "Добавить вариант",

    "Published" => "Опубликовано",

    "Variation Values" => "Значения вариантов",

    "Add Value" => "Добавить значение",

    "Edit Variant" => "Изменить вариант",

    "Unit Type" => "Тип единицы",

    "Add Unit Type" => "Добавить тип единицы",

    "Edit Unit Type" => "Изменить тип единицы",

    "Brand" => "Бренд",

    "Add Brand" => "Добавить бренд",

    "Edit Brand" => "Изменить торговую марку",

    "Add Model" => "Добавить модель",

    "Edit Model" => "Изменить модель",

    "Add Category" => "Добавить категорию",

    "Add as Sub Category" => "Добавить как подкатегорию",

    "Select parent Category" => "Выбрать родительскую категорию",

    "Edit Category" => "Изменить категорию",

    "Add New Product" => "Добавить новый продукт",

    "Product Name" => "Имя продукта",

    "Product SKU" => "Артикул товара",

    "Barcode Type" => "Тип штрих-кода",

    "Unit" => "Единица",

    "Add File" => "Добавить файл",

    "Manage Stock" => "Управление запасами",

    "Alert Quantity" => "Количество оповещений",

    "Variation" => "Вариация",

    "Add Variation" => "Добавить вариант",

    "Add Product" => "Добавить продукт",

    "Edit Product" => "Изменить продукт",

    "Employee Id" => "ID сотрудника",

    "Address" => "Адрес",

    "New Price Group" => "Новая группа цен",

    "Export" => "Экспорт",

    "About" => "О",

    "letter" => "буква",

    "date" => "дата",

    "File Not Found" => "Файл не найден",

    "Download" => "Загрузить",

    "Are you sure to delete ?" => "Вы действительно хотите удалить?",

    "Are you sure to" => "Вы уверены, что",

    "Are you sure to enable this ?" => "Вы действительно хотите включить это?",

    "Are You Sure To Change Status ?" => "Вы Действительно Хотите Изменить Состояние?",

    "Are You Sure To Remove This?" => "Вы Действительно Хотите Удалить Это?",

    "Success" => "Успешно",

    "Failed" => "Сбой",

    "User Logs" => "Журналы пользователей",

    "Question & Answer" => "Вопрос и ответ",

    "Comments" => "Комментарии",

    "Replies" => "Ответы",

    "Commented By" => "Автор комментария",

    "Submitted" => "Представлено",

    "Deactive" => "Деактивный",

    "Email Address" => "Адрес электронной почты",

    "Instagram URL" => "URL Instagram",

    "Youtube URL" => "URL Youtube",

    "LinkedIn URL" => "URL LinkedIn",

    "Twitter URL" => "URL Twitter",

    "Facebook URL" => "URL Facebook",

    "Date of Birth" => "Дата рождения",

    "Change Status" => "Изменить состояние",

    "Filter History" => "Хронология фильтра",

    "Reject" => "Отклонить",

    "Reason" => "Причина",

    "Payouts" => "Выплаты",

    "Author" => "Автор",

    "Available" => "Доступно",

    "Issue Date" => "Дата выдачи",

    "Change" => "Изменение",

    "Deactivate" => "Деактивировать",

    "Files" => "Файлы",

    "File" => "Файл",

    "Send" => "Отправить",

    "Paid" => "Оплачено",

    "Waiting" => "Ожидание",

    "Info" => "Информация",

    "Zip Code" => "Почтовый индекс",

    "Country" => "Страна",

    "City" => "Город",

    "Submit" => "Передать",

    "Error" => "Ошибка",

    "Warning" => "Предупреждение",

    "Used" => "Использовано",

    "Join For Free" => "Присоединиться к свободному",

    "Enter Email" => "Введите электронную почту",

    "Enter Password" => "Введите пароль",

    "Enter Phone Number" => "Введите номер телефона",

    "Enter Confirm Password" => "Введите подтверждение пароля",

    "Update Profile" => "Обновить профайл",

    "Review" => "Обзор",

    "Log in with Facebook" => "Войдите в систему Facebook",

    "Log in with Google" => "Войти в систему с помощью Google",

    "Or" => "Или",

    "Keep me up to date on WCHAT" => "Держите меня до свидания.",

    "Required" => "Обязательный",

    "New" => "Новый",

    "Instructor Payout" => "Payout инструктора",

    "Time Left" => "Левое время",

    "No Item found" => "Элемент не найден",

    "Total Price" => "Общая цена",

    "Course Schedule" => "Расписание курса",

    "Add To Cart" => "Добавить в корзину",

    "Buy Now" => "Купить сейчас",

    "Lessons" => "Уроки",

    "Bookmarks" => "Закладки",

    "Deposit" => "Депозит",

    "Referral" => "Передача",

    "Purchase History" => "Хронология покупок",

    "Live Classes" => "Живые классы",

    "Already Enrolled" => "Уже зачислено",

    "Student Enrolled" => "Зачисленный студент",

    "Already Submitted" => "Уже передано",

    "Correct Answer" => "Правильный ответ",

    "Wrong Answer" => "Неправильный ответ",

    "Skip" => "Пропустить",

    "Next" => "Далее",

    "Previous" => "Предыдущая",

    "Share" => "Совместное использование",

    "Course Files" => "Файлы курса",

    "Course Review" => "Обзор курса",

    "Start Date & Time" => "Дата и время начала",

    "At" => "В",

    "Drip Content" => "Содержимое капель",

    "Specific Date" => "Конкретная дата",

    "Days After Enrollment" => "Дней после регистрации",

    "Show All" => "Показать все",

    "Show After Unlock" => "Показать после разблокировки",

    "Aws S3 Setting" => "Параметр Aws S3",

    "Access Key Id" => "ИД ключа доступа",

    "Secret Key" => "Секретный ключ",

    "Default Region" => "Регион по умолчанию",

    "AWS Bucket" => "Блок AWS",

    "Module Manager" => "Менеджер модулей",

    "Payment Type" => "Тип платежа",

    "Star" => "Звезда",

    "Total Courses" => "Всего курсов",

    "Enroll Now" => "Зарегистрировать сейчас",

    "Added To Cart" => "Добавлено в корзину",

    "Logged In Devices" => "Вошедшие в систему устройства",

    "Purchase Price" => "Закупочная цена",

    "Pay" => "Оплата труда",

    "Welcome" => "Приветствие",

    "Minimum 8 characters" => "Минимум 8 символов",

    "Status has been changed" => "Состояние изменено",

    "For the demo version, you cannot change this" => "Для демо-версии изменить нельзя",

    "Select Date" => "Выбрать дату",

    "Days" => "Дни",

    "Operation successful" => "Операция выполнена успешно",

    "Operation failed" => "Операция не выполнена",

    "Quick Search" => "Быстрый поиск",

    "Copy" => "Копировать",

    "Excel" => "Excel",

    "CSV" => "CSV",

    "PDF" => "PDF",

    "Print" => "Печать",

    "No data available in the table" => "В таблице нет данных",

    "Successfully Assign" => "Успешно назначить",

    "Make Paid" => "Сделать платным",

    "Request For Paid" => "Просьба О Выплате",

    "End Date & Time" => "Дата и время окончания",

    "Short Description" => "Краткое описание",

    "Website" => "Вебсайт",

    "Browse file" => "Просмотреть файл",

    "view_settings" => "Показать параметры",

    "functional_settings" => "Функциональные параметры",

    "color" => "Цвет",

    "agents" => "Агенты",

    "intro_text" => "Введение",

    "single_agent" => "Один агент",

    "multi_agent" => "Несколько агентов",

    "availability" => "Доступность",

    "only_mobile" => "Только мобильный",

    "only_desktop" => "Только рабочий стол",

    "both" => "Оба",

    "showing_page" => "Отображение страницы",

    "only_homepage" => "Только домашняя страница",

    "all_page" => "Все страницы",

    "popup_open_initially" => "Открыть сначала всплывающее окно",

    "agent_type" => "Тип агента",

    "homepage_url" => "URL домашней страницы",

    "whatsapp_support" => "Поддержка WhatsApp",

    "primary_number" => "Основной номер",

    "agent" => "Агент",

    "create_agent" => "Создать агент",

    "update_agent" => "Обновить агент",

    "number" => "Число",

    "add_agent" => "Добавить агент",

    "designation" => "Обозначение",

    "avatar" => "Аватар",

    "status" => "Состояние",

    "active" => "Активно",

    "inactive" => "В активном состоянии",

    "browse_avatar" => "Обзор Avatar",

    "always_available" => "Всегда доступен",

    "analytics" => "Аналитика",

    "layout_settings" => "Параметр макета",

    "choose_layout" => "Выберите макет",

    "show_unavailable_agent_in_popup" => "Показать недоступный агент во всплывающем окне",

    "id" => "ИД",

    "ip" => "IP",

    "browser" => "Браузер",

    "operating_system" => "Операционная система",

    "messages" => "Сообщения",

    "total_click" => "Всего щелчков",

    "clicks" => "Щелчки",

    "click_from_mobile" => "Щелкните по мобильному",

    "click_from_desktop" => "Щелкните на рабочем столе",

    "action" => "Действие",

    "rtl_ltl" => "RTL/LTL",

    "code" => "Код",

    "Timetable" => "Расписание",

    "System Activated Date" => "Дата активации системы",

    "Install Domain" => "Установить домен",

    "Purchase code" => "Код покупки",

    "Curl Enable" => "Включить curl",

    "PHP Version" => "Версия PHP",

    "Check update" => "Проверить обновление",

    "Software Version" => "Версия программы",

    "About System" => "О системе",

    "Upload From Local Directory" => "Закачать Из Локального Каталога",

    "Update System" => "Обновить систему",

    "Default password will be" => "Пароль по умолчанию будет",

    "native_name" => "Собственное имя",

    "min_8" => "Минимум 8 символов",

    "re_type" => "Повторный тип",

    "update_system" => "Обновить систему",

    "key" => "Ключ",

    "value" => "Значение",

    "edit_language_info" => "Изменить информацию о языке",

    "users" => "Пользователи",

    "Whatsapp support icon position" => "Положение значка поддержки Whatsapp",

    "copy_script" => "Скопируйте этот сценарий и вставьте его на веб-сайт перед тем, как оканчивать тег body",

    "update_user" => "Обновить пользователя",

    "email" => "Электронная почта",

    "language_list" => "Список языков",

    "new_language" => "Новый язык",

    "translation" => "Письменный перевод",

    "create_user" => "Создать пользователя",

    "System Settings" => "Параметры системы",

    "assign" => "Назначить",

    "add_user" => "Добавить пользователя",

    "icon_position" => "Положение значка Whatsapp",

    "bottom_left" => "Нижний левый",

    "bottom_right" => "Справа внизу",

    "margin_from_bottom" => "Маржа снизу",

    "margin_from_right" => "Отступ от правого",

    "margin_from_left" => "Отступ слева",

    "role_permission" => "Права доступа роли",

    "end" => "Конец",

    "time" => "Время",

    "Apply All Days" => "Применить все дни",

    "Are you sure to delete" => "Вы действительно хотите удалить",

    "with_country_code" => "Код страны должен быть",

    "welcome_message" => "Приветственное сообщение",

    "your_scripts" => "Ваши сценарии",

    "Sanitize No" => "Sanitize No",

    "Sanitize Yes" => "Sanitize Да",

    "3DS Yes" => "3DS Да",

    "3DS No" => "3DS Нет",

    "Module Verification" => "Проверка модуля",

    "Envato Email Address" => "Адрес электронной почты Envato",

    "Envato Purchase Code" => "Код покупки Envato",

    "Verifying" => "Проверка",

    "None" => "Нет",

    "Subscription Api Key" => "Ключ Api подписки",

    "Subscription Method" => "Метод подписки",

    "Watch Now" => "Смотреть сейчас",

    "Continue Watch" => "Продолжить отслеживание",

    "End" => "Конец",

    "TimeZone" => "Часовой пояс",

    "Backup" => "Резервное копирование",

    "Upload SQL File" => "Закачать файл SQL",

    "Database Backup List" => "Список резервных копий базы данных",

    "Generate New Backup" => "Создать новое резервное копирование",

    "File Name" => "Имя файла",

    "Theme" => "Тема",

    "Reset To Default" => "Восстановить значения по умолчанию",

    "Mode" => "Режим",

    "Sub Title" => "Подзаголовок",

    "general_settings" => "Общие параметры",

    "Timezone Name" => "Имя часового пояса",

    "Timezone Code" => "Код часового пояса",

    "upload" => "Закачать",

    "change_logo" => "Изменить логотип",

    "change_fav" => "Изменить Fav",

    "Delete confirmation message" => "Удалить сообщение подтверждения",

    "assign_permission" => "Присвоить права доступа",

    "role" => "Роль",

    "total_user" => "Общий пользователь",

    "total_agent" => "Общий агент",

    "Unique Guest User" => "Уникальный гостевой пользователь",

    "Timezone List" => "Список часовых пояс",

    "submit" => "Передать",

    "Email Configuration" => "Конфигурация электронной почты",

    "Send Test Mail" => "Отправить тестовое сообщение",

    "Send a Test Email to" => "Отправить тестовый адрес электронной почты в",

    "Predefined Footer" => "Предопределенный нижний колонтитул",

    "Predefined Header" => "Предопределенный заголовок",

    "Email Signature" => "Подпись электронной почты",

    "Sender Email" => "Электронная почта отправителя",

    "Sender Name" => "Имя отправителя",

    "Email Protocol" => "Протокол электронной почты",

    "Mail Engine" => "Почтовый модуль",

    "From Name" => "От имени",

    "From Mail" => "Из почты",

    "Mail Host" => "Хост почты",

    "Mail Port" => "Почтовый порт",

    "Mail Username" => "Имя пользователя почты",

    "Mail Password" => "Пароль для почты",

    "Mail Encryption" => "Шифрование почты",

    "Email Charset" => "Набор символов электронной почты",

    "Email Setup" => "Настройка электронной почты",

    "whatsapp bubble logo" => "Логотип Whatsapp",

    "System Last Update" => "Последнее обновление системы",

];
