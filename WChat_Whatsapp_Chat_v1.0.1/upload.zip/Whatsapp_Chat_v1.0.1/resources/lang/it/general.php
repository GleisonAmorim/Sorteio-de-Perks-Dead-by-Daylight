<?php
return [
    "Timetable" => "Calendario",

    "System Activated Date" => "Data Attivata sistema",

    "Install Domain" => "Installazione dominio",

    "Purchase code" => "Codice di acquisto",

    "Curl Enable" => "Abilitazione di Curl",

    "PHP Version" => "Versione PHP",

    "Check update" => "Controllo aggiornamento",

    "Software Version" => "Versione software",

    "About System" => "Informazioni su Sistema",

    "Upload From Local Directory" => "Carica da Directory locale",

    "Update System" => "Sistema di aggiornamento",

    "min_8" => "Minimo 8 carattere",

    "re_type" => "Re - Tipo",

    "update_system" => "Sistema di aggiornamento",

    "failed" => "Queste credenziali non corrispondono ai nostri record.",

    "Dashboard" => "Dashboard",

    "Enable" => "Abilitare",

    "Disable" => "Disabilitare",

    "Duration" => "Durata",

    "Logo" => "Logo",

    "Browse" => "Sfoglia",

    "Update" => "Aggiornamento",

    "ID" => "ID",

    "Password" => "Password",

    "Add" => "Aggiungi",

    "List" => "Elenco",

    "Yes" => "Sì",

    "No" => "No",

    "Description" => "Descrizione",

    "Save" => "Salva",

    "Date" => "Data",

    "Time" => "Tempo",

    "Start" => "Inizio",

    "Select" => "Seleziona",

    "View" => "Vista",

    "Edit" => "Modifica",

    "Delete" => "Elimina",

    "Cancel" => "Annulla",

    "Name" => "Nome",

    "Status" => "Stato",

    "Details" => "Dettagli",

    "Close" => "Stato",

    "Blogs" => "Blog",

    "Create" => "Crea",

    "Show" => "Mostra",

    "Title" => "Titolo",

    "Image" => "Immagine",

    "SL" => "SL",

    "Send Email" => "Invia Email",

    "Course" => "Corso",

    "Category" => "Categoria",

    "Code" => "Codice",

    "Type" => "Tipo di corso",

    "Start Date" => "Data di inizio",

    "End Date" => "Data di fine",

    "Active" => "Attivo",

    "Inactive" => "Inattivo",

    "Role" => "Ruolo",

    "Checkout" => "Checkout",

    "Discount or coupon info" => "Sconto o info coupon",

    "My Cart" => "My Cart",

    "Apply" => "Applicare",

    "list" => "Elenco",

    "create" => "Crea",

    "browse" => "Sfoglia",

    "name" => "Nome",

    "update" => "Aggiornamento",

    "settings" => "Impostazioni",

    "files" => "File",

    "file" => "File",

    "new" => "Nuovo",

    "type" => "Tipo",

    "send" => "Invia",

    "delete" => "Elimina",

    "yes" => "Sì",

    "select" => "Seleziona",

    "no" => "No",

    "user" => "Utente",

    "required" => "Richiesto",

    "permission" => "Autorizzazione",

    "remove" => "Rimuovi",

    "start" => "Inizio",

    "to" => "A",

    "add" => "Aggiungi",

    "search" => "Ricerca",

    "description" => "Descrizione",

    "Make Default" => "Rendi predefinito",

    "Login" => "Login",

    "View Profile" => "Visualizza profilo",

    "My Profile" => "Il mio profilo",

    "Profile Settings" => "Impostazioni del profilo",

    "Current" => "Corrente",

    "Re-Type Password" => "Password di tipo Reo",

    "Type Password" => "Password di tipo",

    "Remember Me" => "Ricorda Me",

    "Login Details" => "Dettagli di login",

    "Forget Password ?" => "Dimenticare Password?",

    "Need an account?" => "Serve un account?",

    "Sign Up" => "Firma Up",

    "Sign Up Details" => "Dettagli di sign Up",

    "You have already an account?" => "Hai già un account?",

    "Send Reset Link" => "Invia Reset Link",

    "Reset Password" => "Reimposta password",

    "Reset" => "Reset",

    "Set New Password" => "Imposta nuova password",

    "Set Password" => "Imposta password",

    "Start From" => "Inizio da",

    "Start At" => "Inizia a",

    "To" => "A",

    "Free" => "Libero",

    "Off" => "Off",

    "On" => "Su",

    "Social Link" => "Collegamento sociale",

    "Active Status" => "Stato attivo",

    "Language List" => "Elenco lingue",

    "Choose File" => "Scegli file",

    "Translation" => "Traduzione",

    "Currency" => "Valuta",

    "Add New" => "Aggiungi nuovo",

    "Action" => "Azione",

    "Live" => "Vivere",

    "Sandbox" => "Sandbox",

    "Something Went Wrong" => "Qualcosa È Andato Storto",

    "Model" => "Modello",

    "Attempted At" => "Tentativo di At",

    "User" => "Utente",

    "Activity Logs" => "Log Attività",

    "Delete Confirmation" => "Elimina Conferma",

    "Human Resource" => "Risorsa umana",

    "Staff" => "Personale",

    "Staff List" => "Elenco personale",

    "Username" => "Username",

    "Email" => "Email",

    "Phone" => "Telefono",

    "Registered Date" => "Data registrata",

    "URL" => "URL",

    "Register" => "Registro",

    "Remove" => "Rimuovi",

    "Staff Id" => "Id del personale",

    "Confirm Password" => "Conferma password",

    "Re-Password" => "Re - Password",

    "Avatar" => "Avatar",

    "Edit Staff Info" => "Modifica informazioni Staff",

    "Staff info has been updated Successfully" => "Le info staff sono state aggiornate Successpienamente",

    "Staff has been added Successfully" => "Il personale è stato aggiunto Successpienamente",

    "Staff Info" => "Info personale",

    "Staff ID" => "ID personale",

    "Password did not match with your account password." => "La password non è partita con la password dell'account.",

    "Put Your password" => "Metti la password",

    "Staff has been deleted Successfully" => "Il personale è stato cancellato Successpienamente",

    "Language" => "Lingua",

    "Variant" => "Variante",

    "Add Variant" => "Aggiungi variante",

    "Publish" => "Pubblica",

    "Published" => "Pubblicato",

    "Variation Values" => "Valori di variazione",

    "Add Value" => "Aggiungi valore",

    "Edit Variant" => "Modifica variante",

    "Unit Type" => "Tipo di unità",

    "Add Unit Type" => "Aggiungi tipo di unità",

    "Edit Unit Type" => "Modifica tipo di unità",

    "Brand" => "Marchio",

    "Add Brand" => "Aggiungi Brand",

    "Edit Brand" => "Modifica Brand",

    "Add Model" => "Aggiungi modello",

    "Edit Model" => "Modifica modello",

    "Add Category" => "Aggiungi categoria",

    "Add as Sub Category" => "Aggiungi come sottocategoria",

    "Select parent Category" => "Seleziona categoria principale",

    "Edit Category" => "Modifica categoria",

    "Add New Product" => "Aggiungi nuovo prodotto",

    "Product Name" => "Nome prodotto",

    "Product SKU" => "SKU prodotto",

    "Barcode Type" => "Tipo di codice",

    "Unit" => "Unità",

    "Sub Category" => "Categoria secondaria",

    "Add File" => "Aggiungi file",

    "Manage Stock" => "Gestione Stock",

    "Alert Quantity" => "Quantità Avviso",

    "Variation" => "Variazione",

    "Add Variation" => "Aggiungi Variazione",

    "Add Product" => "Aggiungi prodotto",

    "Edit Product" => "Modifica prodotto",

    "Employee Id" => "Id dipendente",

    "Address" => "Indirizzo",

    "New Price Group" => "Nuovo gruppo di prezzo",

    "Export" => "Esportazione",

    "About" => "Informazioni su",

    "letter" => "lettera",

    "date" => "data",

    "File Not Found" => "File non trovato",

    "Download" => "Scarica",

    "Are you sure to delete ?" => "Sei sicuro di eliminare?",

    "Are you sure to" => "Sei sicuro di",

    "Are you sure to enable this ?" => "Sei sicuro di abilitare questo?",

    "Are You Sure To Change Status ?" => "Sei sicuro To Change Status?",

    "Are You Sure To Remove This?" => "Sei sicuro di Rimuovi questo?",

    "Success" => "Successo",

    "Failed" => "Non riuscito",

    "User Logs" => "Log Utente",

    "Question & Answer" => "Domanda & Risposta",

    "Comments" => "Commenti",

    "Replies" => "Risposte",

    "Commented By" => "Commentato da",

    "Submitted" => "Presentato",

    "Deactive" => "Deattivo",

    "Email Address" => "Indirizzo email",

    "Instagram URL" => "URL instagram",

    "Youtube URL" => "URL youtube",

    "LinkedIn URL" => "URL linkedIn",

    "Twitter URL" => "URL di Twitter",

    "Facebook URL" => "URL di Facebook",

    "Date of Birth" => "Data di nascita",

    "Change Status" => "Stato di modifica",

    "Filter History" => "Cronologia dei filtri",

    "Reject" => "Rifiuto",

    "Reason" => "Motivo",

    "Payouts" => "Payout",

    "Author" => "Autore",

    "Available" => "Disponibile",

    "Issue Date" => "Data di rilascio",

    "Change" => "Modifica",

    "Deactivate" => "Disattivare",

    "Files" => "File",

    "File" => "File",

    "Send" => "Invia",

    "Paid" => "Pagato",

    "Waiting" => "Attesa",

    "Info" => "Info",

    "Zip Code" => "Codice zip",

    "Country" => "Paese",

    "City" => "Città",

    "Submit" => "Invia",

    "Error" => "Errore",

    "Warning" => "Avviso",

    "Used" => "Usato",

    "Join For Free" => "Join Per Free",

    "Enter Email" => "Inserire Email",

    "Enter Password" => "Inserire password",

    "Enter Phone Number" => "Inserire il numero di telefono",

    "Enter Confirm Password" => "Inserisce la password",

    "Update Profile" => "Profilo di aggiornamento",

    "Review" => "Revisione",

    "Log in with Facebook" => "Accedi con Facebook",

    "Log in with Google" => "Accedi con Google",

    "Or" => "Oppure",

    "Keep me up to date on WCHAT" => "Tenetemi aggiornato su WCHAT",

    "Required" => "Richiesto",

    "New" => "Nuovo",

    "Instructor Payout" => "Payout istruttore",

    "Time Left" => "Sinistra del tempo",

    "No Item found" => "Nessun articolo trovato",

    "Total Price" => "Prezzo totale",

    "Course Schedule" => "Pianificazione del corso",

    "Add To Cart" => "Aggiungi Al Carrello",

    "Buy Now" => "Compra ora",

    "Lessons" => "Lezioni",

    "Bookmarks" => "Segnalibri",

    "Deposit" => "Deposito",

    "Referral" => "Rinvio",

    "Purchase History" => "Cronologia di acquisto",

    "My Courses" => "I Miei Corsi",

    "Live Classes" => "Classi Live",

    "Already Enrolled" => "Già Iscritto",

    "Student Enrolled" => "Studente Iscritto",

    "Already Submitted" => "Già Inoltrato",

    "Quiz" => "Quiz",

"Correct Answer" => "Risposta Corretta",

"Wrong Answer" => "Risposta Sbagliata",

"Skip" => "Skip",

"Next" => "Successivo",

"Previous" => "Precedente",

"Course File" => "File del corso",

"Share" => "Condividi",

"Course Files" => "File di corso",

"Course Review" => "Revisione del corso",

"Start Date & Time" => "Data inizio & ora",

"At" => "A",

"Drip Content" => "Contenuto di drip",

"Specific Date" => "Data specifica",

"Days After Enrollment" => "Giorni Dopo l'iscrizione",

"Show All" => "Mostra tutto",

"Show After Unlock" => "Mostra After Unlock",

"Aws S3 Setting" => "Aws S3 Impostazione",

"Access Key Id" => "Id chiave di accesso",

"Secret Key" => "Chiave segreta",

"Default Region" => "Regione predefinita",

"AWS Bucket" => "AWS Bucket",

"Module Manager" => "Gestore del modulo",

"Payment Type" => "Tipo di pagamento",

"Star" => "Stella",

"Total Courses" => "Totale Corsi",

"Discount" => "Sconto",

"My Quizzes" => "I miei Quizzi",

"Enroll Now" => "Iscrivi ora",

"Added To Cart" => "Aggiunto Al Carrello",

"Logged In Devices" => "Periferiche registrate",

"Purchase Price" => "Prezzo di acquisto",

"Pay" => "Paga",

"Welcome" => "Benvenuto",

"Minimum 8 characters" => "Minimo 8 caratteri",

"Status has been changed" => "Lo stato è stato modificato",

"For the demo version, you cannot change this" => "Per la versione demo non è possibile modificare questo",

"Video File" => "File video",

"Browse Video file" => "Sfoglia file video",

"Select Date" => "Seleziona data",

"Days" => "Giorni",

"Operation successful" => "Funzionamento riuscito",

"Operation failed" => "Operazione non riuscita",

"Quick Search" => "Ricerca rapida",

"Copy" => "Copia",

"Excel" => "Excel",

"CSV" => "CSV",

"PDF" => "PDF",

"Print" => "Stampa",

"No data available in the table" => "Nessun dato disponibile nella tabella",

"Successfully Assign" => "Assegnare Correttamente",

"Make Paid" => "Marca Pagata",

"Request For Paid" => "Richiesta Di Pagamento",

"End Date & Time" => "Data e ora di fine",

"Short Description" => "Descrizione breve",

"Website" => "Sito web",

"Browse file" => "Sfoglia file",

"phone" => "Telefono",

"address" => "Indirizzo",

"Sub Title" => "Titolo secondario",

"view_settings" => "Impostazioni vista",

"functional_settings" => "Impostazioni funzionali",

"color" => "Colore",

"agents" => "Agenti",

"intro_text" => "Introduzione testo",

"single_agent" => "Agente singolo",

"multi_agent" => "Agent multiplo",

"availability" => "Disponibilità",

"only_mobile" => "Solo Mobile",

"only_desktop" => "Solo Desktop",

"both" => "Entrambi",

"showing_page" => "Visualizzazione pagina",

"only_homepage" => "Solo Home Page",

"all_page" => "Tutte le pagine",

"popup_open_initially" => "Popup Open Inizialmente",

"agent_type" => "Tipo di agente",

"homepage_url" => "Home Page Url",

"whatsapp_support" => "Supporto whatsApp",

"primary_number" => "Numero principale",

"agent" => "Agente",

"create_agent" => "Crea agent",

"update_agent" => "Agent di aggiornamento",

"number" => "Numero",

"add_agent" => "Aggiungi agente",

"designation" => "Designazione",

"avatar" => "Avatar",

"status" => "Stato",

"active" => "Attivo",

"inactive" => "In - Attivo",

"browse_avatar" => "Sfoglia Avatar",

"always_available" => "Sempre disponibile",

"analytics" => "Analytics",

"rtl_ltl" => "RTL/LTL",

"code" => "Codice",

"Default password will be" => "La password predefinita sarà",

"native_name" => "Nome nativo",

"key" => "Chiave",

"value" => "Valore",

"edit_language_info" => "Modifica info lingua",

"users" => "Utenti",

"Whatsapp support icon position" => "Posizione icona di supporto whatsapp",

"copy_script" => "Copiare questo script e incollarlo sul tuo sito web prima che il tag body finisca.",

"update_user" => "Utente di aggiornamento",

"email" => "Email",

"language_list" => "Elenco lingue",

"new_language" => "Nuova lingua",

"translation" => "Traduzione",

"create_user" => "Crea utente",

"System Settings" => "Impostazioni di sistema",

"assign" => "Assegnazione",

"add_user" => "Aggiungi utente",

"icon_position" => "Posizione Icona Whatsapp",

"bottom_left" => "Sinistra inferiore",

"bottom_right" => "Destra inferiore",

"margin_from_bottom" => "Margine Dal Basso",

"margin_from_right" => "Margine Da destra",

"margin_from_left" => "Margine Da sinistra",

"role_permission" => "Autorizzazione Ruolo",

"layout_settings" => "Impostazione del layout",

"choose_layout" => "Scegliere Layout",

"show_unavailable_agent_in_popup" => "Mostra agente non disponibile in popup",

"end" => "Fine",

"time" => "Tempo",

"Apply All Days" => "Applica tutti i giorni",

"Are you sure to delete" => "Sei sicuro di eliminare",

"id" => "ID",

"ip" => "IP",

"browser" => "Browser",

"operating_system" => "Sistema operativo",

"messages" => "Messaggi",

"with_country_code" => "Con il codice paese è necessario",

"total_click" => "Totale Click",

"clicks" => "Click",

"click_from_mobile" => "Clicca da Mobile",

"click_from_desktop" => "Click Da Desktop",

"action" => "Azione",

"welcome_message" => "Messaggio di benvenuto",

"your_scripts" => "I Tuoi Script",

"Sanitize No" => "Sanitizzare n.",

"Sanitize Yes" => "Sanitizzare Sì",

"3DS Yes" => "3DS Sì",

"3DS No" => "3DS n.",

"Module Verification" => "Verifica Modulo",

"Envato Email Address" => "Indirizzo Email Envato",

"Envato Purchase Code" => "Codice Acquisto Envato",

"Verifying" => "Verifica",

"None" => "Nessuno",

"Subscription Api Key" => "Chiave Api di abbonamento",

"Subscription Method" => "Metodo di sottoscrizione",

"Watch Now" => "Guarda ora",

"Continue Watch" => "Continua Watch",

"End" => "Fine",

"TimeZone" => "TimeZone",

"Backup" => "Backup",

"Upload SQL File" => "Carica file SQL",

"Database Backup List" => "Elenco backup database",

"Generate New Backup" => "Genera nuovo backup",

"File Name" => "Nome file",

"Theme" => "Tema",

"Reset To Default" => "Reimposta a default",

"Mode" => "Modalità",

];
