<?php
return [
    "search" => "搜索",

    "Timetable" => "时间表",

    "System Activated Date" => "系统激活日期",

    "Install Domain" => "安装域",

    "Purchase code" => "采购代码",

    "Curl Enable" => "Curl 启用",

    "PHP Version" => "PHP 版本",

    "Check update" => "检查更新",

    "Software Version" => "软件版本",

    "About System" => "关于系统",

    "Upload From Local Directory" => "从本地目录上载",

    "Update System" => "更新系统",

    "min_8" => "最小 8 个字符",

    "re_type" => "重新输入",

    "update_system" => "更新系统",

    "view_settings" => "查看设置",

    "functional_settings" => "功能设置",

    "color" => "颜色",

    "update" => "更新",

    "settings" => "设置",

    "agents" => "代理程序",

    "intro_text" => "介绍文本",

    "single_agent" => "单个代理程序",

    "multi_agent" => "多个代理程序",

    "availability" => "可用性",

    "only_mobile" => "仅移动",

    "only_desktop" => "仅桌面",

    "both" => "都是",

    "showing_page" => "显示页面",

    "only_homepage" => "仅主页",

    "all_page" => "仅主页",

    "popup_open_initially" => "最初弹出窗口",

    "yes" => "是啊",

    "agent_type" => "代理程序类型",

    "homepage_url" => "主页 URL",

    "no" => "没有",

    "whatsapp_support" => "WhatsApp 支持",

    "primary_number" => "主编号",

    "agent" => "代理人",

    "create_agent" => "创建代理程序",

    "update_agent" => "更新代理程序",

    "number" => "编号",

    "add_agent" => "添加代理程序",

    "name" => "名称",

    "designation" => "指定",

    "avatar" => "阿瓦塔尔",

    "status" => "地位",

    "active" => "活动",

    "inactive" => "处于活动状态",

    "browse_avatar" => "浏览头像",

    "always_available" => "始终可用",

    "analytics" => "分析",

    "rtl_ltl" => "RTL/LTL",

    "code" => "守则",

    "Default password will be" => "缺省密码将为",

    "native_name" => "本机名称",

    "key" => "钥匙",

    "value" => "价值",

    "edit_language_info" => "编辑语言信息",

    "users" => "用户",

    "Whatsapp support icon position" => "Whatsapp 支持图标位置",

    "copy_script" => "复制此脚本并在主体标记结束之前将其粘贴到 Web 站点。",

    "update_user" => "更新用户",

    "email" => "电子邮件",

    "language_list" => "语言列表",

    "new_language" => "新语言",

    "translation" => "翻译",

    "create_user" => "创建用户",

    "System Settings" => "系统设置",

    "assign" => "分配",

    "permission" => "许可权",

    "add_user" => "添加用户",

    "icon_position" => "Whatsapp 图标位置",

    "bottom_left" => "左底",

    "bottom_right" => "右底",

    "margin_from_bottom" => "从底部页边距",

    "margin_from_right" => "从右页边距",

    "margin_from_left" => "从左页边距",

    "role_permission" => "角色许可权",

    "layout_settings" => "布局设置",

    "choose_layout" => "选择布局",

    "show_unavailable_agent_in_popup" => "在弹出框中显示不可用的代理程序",

    "start" => "开始",

    "end" => "结束了",

    "time" => "时间",

    "Apply All Days" => "应用所有天数",

    "Are you sure to delete" => "是否确定要删除",

    "create" => "创建",

    "select" => "选择",

    "id" => "标识",

    "ip" => "IP 地址",

    "browser" => "浏览器",

    "operating_system" => "操作系统",

    "messages" => "消息",

    "with_country_code" => "必须使用国家或地区代码",

    "total_click" => "总单击数",

    "clicks" => "点击数",

    "click_from_mobile" => "从移动中单击",

    "click_from_desktop" => "从桌面单击",

    "action" => "行动",

    "welcome_message" => "欢迎消息",

    "your_scripts" => "您的脚本",

    "Login" => "登录",

    "View Profile" => "查看概要文件",

    "My Profile" => "我的概要文件",

    "Profile Settings" => "概要文件设置",

    "Current" => "电流",

    "Re-Type Password" => "重新输入密码",

    "Type Password" => "输入密码",

    "Remember Me" => "记住我",

    "Login Details" => "登录详细信息",

    "Forget Password ?" => "忘记密码 ?",

    "Need an account?" => "需要帐户吗 ?",

    "Sign Up" => "注册",

    "Sign Up Details" => "注册详细信息",

    "You have already an account?" => "你已经有户口了 ?",

    "Send Reset Link" => "发送重置链接",

    "Reset Password" => "重置密码",

    "Reset" => "重置",

    "Set New Password" => "设置新密码",

    "Set Password" => "设置密码",

    "Start From" => "开始自",

    "Start At" => "开始时间",

    "To" => "至",

    "Free" => "免费",

    "Off" => "关",

    "On" => "在",

    "Social Link" => "社交链接",

    "Active Status" => "活动状态",

    "Language List" => "语言列表",

    "Choose File" => "选择文件",

    "Translation" => "翻译",

    "Currency" => "货币",

    "Add New" => "添加新",

    "ID" => "标识",

    "Title" => "标题",

    "Details" => "细节",

    "Name" => "名称",

    "Action" => "行动",

    "Edit" => "编辑",

    "Delete" => "删除",

    "Select" => "选择",

    "Save" => "保存",

    "Update" => "更新",

    "Live" => "活",

    "Sandbox" => "沙箱",

    "Something Went Wrong" => "出什么事了",

    "Description" => "描述",

    "Model" => "模型",

    "Attempted At" => "尝试时间",

    "User" => "用户",

    "Activity Logs" => "活动日志",

    "Type" => "类型",

    "Delete Confirmation" => "删除确认",

    "Human Resource" => "人力资源",

    "Staff" => "工作人员",

    "Staff List" => "工作人员名单",

    "Username" => "用户名",

    "Email" => "电子邮件",

    "Phone" => "电话",

    "Registered Date" => "注册日期",

    "Status" => "地位",

    "URL" => "URL",

    "Register" => "注册纪录册",

    "Remove" => "除去",

    "Staff Id" => "工作人员标识",

    "Password" => "密码",

    "Confirm Password" => "确认密码",

    "Re-Password" => "重新密码",

    "Browse" => "浏览",

    "Avatar" => "阿瓦塔尔",

    "Edit Staff Info" => "编辑人员信息",

    "Staff info has been updated Successfully" => "已成功更新工作人员信息",

    "Staff has been added Successfully" => "已成功添加人员",

    "View" => "维尤",

    "Staff Info" => "工作人员信息",

    "Close" => "关闭",

    "Staff ID" => "工作人员标识",

    "Password did not match with your account password." => "密码与您的帐户密码不匹配。",

    "Put Your password" => "输入密码",

    "Staff has been deleted Successfully" => "已成功删除工作人员",

    "Language" => "语文",

    "Variant" => "变式",

    "Add Variant" => "添加变体",

    "Publish" => "发布",

    "Published" => "发表",

    "Variation Values" => "变体值",

    "Add Value" => "添加值",

    "Edit Variant" => "编辑变体",

    "Unit Type" => "单元类型",

    "Add Unit Type" => "添加单元类型",

    "Edit Unit Type" => "编辑单元类型",

    "Brand" => "布兰德",

    "Add Brand" => "添加品牌",

    "Edit Brand" => "编辑品牌",

    "Add Model" => "添加模型",

    "Edit Model" => "编辑模型",

    "Category" => "类别",

    "Add Category" => "添加类别",

    "Code" => "守则",

    "Add as Sub Category" => "添加为子类别",

    "Select parent Category" => "选择父类别",

    "Edit Category" => "编辑类别",

    "Add New Product" => "添加新产品",

    "Product Name" => "产品名称",

    "Product SKU" => "产品 SKU",

    "Barcode Type" => "条形码类型",

    "Unit" => "单位",

    "Sub Category" => "子类别",

    "Add File" => "添加文件",

    "Manage Stock" => "管理库存",

    "Alert Quantity" => "警报数量",

    "Variation" => "更改",

    "Add Variation" => "添加变体",

    "Add Product" => "添加产品",

    "Edit Product" => "编辑产品",

    "Employee Id" => "员工标识",

    "Address" => "地址",

    "New Price Group" => "新价格组",

    "Export" => "出口",

    "SL" => "SL",

    "Cancel" => "取消",

    "About" => "关于",

    "letter" => "信",

    "date" => "日期",

    "Date" => "日期",

    "Image" => "图像",

    "File Not Found" => "找不到文件",

    "Download" => "下载",

    "Are you sure to delete ?" => "确定要删除吗 ?",

    "Are you sure to" => "你确定",

    "Are you sure to enable this ?" => "您确定要启用此功能吗 ?",

    "Are You Sure To Change Status ?" => "您确定要更改状态吗 ?",

    "Are You Sure To Remove This?" => "您确定要除去此吗 ?",

    "Role" => "角色",

    "List" => "列表",

    "Add" => "加添",

    "Success" => "成功",

    "Failed" => "失败",

    "Dashboard" => "仪表板",

    "User Logs" => "用户日志",

    "Question & Answer" => "问题与答案",

    "Comments" => "评论",

    "Course" => "当然了",

    "Replies" => "答复",

    "Commented By" => "注释者",

    "Submitted" => "已提交",

    "Enable" => "启用",

    "Disable" => "禁用",

    "Active" => "活动",

    "Deactive" => "已取消活动",

    "Inactive" => "不活动",

    "Email Address" => "电子邮件地址",

    "Instagram URL" => "Instagram URL",

    "Youtube URL" => "Youtube URL",

    "LinkedIn URL" => "LinkedIn URL",

    "Twitter URL" => "Twitter URL",

    "Facebook URL" => "Facebook URL",

    "Date of Birth" => "出生日期",

    "Change Status" => "更改状态",

    "Start Date" => "开始日期",

    "End Date" => "结束日期",

    "Filter History" => "过滤历史记录",

    "Reject" => "拒绝",

    "Reason" => "原因",

    "Payouts" => "支付",

    "Author" => "作者",

    "Available" => "可用",

    "Issue Date" => "发放日期",

    "Duration" => "持续时间",

    "Change" => "更改",

    "Deactivate" => "取消激活",

    "Yes" => "是啊",

    "Files" => "文件",

    "File" => "文件",

    "Send" => "发",

    "Paid" => "已支付",

    "Waiting" => "正在等待",

    "Info" => "信息",

    "Zip Code" => "邮政编码",

    "Country" => "国家或地区",

    "City" => "城",

    "Submit" => "提交",

    "Error" => "错误",

    "Warning" => "警告",

    "Used" => "已使用",

    "Join For Free" => "免费加入",

    "Enter Email" => "输入电子邮件",

    "Enter Password" => "输入密码",

    "Enter Phone Number" => "输入电话号码",

    "Enter Confirm Password" => "输入确认密码",

    "Update Profile" => "更新概要文件",

    "Review" => "审查",

    "Log in with Facebook" => "使用 Facebook 登录",

    "Log in with Google" => "使用 Google 登录",

    "Or" => "或",

    "Keep me up to date on WCHAT" => "让我保持最新的 WCHAT",

    "Required" => "必需",

    "New" => "新",

    "Instructor Payout" => "讲师支付",

    "Time Left" => "左时",

    "No Item found" => "找不到项",

    "Total Price" => "总价格",

    "Discount or coupon info" => "折扣或优惠券信息",

    "Checkout" => "检出",

    "Apply" => "申请",

    "Course Schedule" => "课程安排",

    "Add To Cart" => "添加到购物车",

    "Buy Now" => "立即购买",

    "Lessons" => "课程",

    "Bookmarks" => "书签",

    "Deposit" => "存款",

    "Referral" => "转诊",

    "My Cart" => "我的购物车",

    "Purchase History" => "购买历史记录",

    "My Courses" => "我的课程",

    "Live Classes" => "实时类",

    "Already Enrolled" => "已登记",

    "Student Enrolled" => "学生入学",

    "Already Submitted" => "已提交",

    "'s Quiz" => "斯奎兹",

    "Correct Answer" => "正确答案",

    "Wrong Answer" => "错误答案",

    "Skip" => "跳过",

    "Next" => "下一个",

    "Previous" => "上一个",

    "Course File" => "课程文件",

    "Share" => "分享",

    "Course Files" => "课程文件",

    "Course Review" => "课程评审",

    "Start Date & Time" => "开始日期和时间",

    "At" => "在",

    "Show" => "显示",

    "Drip Content" => "滴水内容",

    "Specific Date" => "特定日期",

    "Days After Enrollment" => "注册后的天数",

    "Show All" => "全部显示",

    "Show After Unlock" => "解锁后显示",

    "Aws S3 Setting" => "Aws S3 设置",

    "Access Key Id" => "访问密钥标识",

    "Secret Key" => "密钥",

    "Default Region" => "缺省区域",

    "AWS Bucket" => "AWS 存储区",

    "Module Manager" => "模块管理器",

    "Payment Type" => "付款类型",

    "Blogs" => "博客",

    "Star" => "斯塔克",

    "Total Courses" => "课程总数",

    "Discount" => "折扣",

    "Logo" => "洛戈",

    "My Quizzes" => "我的 Quizzes",

    "Enroll Now" => "立即注册",

    "Added To Cart" => "添加到购物车",

    "Logged In Devices" => "登录设备",

    "Purchase Price" => "采购价格",

    "Pay" => "支付",

    "Welcome" => "欢迎",

    "Send Email" => "发送电子邮件",

    "Minimum 8 characters" => "最少 8 个字符",

    "Status has been changed" => "状态已更改",

    "For the demo version, you cannot change this" => "对于演示版本，您无法更改此",

    "Video File" => "视频文件",

    "Browse Video file" => "浏览视频文件",

    "Select Date" => "选择日期",

    "Days" => "日",

    "Operation successful" => "操作成功",

    "Operation failed" => "操作失败",

    "Quick Search" => "快速搜索",

    "Copy" => "复制",

    "Excel" => "Excel",

    "CSV" => "CSV",

    "PDF" => "PDF",

    "Print" => "印刷",

    "No data available in the table" => "表中没有可用数据",

    "Successfully Assign" => "成功分配",

    "Make Paid" => "已支付",

    "Request For Paid" => "已付款请求",

    "End Date & Time" => "结束日期和时间",

    "Short Description" => "简短描述",

    "No" => "没有",

    "Website" => "网站",

    "Browse file" => "浏览文件",

    "Sanitize No" => "清理",

"Sanitize Yes" => "清理是",

"3DS Yes" => "3DS 是",

"3DS No" => "3DS 否",

"Module Verification" => "模块验证",

"Envato Email Address" => "Envato 电子邮件地址",

"Envato Purchase Code" => "Envato 采购代码",

"Verifying" => "验证",

"None" => "没有",

"Subscription Api Key" => "预订 API 密钥",

"Subscription Method" => "预订方法",

"Watch Now" => "立即观看",

"Continue Watch" => "继续观察",

"Time" => "时间",

"Start" => "开始",

"End" => "结束了",

"TimeZone" => "时区",

"Backup" => "备份",

"Upload SQL File" => "上载 SQL 文件",

"Database Backup List" => "数据库备份列表",

"Generate New Backup" => "生成新备份",

"File Name" => "文件名",

"Make Default" => "使缺省值",

"Theme" => "主题",

"Reset To Default" => "重置为缺省值",

"Mode" => "模式",

"Sub Title" => "子标题",

];
