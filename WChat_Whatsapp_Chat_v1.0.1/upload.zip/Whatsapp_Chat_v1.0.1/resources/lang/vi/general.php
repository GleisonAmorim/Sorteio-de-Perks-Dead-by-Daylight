<?php
return [
    "rtl_ltl" => "RLL/LTL",

    "code" => "Mã",

    "search" => "Tìm kiếm",

    "Timetable" => "Thời gian biểu",

    "System Activated Date" => "Ngày kích hoạt hệ thống",

    "Install Domain" => "Cài đặt miền",

    "Purchase code" => "Mã mua",

    "Curl Enable" => "Kích hoạt curl",

    "PHP Version" => "Phiên bản PHP",

    "Check update" => "Cập nhật lại",

    "Software Version" => "Phiên Bản Phần",

    "About System" => "Hệ thống",

    "Upload From Local Directory" => "Tải lên thư mục nội bộ",

    "Update System" => "Cập nhật hệ",

    "Default password will be" => "Mật khẩu mặc định sẽ là",

    "native_name" => "Tên bản địa",

    "min_8" => "Ký tự tối thiểu 8",

    "re_type" => "Kiểu lại",

    "update_system" => "Cập nhật hệ",

    "key" => "Khóa",

    "value" => "Giá trị",

    "edit_language_info" => "Sửa thông tin ngôn ngữ",

    "users" => "Người dùng",

    "Whatsapp support icon position" => "Vị trí biểu tượng hỗ trợ whatsapp",

    "copy_script" => "Sao chép tập lệnh này và dán nó vào trang web của bạn trước khi kết thúc thẻ cơ thể.",

    "update_user" => "Cập nhật người",

    "email" => "Email",

    "language_list" => "Danh sách &amp;",

    "new_language" => "Ngôn ngữ mới",

    "translation" => "Bản dịch",

    "create_user" => "Tạo người dùng",

    "System Settings" => "Thiết &amp; lập",

    "assign" => "Gán",

    "permission" => "Quyền hạn",

    "add_user" => "Thêm người dùng",

    "icon_position" => "Vị trí biểu tượng whatsapp",

    "bottom_left" => "Trái dưới",

    "bottom_right" => "Phải dưới",

    "margin_from_bottom" => "Lề từ đáy",

    "margin_from_right" => "Lề Từ Phải",

    "margin_from_left" => "Biên từ trái",

    "role_permission" => "Quyền vai trò",

    "layout_settings" => "Thiết lập bô",

    "choose_layout" => "Chọn bố trí",

    "show_unavailable_agent_in_popup" => "Hiện không có sẵn đại lý trong popup",

    "start" => "Bắt đầu",

    "end" => "Kết thúc",

    "time" => "Thời gian",

    "Apply All Days" => "Áp dụng tất cả ngày",

    "Are you sure to delete" => "Bạn có chắc xóa",

    "create" => "Tạo",

    "select" => "Chọn",

    "id" => "ID",

    "ip" => "IP",

    "browser" => "Trình duyệt",

    "operating_system" => "Hệ điều hành",

    "messages" => "Thông báo",

    "with_country_code" => "Với Mã Quốc gia là phải có",

    "total_click" => "Tổng sô ́ nhấp",

    "clicks" => "Click",

    "click_from_mobile" => "Nhấp Từ Di động",

    "click_from_desktop" => "Nhấp Từ Máy Khách",

    "action" => "Thao tác",

    "welcome_message" => "Thông điệp chào",

    "your_scripts" => "Tập lệnh của bạn",

    "Login" => "Đăng nhập",

    "View Profile" => "Xem hồ sơ",

    "My Profile" => "Hồ sơ",

    "Profile Settings" => "Thiết lập hồ",

    "Current" => "Hiện tại",

    "Re-Type Password" => "Mật khẩu lại",

    "Type Password" => "Mật khẩu kiểu",

    "Remember Me" => "Hãy Nhớ Tôi",

    "Login Details" => "Chi tiết đăng",

    "Forget Password ?" => "Quên Mật Khẩu?",

    "Need an account?" => "Có cần tài khoản không?",

    "Sign Up" => "Đăng ký",

    "Sign Up Details" => "Dấu hiệu chi tiết",

    "You have already an account?" => "Anh đã có tài khoản rồi à?",

    "Send Reset Link" => "Gửi lại liên kết lại",

    "Reset Password" => "Thiết lập lại",

    "Reset" => "Đặt lại",

    "Set New Password" => "Đặt mật khẩu mới",

    "Set Password" => "Ðặt mật khẩu",

    "Start From" => "Bắt đầu từ",

    "Start At" => "Bắt đầu tại",

    "To" => "Đến",

    "Free" => "Tự do",

    "Off" => "Tắt",

    "On" => "Vào",

    "Social Link" => "Liên kết mạng",

    "Active Status" => "Trạng thái năng",

    "Language List" => "Danh sách &amp;",

    "Choose File" => "Chọn tập tin",

    "Translation" => "Bản dịch",

    "Currency" => "Tiền tệ",

    "Add New" => "Thêm mới",

    "ID" => "ID",

    "Title" => "Tiêu đề",

    "Details" => "Chi tiết",

    "Name" => "Tên",

    "Action" => "Thao tác",

    "Edit" => "Chỉnh sửa",

    "Delete" => "&amp; Xoá",

    "Select" => "Chọn",

    "Save" => "Lưu",

    "Update" => "Cập nhật",

    "Live" => "Sống",

    "Sandbox" => "Hộp cát",

    "Something Went Wrong" => "Có Gì Sai Rồi.",

    "Description" => "Mô tả",

    "Model" => "Mô hình",

    "Attempted At" => "Ðã thử Ở",

    "User" => "Người dùng",

    "Activity Logs" => "Nhật ký hoạt động",

    "Type" => "Kiểu",

    "Delete Confirmation" => "Xoá xác nhận",

    "Human Resource" => "Nguồn nhân lực",

    "Staff" => "Nhân viên",

    "Staff List" => "Danh sách nhóm",

    "Username" => "Tên người dùng",

    "Email" => "Email",

    "Phone" => "Điện thoại",

    "Registered Date" => "Ngày đăng ký",

    "Status" => "Trạng thái",

    "URL" => "URL",

    "Register" => "Ðăng ký",

    "Remove" => "Gỡ bỏ",

    "Staff Id" => "Id nhân viên",

    "Password" => "Mật khẩu",

    "Confirm Password" => "Xác nhận mật",

    "Re-Password" => "Lại mật khẩu",

    "Browse" => "Duyệt",

    "Avatar" => "Avatar!",

    "Edit Staff Info" => "Sửa thông tin nhân viên",

    "Staff info has been updated Successfully" => "Thông tin nhân viên đã được cập nhật thành công",

    "Staff has been added Successfully" => "Nhân viên đã được bổ sung thành công",

    "View" => "Xem thử",

    "Staff Info" => "Thông tin ban",

    "Close" => "Đóng",

    "Staff ID" => "ID nhân viên",

    "Password did not match with your account password." => "Mật khẩu không khớp với mật khẩu tài khoản của bạn.",

    "Put Your password" => "Đặt mật khẩu của bạn",

    "Staff has been deleted Successfully" => "Nhân viên đã bị xóa thành công",

    "Language" => "Ngôn ngữ",

    "Variant" => "Biến thể",

    "Add Variant" => "Thêm biến thể",

    "Publish" => "Phát hành",

    "Published" => "Xuất bản",

    "Variation Values" => "Giá Trị Biến",

    "Add Value" => "Thêm giá trị",

    "Edit Variant" => "Sửa đổi biến thể",

    "Unit Type" => "Kiểu đơn vị",

    "Add Unit Type" => "Thêm đơn vị",

    "Edit Unit Type" => "Chỉnh sửa kiểu đơn vị",

    "Brand" => "Thương hiệu",

    "Add Brand" => "Thêm Nhãn",

    "Edit Brand" => "Sửa thương hiệu",

    "Add Model" => "Thêm mô hình",

    "Edit Model" => "Sửa kiểu mẫu",

    "Category" => "Danh mục",

    "Add Category" => "Thêm danh mục",

    "Code" => "Mã",

    "Add as Sub Category" => "Thêm vào danh mục con",

    "Select parent Category" => "Chọn danh mục mẹ",

    "Edit Category" => "Sửa danh mục",

    "Add New Product" => "Thêm sản phẩm mới",

    "Product Name" => "Tên sản phẩm",

    "Product SKU" => "Sản phẩm SKU",

    "Barcode Type" => "Kiểu mã vạch",

    "Unit" => "Đơn vị",

    "Sub Category" => "Phân loại phụ",

    "Add File" => "Thêm tập tin",

    "Manage Stock" => "Quản lý Stock",

    "Alert Quantity" => "Số lượng báo động",

    "Variation" => "Biến thể",

    "Add Variation" => "Thêm biến thể",

    "Add Product" => "Thêm sản phẩm",

    "Edit Product" => "Sửa sản phẩm",

    "Employee Id" => "Id nhân viên",

    "Address" => "Địa chỉ",

    "New Price Group" => "Nhóm giá mới",

    "Export" => "Xuất",

    "SL" => "SL",

    "Cancel" => "Hủy",

    "About" => "Về",

    "letter" => "thư ́",

    "date" => "ngày",

    "Date" => "Ngày",

    "Image" => "Ảnh",

    "File Not Found" => "Không tìm thấy tập tin",

    "Download" => "Tải xuống",

    "Are you sure to delete ?" => "Bạn có chắc chắn xóa không?",

    "Are you sure to" => "Anh có chắc không?",

    "Are you sure to enable this ?" => "Anh có chắc là cho phép chuyện này không?",

    "Are You Sure To Change Status ?" => "Bạn Có Chắc Chắn Thay Đổi Trạng Thái Không?",

    "Are You Sure To Remove This?" => "Anh Có Chắc Muốn Bỏ Qua Cái Này Không?",

    "Role" => "Vai trò",

    "List" => "Danh sách",

    "Add" => "Thêm",

    "Success" => "Thành công",

    "Failed" => "Thất bại",

    "Dashboard" => "Bảng điều khiển",

    "User Logs" => "Nhật ký người dùng",

    "Question & Answer" => "Câu hỏi & Trả lời",

    "Comments" => "Chú thích",

    "Course" => "Tất nhiên",

    "Replies" => "Replies",

    "Commented By" => "Nhận xét bởi",

    "Submitted" => "Ðã gửi",

    "Enable" => "Kích hoạt",

    "Disable" => "Tắt",

    "Active" => "Hoạt động",

    "Deactive" => "Không hoạt động",

    "Inactive" => "Không chọn",

    "Email Address" => "Ðịa chỉ email",

    "Instagram URL" => "URL Instagram",

    "Youtube URL" => "URL của bạn",

    "LinkedIn URL" => "URL LinkedIn",

    "Twitter URL" => "URL của Twitter",

    "Facebook URL" => "URL của Facebook",

    "Date of Birth" => "Ngày sinh",

    "Change Status" => "Độ thay đổi",

    "Start Date" => "Ngày bắt đầu",

    "End Date" => "Ngày kết thúc",

    "Filter History" => "Bộ lọc lịch",

    "Reject" => "Từ chối",

    "Reason" => "Lý do",

    "Payouts" => "Thanh toán",

    "Author" => "Tác giả",

    "Available" => "Có sẵn",

    "Issue Date" => "Ngày phát hành",

    "Duration" => "Thời gian",

    "Change" => "Thay đổi",

    "Deactivate" => "Hủy kích hoạt",

    "Yes" => "Vâng.",

    "Files" => "Tập tin",

    "File" => "Tập tin",

    "Send" => "Gửi",

    "Paid" => "Thanh toán",

    "Waiting" => "Đang đợi",

    "Info" => "Thông tin",

    "Zip Code" => "Mã zip",

    "Country" => "Quốc gia",

    "City" => "Thành phố",

    "Submit" => "Gửi",

    "Error" => "Lỗi",

    "Warning" => "Cảnh báo",

    "Used" => "Đã dùng",

    "Join For Free" => "Tham Gia Miễn Phí",

    "Enter Email" => "Nhập email",

    "Enter Password" => "Nhập mật khẩu",

    "Enter Phone Number" => "Nhập sô ́ điện thoại",

    "Enter Confirm Password" => "Nhập mật khẩu xác nhận",

    "Update Profile" => "Cập nhật hồ",

    "Review" => "Xem lại",

    "Log in with Facebook" => "Đăng nhập với Facebook",

    "Log in with Google" => "Đăng nhập với Google",

    "Or" => "Hoặc là",

    "Keep me up to date on WCHAT" => "Cho tôi hẹn hò với WCHAT",

    "Required" => "Yêu cầu",

    "New" => "Mới",

    "Instructor Payout" => "Thanh toán viên thanh toán",

    "Time Left" => "Thời gian trái",

    "No Item found" => "Không tìm thấy mục",

    "Total Price" => "Tổng giá",

    "Discount or coupon info" => "Thông tin giảm giá hoặc phiếu mua hàng",

    "Checkout" => "Kiểm xuất",

    "Apply" => "Áp dụng",

    "Course Schedule" => "Lịch trình",

    "Add To Cart" => "Thêm vào giỏ hàng",

    "Buy Now" => "Mua ngay",

    "Lessons" => "Bài học",

    "Bookmarks" => "Đánh dấu",

    "Deposit" => "Đặt cọc",

    "Referral" => "Giới thiệu",

    "My Cart" => "Xe của tôi.",

    "Purchase History" => "Lịch sử mua",

    "My Courses" => "Khóa học của tôi",

    "Live Classes" => "Lớp trực tiếp",

    "Already Enrolled" => "Đã ghi danh",

    "Student Enrolled" => "Học sinh ghi danh",

    "Already Submitted" => "Ðã gửi đã được gửi",

    "'s Quiz" => "' s Quiz",

    "Correct Answer" => "Trả lời đúng",

    "Wrong Answer" => "Trả lời sai",

    "Skip" => "Bỏ qua",

    "Next" => "Tiếp theo",

    "Previous" => "Trước",

    "Course File" => "Khóa học",

    "Share" => "Chia sẻ",

    "Course Files" => "Khoá tập tin",

    "Course Review" => "Khóa học",

    "Start Date & Time" => "Ngày & giơ ̀ bắt đầu",

    "At" => "Vào",

    "Show" => "Hiển thị",

    "Drip Content" => "Nội dung Drip",

    "Specific Date" => "Ngày cụ thể",

    "Days After Enrollment" => "Ngày Sau Khi Tuyển Sinh",

    "Show All" => "Hiện tất cả",

    "Show After Unlock" => "Hiện Sau Mở Khóa",

    "Aws S3 Setting" => "Thiết lập Aws S3",

    "Access Key Id" => "ID khóa truy cập",

    "Secret Key" => "Khóa bí mật",

    "Default Region" => "Vùng mặc định",

    "AWS Bucket" => "Vùng chứa AWS",

    "Module Manager" => "Bộ quản lý",

    "Payment Type" => "Kiểu thanh toán",

    "Blogs" => "Blog",

    "Star" => "Ngôi sao",

    "Total Courses" => "Tổng sô ́ khóa",

    "Discount" => "Giảm giá",

    "Logo" => "Logo",

    "My Quizzes" => "Quizzes của tôi",

    "Enroll Now" => "Chạy ngay bây giờ",

    "Added To Cart" => "Thêm vào giỏ hàng",

    "Logged In Devices" => "Ðược đăng nhập vào thiết",

    "Purchase Price" => "Giá mua",

    "Pay" => "Trả tiền",

    "Welcome" => "Chào mừng",

    "Send Email" => "Gửi email",

    "Minimum 8 characters" => "Tối thiểu 8 ký tự",

    "Status has been changed" => "Tình trạng đã được thay đổi",

    "For the demo version, you cannot change this" => "Với phiên bản dùng thử, bạn không thể thay đổi được",

    "Video File" => "Tập tin video",

    "Browse Video file" => "Duyệt tập tin Video",

    "Select Date" => "Chọn Ngày",

    "Days" => "Ngày",

    "Operation successful" => "Thao tác thành",

    "Operation failed" => "Thao tác bị",

    "Quick Search" => "Tìm kiếm nhanh",

    "Copy" => "Sao chép",

    "Excel" => "Excel",

    "CSV" => "CSV",

    "PDF" => "PDF",

    "Print" => "Bản in",

    "No data available in the table" => "Không có sẵn dư ̃ liệu trong bảng",

    "Successfully Assign" => "Gán thành công",

    "Make Paid" => "Tạo thanh toán",

    "Request For Paid" => "Yêu cầu thanh toán",

    "End Date & Time" => "Ngày & giơ ̀ kết thúc",

    "Short Description" => "Mô tả ngắn",

    "No" => "Không.",

    "Website" => "Trang web",

    "Browse file" => "Duyệt tập tin",

    "Sanitize No" => "Không có tác dụng",

    "Sanitize Yes" => "Giảm giá trị",

    "3DS Yes" => "3DS Yes",

    "3DS No" => "3DS No",

    "Module Verification" => "Xác minh mô-đun",

    "Envato Email Address" => "Địa chỉ email envato",

    "Envato Purchase Code" => "Mã mua enenvato",

    "Verifying" => "Xác minh",

    "None" => "Không có",

    "Subscription Api Key" => "Khóa đăng ký api",

    "Subscription Method" => "Phương thức Đăng",

    "Watch Now" => "Coi chừng!",

    "Continue Watch" => "Tiếp tục xem",

    "Time" => "Thời gian",

    "Start" => "Bắt đầu",

    "End" => "Kết thúc",

    "TimeZone" => "Múi giơ ̀",

    "Backup" => "Sao lưu",

    "Upload SQL File" => "Tải tập tin SQL lên",

    "Database Backup List" => "Danh Sách Sao Lưu Cơ",

    "Generate New Backup" => "Tạo ra sao lưu mới",

    "File Name" => "Tên tập tin",

    "Make Default" => "Tạo mặc định",

    "Theme" => "Sắc thái",

    "Reset To Default" => "Ðặt lại thành mặc định",

    "Mode" => "Chế độ",

    "Sub Title" => "Tiêu đề phụ",

    "view_settings" => "Thiết lập xem",

    "functional_settings" => "Thiết lập hàm",

    "color" => "Màu",

    "update" => "Cập nhật",

    "settings" => "Thiết lập",

    "agents" => "Tác tử",

    "intro_text" => "Đoạn giới thiệu",

    "single_agent" => "Đặc vụ đơn",

    "multi_agent" => "Đa tác vụ",

    "availability" => "Có sẵn",

    "only_mobile" => "Chỉ di động",

    "only_desktop" => "Chỉ màn hình",

    "both" => "Cả hai",

    "showing_page" => "Hiện trang",

    "only_homepage" => "Chỉ trang chủ",

    "all_page" => "Tất cả trang",

    "popup_open_initially" => "Mở cửa Ban đầu",

    "yes" => "Vâng.",

    "agent_type" => "Kiểu tác tử",

    "homepage_url" => "Url trang chủ",

    "no" => "Không.",

    "whatsapp_support" => "Hỗ trợ whatsApp",

    "primary_number" => "Số chính",

    "agent" => "Đặc vụ",

    "create_agent" => "Tạo tác tử",

    "update_agent" => "Cập nhật nhân",

    "number" => "Số",

    "add_agent" => "Thêm đặc vụ",

    "name" => "Tên",

    "designation" => "Tên gọi",

    "avatar" => "Avatar!",

    "status" => "Trạng thái",

    "active" => "Hoạt động",

    "inactive" => "Đang hoạt động",

    "browse_avatar" => "Duyệt Avatar",

    "always_available" => "Luôn sẵn sàng",

    "analytics" => "Phân tích",

];
