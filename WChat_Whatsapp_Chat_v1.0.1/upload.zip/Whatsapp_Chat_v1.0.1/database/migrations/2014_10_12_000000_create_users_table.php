<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->nullable();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('role_id')->default(1);
            $table->string('avatar')->default('public/whatsapp-support/demo-avatar.jpg');
            $table->string('ws_token')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });

        \App\Models\User::create([
           'name' => 'Admin',
           'email' => 'admin1@gmail.com',
            'password' => bcrypt(12345678)
        ]);

        \App\Models\User::create([
           'name' => 'User',
           'email' => 'user@gmail.com',
           'role_id' => 2,
            'avatar' => 'public/whatsapp-support/demo-avatar.jpg',
            'password' => bcrypt(12345678)
        ]);

        $agent = \App\Models\User::create([
           'name' => 'Agent',
           'email' => 'agent@gmail.com',
           'role_id' => 3,
            'avatar' => 'public/whatsapp-support/demo-avatar.jpg',
            'password' => bcrypt(12345678)
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
