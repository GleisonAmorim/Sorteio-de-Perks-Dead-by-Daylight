
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
                               `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                               `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
                               `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
                               `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
                               `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
                               `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
                               `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
                               PRIMARY KEY (`id`),
                               UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `general_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `general_settings` (
                                    `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                                    `site_title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'WCHAT',
                                    `company_info` longtext COLLATE utf8mb4_unicode_ci,
                                    `zip_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `vat_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `currency_id` int(11) DEFAULT '2',
                                    `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `logo2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `favicon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `system_version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '1.0',
                                    `active_status` int(11) DEFAULT '1',
                                    `website_url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `ttl_rtl` int(11) NOT NULL DEFAULT '2',
                                    `phone_number_privacy` int(11) NOT NULL DEFAULT '1',
                                    `language_id` int(10) unsigned DEFAULT '19',
                                    `date_format_id` int(10) unsigned DEFAULT '1',
                                    `software_version` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `mail_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `mail_header` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `mail_footer` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `mail_protocol` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `time_zone_id` int(11) DEFAULT '83',
                                    `country_id` int(11) DEFAULT '19',
                                    `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Dhaka',
                                    `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'Dhaka',
                                    `fb` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://facebook.com/',
                                    `twitter` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://twitter.com/',
                                    `youtube` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://youtube.com/',
                                    `linkedin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'https://www.linkedin.com/',
                                    `copyright_text` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
                                    `commission` double(8,2) NOT NULL DEFAULT '40.00',
  `recapthca` tinyint(1) NOT NULL DEFAULT '0',
  `recaptcha_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recaptcha_secret` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_id` tinyint(4) NOT NULL DEFAULT '3' COMMENT '1 => Default Template, 2 => Dark Template & 3 => Dark Two Template',
  `instructor_reg` tinyint(1) NOT NULL DEFAULT '1',
  `email_template` text COLLATE utf8mb4_unicode_ci,
  `meta_keywords` text COLLATE utf8mb4_unicode_ci,
  `meta_description` text COLLATE utf8mb4_unicode_ci,
  `currency_conversion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Fixer',
  `device_limit` int(11) NOT NULL DEFAULT '0',
  `email_notification` tinyint(1) NOT NULL DEFAULT '0',
  `show_drip` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0 = all; 1=only unlocked',
  `AmazonS3` tinyint(1) NOT NULL DEFAULT '1',
  `BBB` tinyint(1) NOT NULL DEFAULT '0',
  `Sslcommerz` tinyint(1) NOT NULL DEFAULT '0',
  `Zoom` tinyint(1) NOT NULL DEFAULT '1',
  `lat` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '23.806931' COMMENT 'Latitude',
  `lng` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '90.368709' COMMENT 'Longitude',
  `zoom_level` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '11' COMMENT 'Zoom Level',
  `gmap_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT 'AIzaSyA7nx22ZmINYk9TGiXDEXGVxghC43Ox6qA' COMMENT 'Google Api Key',
  `fixer_key` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '0bd244e811264242d56e1759c93a3f1a' COMMENT 'Fixer Api Key',
  `footer_about_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'About',
  `footer_about_description` text COLLATE utf8mb4_unicode_ci,
  `footer_copy_right` text COLLATE utf8mb4_unicode_ci,
  `footer_section_one_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Support Zone',
  `footer_section_two_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Company Info',
  `footer_section_three_title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Explore Services',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `system_domain` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `system_activated_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_updated_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `general_settings` WRITE;
/*!40000 ALTER TABLE `general_settings` DISABLE KEYS */;
INSERT INTO `general_settings` VALUES (1,'WCHAT',NULL,'1205',NULL,'89/2 Panthapath, Dhaka 1215, Bangladesh','+8801841412141','info@spondonit.com',2,'public/backend/frontend/img/logo.png','public/uploads/settings/logo.png','public/favicon.png','1.0.0',1,NULL,2,1,19,1,NULL,NULL,NULL,NULL,NULL,83,19,'Dhaka','Dhaka','https://facebook.com/','https://twitter.com/','https://youtube.com/','https://www.linkedin.com/',NULL,40.00,0,NULL,NULL,3,1,NULL,NULL,NULL,'Fixer',0,0,0,1,0,0,1,'23.806931','90.368709','11','AIzaSyA7nx22ZmINYk9TGiXDEXGVxghC43Ox6qA','0bd244e811264242d56e1759c93a3f1a','About',NULL,NULL,'Support Zone','Company Info','Explore Services','2021-07-06 09:28:06','2021-07-06 09:28:06',NULL,NULL,NULL);
/*!40000 ALTER TABLE `general_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `languages` (
                             `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
                             `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
                             `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
                             `native` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
                             `rtl` tinyint(4) NOT NULL DEFAULT '0',
                             `status` tinyint(4) NOT NULL DEFAULT '1',
                             `json_exist` tinyint(4) NOT NULL DEFAULT '0',
                             `created_at` timestamp NULL DEFAULT NULL,
                             `updated_at` timestamp NULL DEFAULT NULL,
                             PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'af','Afrikaans','Afrikaans',0,0,0,NULL,NULL),(2,'am','Amharic','አማርኛ',0,0,0,NULL,NULL),(3,'ar','Arabic','العربية',1,1,0,NULL,NULL),(4,'ay','Aymara','Aymar',0,0,0,NULL,NULL),(5,'az','Azerbaijani','Azərbaycanca / آذربايجان',0,0,0,NULL,NULL),(6,'be','Belarusian','Беларуская',0,0,0,NULL,NULL),(7,'bg','Bulgarian','Български',0,0,0,NULL,NULL),(8,'bi','Bislama','Bislama',0,0,0,NULL,NULL),(9,'bn','Bengali','বাংলা',0,1,0,NULL,NULL),(10,'bs','Bosnian','Bosanski',0,0,0,NULL,NULL),(11,'ca','Catalan','Català',0,0,0,NULL,NULL),(12,'ch','Chamorro','Chamoru',0,0,0,NULL,NULL),(13,'cs','Czech','Česky',0,0,0,NULL,NULL),(14,'da','Danish','Dansk',0,0,0,NULL,NULL),(15,'de','German','Deutsch',0,0,0,NULL,NULL),(16,'dv','Divehi','ދިވެހިބަސް',1,0,0,NULL,NULL),(17,'dz','Dzongkha','ཇོང་ཁ',0,0,0,NULL,NULL),(18,'el','Greek','Ελληνικά',0,0,0,NULL,NULL),(19,'en','English','English',0,1,0,NULL,NULL),(20,'es','Spanish','Español',0,1,0,NULL,NULL),(21,'et','Estonian','Eesti',0,0,0,NULL,NULL),(22,'eu','Basque','Euskara',0,0,0,NULL,NULL),(23,'fa','Persian','فارسی',1,0,0,NULL,NULL),(24,'ff','Peul','Fulfulde',0,0,0,NULL,NULL),(25,'fi','Finnish','Suomi',0,0,0,NULL,NULL),(26,'fj','Fijian','Na Vosa Vakaviti',0,0,0,NULL,NULL),(27,'fo','Faroese','Føroyskt',0,0,0,NULL,NULL),(28,'fr','French','Français',0,1,0,NULL,NULL),(29,'ga','Irish','Gaeilge',0,0,0,NULL,NULL),(30,'gl','Galician','Galego',0,0,0,NULL,NULL),(31,'gn','Guarani','Avañe\'ẽ',0,0,0,NULL,NULL),(32,'gv','Manx','Gaelg',0,0,0,NULL,NULL),(33,'he','Hebrew','עברית',1,0,0,NULL,NULL),(34,'hi','Hindi','हिन्दी',0,0,0,NULL,NULL),(35,'hr','Croatian','Hrvatski',0,0,0,NULL,NULL),(36,'ht','Haitian','Krèyol ayisyen',0,0,0,NULL,NULL),(37,'hu','Hungarian','Magyar',0,0,0,NULL,NULL),(38,'hy','Armenian','Հայերեն',0,0,0,NULL,NULL),(39,'id','Indonesian','Bahasa Indonesia',0,1,0,NULL,NULL),(40,'is','Icelandic','Íslenska',0,0,0,NULL,NULL),(41,'it','Italian','Italiano',0,0,0,NULL,NULL),(42,'ja','Japanese','日本語',0,0,0,NULL,NULL),(43,'ka','Georgian','ქართული',0,0,0,NULL,NULL),(44,'kg','Kongo','KiKongo',0,0,0,NULL,NULL),(45,'kk','Kazakh','Қазақша',0,0,0,NULL,NULL),(46,'kl','Greenlandic','Kalaallisut',0,0,0,NULL,NULL),(47,'km','Cambodian','ភាសាខ្មែរ',0,0,0,NULL,NULL),(48,'ko','Korean','한국어',0,0,0,NULL,NULL),(49,'ku','Kurdish','Kurdî / كوردی',1,0,0,NULL,NULL),(50,'ky','Kirghiz','Kırgızca / Кыргызча',0,0,0,NULL,NULL),(51,'la','Latin','Latina',0,0,0,NULL,NULL),(52,'lb','Luxembourgish','Lëtzebuergesch',0,0,0,NULL,NULL),(53,'ln','Lingala','Lingála',0,0,0,NULL,NULL),(54,'lo','Laotian','ລາວ / Pha xa lao',0,0,0,NULL,NULL),(55,'lt','Lithuanian','Lietuvių',0,0,0,NULL,NULL),(56,'lu','','',0,0,0,NULL,NULL),(57,'lv','Latvian','Latviešu',0,0,0,NULL,NULL),(58,'mg','Malagasy','Malagasy',0,0,0,NULL,NULL),(59,'mh','Marshallese','Kajin Majel / Ebon',0,0,0,NULL,NULL),(60,'mi','Maori','Māori',0,0,0,NULL,NULL),(61,'mk','Macedonian','Македонски',0,0,0,NULL,NULL),(62,'mn','Mongolian','Монгол',0,0,0,NULL,NULL),(63,'ms','Malay','Bahasa Melayu',0,0,0,NULL,NULL),(64,'mt','Maltese','bil-Malti',0,0,0,NULL,NULL),(65,'my','Burmese','မြန်မာစာ',0,0,0,NULL,NULL),(66,'na','Nauruan','Dorerin Naoero',0,0,0,NULL,NULL),(67,'nb','','',0,0,0,NULL,NULL),(68,'nd','North Ndebele','Sindebele',0,0,0,NULL,NULL),(69,'ne','Nepali','नेपाली',0,0,0,NULL,NULL),(70,'nl','Dutch','Nederlands',0,0,0,NULL,NULL),(71,'nn','Norwegian Nynorsk','Norsk (nynorsk)',0,0,0,NULL,NULL),(72,'no','Norwegian','Norsk (bokmål / riksmål)',0,0,0,NULL,NULL),(73,'nr','South Ndebele','isiNdebele',0,0,0,NULL,NULL),(74,'ny','Chichewa','Chi-Chewa',0,0,0,NULL,NULL),(75,'oc','Occitan','Occitan',0,0,0,NULL,NULL),(76,'pa','Panjabi / Punjabi','ਪੰਜਾਬੀ / पंजाबी / پنجابي',0,0,0,NULL,NULL),(77,'pl','Polish','Polski',0,0,0,NULL,NULL),(78,'ps','Pashto','پښتو',1,0,0,NULL,NULL),(79,'pt','Portuguese','Português',0,0,0,NULL,NULL),(80,'qu','Quechua','Runa Simi',0,0,0,NULL,NULL),(81,'rn','Kirundi','Kirundi',0,0,0,NULL,NULL),(82,'ro','Romanian','Română',0,0,0,NULL,NULL),(83,'ru','Russian','Русский',0,1,0,NULL,NULL),(84,'rw','Rwandi','Kinyarwandi',0,0,0,NULL,NULL),(85,'sg','Sango','Sängö',0,0,0,NULL,NULL),(86,'si','Sinhalese','සිංහල',0,0,0,NULL,NULL),(87,'sk','Slovak','Slovenčina',0,0,0,NULL,NULL),(88,'sl','Slovenian','Slovenščina',0,0,0,NULL,NULL),(89,'sm','Samoan','Gagana Samoa',0,0,0,NULL,NULL),(90,'sn','Shona','chiShona',0,0,0,NULL,NULL),(91,'so','Somalia','Soomaaliga',0,0,0,NULL,NULL),(92,'sq','Albanian','Shqip',0,0,0,NULL,NULL),(93,'sr','Serbian','Српски',0,0,0,NULL,NULL),(94,'ss','Swati','SiSwati',0,0,0,NULL,NULL),(95,'st','Southern Sotho','Sesotho',0,0,0,NULL,NULL),(96,'sv','Swedish','Svenska',0,0,0,NULL,NULL),(97,'sw','Swahili','Kiswahili',0,0,0,NULL,NULL),(98,'ta','Tamil','தமிழ்',0,0,0,NULL,NULL),(99,'tg','Tajik','Тоҷикӣ',0,0,0,NULL,NULL),(100,'th','Thai','ไทย / Phasa Thai',0,0,0,NULL,NULL),(101,'ti','Tigrinya','ትግርኛ',0,0,0,NULL,NULL),(102,'tk','Turkmen','Туркмен /تركمن ',0,0,0,NULL,NULL),(103,'tn','Tswana','Setswana',0,0,0,NULL,NULL),(104,'to','Tonga','Lea Faka-Tonga',0,0,0,NULL,NULL),(105,'tr','Turkish','Türkçe',0,0,0,NULL,NULL),(106,'ts','Tsonga','Xitsonga',0,0,0,NULL,NULL),(107,'uk','Ukrainian','Українська',0,0,0,NULL,NULL),(108,'ur','Urdu','اردو',1,0,0,NULL,NULL),(109,'uz','Uzbek','Ўзбек',0,0,0,NULL,NULL),(110,'ve','Venda','Tshivenḓa',0,0,0,NULL,NULL),(111,'vi','Vietnamese','Tiếng Việt',0,0,0,NULL,NULL),(112,'xh','Xhosa','isiXhosa',0,0,0,NULL,NULL),(113,'zh','Chinese','中文',0,0,0,NULL,NULL),(114,'zu','Zulu','isiZulu',0,0,0,NULL,NULL);
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2020_07_11_162112_create_language_table',1),(5,'2020_07_13_061051_create_timezone_table',1),(6,'2020_07_20_095501_create_permissions_tables',1),(7,'2020_07_20_095817_create_role_permission_tables',1),(8,'2020_09_02_084215_create_general_settings_table',1),(9,'2020_09_10_075009_create_roles_table',1),(10,'2021_02_23_194810_create_version_histories_table',1),(11,'2021_02_23_200517_general_setting_add_column',1),(12,'2021_05_24_042145_create_whatsapp_support_settings_table',1),(13,'2021_05_25_050337_create_whatsapp_support_agents_table',1),(14,'2021_05_25_050338_create_whatsapp_support_agent_times_table',1),(15,'2021_05_25_050339_create_whatsapp_support_messages_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `route` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_by` int(10) unsigned NOT NULL DEFAULT '1',
  `updated_by` int(10) unsigned NOT NULL DEFAULT '1',
  `type` int(11) DEFAULT NULL COMMENT '1 for main menu, 2 for sub menu , 3 action',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,1,NULL,'Whatsapp Settings','whatsapp-support.settings',1,1,1,1,NULL,NULL),(2,1,1,'Agents','whatsapp-support.agents',1,1,1,2,NULL,NULL),(3,1,3,'all agents','whatsapp-support.agents',1,1,1,3,NULL,NULL),(4,1,3,'agent edit','whatsapp-support.agents.show',1,1,1,3,NULL,NULL),(5,1,1,'Analytics','whatsapp-support.analytics',1,1,1,2,NULL,NULL),(6,1,1,'Users','users.index',1,1,1,2,NULL,NULL),(7,1,6,'Create','users.create',1,1,1,3,NULL,NULL),(8,2,NULL,'System Settings','setting.updateSystem',1,1,1,1,NULL,NULL),(9,2,8,'Language','languages.index',1,1,1,2,NULL,NULL),(10,2,8,'General Settings','whatsapp-support.settings',1,1,1,2,NULL,NULL),(11,2,8,'Role Permission','permission.roles.index',1,1,1,2,NULL,NULL),(12,2,11,'Create Role','permission.roles.store',1,1,1,3,NULL,NULL),(13,2,11,'Edit Role','permission.roles.edit',1,1,1,3,NULL,NULL),(14,2,11,'Delete Role','permission.roles.destroy',1,1,1,3,NULL,NULL),(15,2,8,'Update','setting.updateSystem',1,1,1,2,NULL,NULL),(16,2,8,'Timezone','timezone.index',1,1,1,2,NULL,NULL),(17,2,8,'Email Setup','setting.email_setup',1,1,1,2,NULL,NULL);
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_permission` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `permission_id` int(11) DEFAULT NULL,
  `role_id` int(10) unsigned DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_by` int(10) unsigned NOT NULL DEFAULT '1',
  `updated_by` int(10) unsigned NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
INSERT INTO `role_permission` VALUES (1,1,2,1,1,1,'2021-07-06 09:28:06','2021-07-06 09:28:06'),(2,2,2,1,1,1,'2021-07-06 09:28:06','2021-07-06 09:28:06'),(3,2,2,1,1,1,'2021-07-06 09:28:06','2021-07-06 09:28:06'),(4,5,2,1,1,1,'2021-07-06 09:28:06','2021-07-06 09:28:06'),(5,4,3,1,1,1,'2021-07-06 09:28:06','2021-07-06 09:28:06');
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Super admin','System',NULL,'2021-07-05 21:28:06',NULL),(2,'User','System',NULL,'2021-07-05 21:28:06',NULL),(3,'Agent','System',NULL,'2021-07-05 21:28:06',NULL);
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `time_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `time_zones` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_zone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `time_zones` WRITE;
/*!40000 ALTER TABLE `time_zones` DISABLE KEYS */;
INSERT INTO `time_zones` VALUES (1,'Pacific/Midway','(GMT-11:00) Midway Island','2021-07-06 09:28:06','2021-07-06 09:28:06'),(2,'US/Samoa','(GMT-11:00) Samoa','2021-07-06 09:28:06','2021-07-06 09:28:06'),(3,'US/Hawaii','(GMT-10:00) Hawaii','2021-07-06 09:28:06','2021-07-06 09:28:06'),(4,'US/Alaska','(GMT-09:00) Alaska','2021-07-06 09:28:06','2021-07-06 09:28:06'),(5,'US/Pacific','(GMT-08:00) Pacific Time (US &amp; Canada)','2021-07-06 09:28:06','2021-07-06 09:28:06'),(6,'America/Tijuana','(GMT-08:00) Tijuana','2021-07-06 09:28:06','2021-07-06 09:28:06'),(7,'US/Arizona','(GMT-07:00) Arizona','2021-07-06 09:28:06','2021-07-06 09:28:06'),(8,'US/Mountain','(GMT-07:00) Mountain Time (US &amp; Canada)','2021-07-06 09:28:06','2021-07-06 09:28:06'),(9,'America/Chihuahua','(GMT-07:00) Chihuahua','2021-07-06 09:28:06','2021-07-06 09:28:06'),(10,'America/Mazatlan','(GMT-07:00) Mazatlan','2021-07-06 09:28:06','2021-07-06 09:28:06'),(11,'America/Mexico_City','(GMT-06:00) Mexico City','2021-07-06 09:28:06','2021-07-06 09:28:06'),(12,'America/Monterrey','(GMT-06:00) Monterrey','2021-07-06 09:28:06','2021-07-06 09:28:06'),(13,'Canada/Saskatchewan','(GMT-06:00) Saskatchewan','2021-07-06 09:28:06','2021-07-06 09:28:06'),(14,'US/Central','(GMT-06:00) Central Time (US &amp; Canada)','2021-07-06 09:28:06','2021-07-06 09:28:06'),(15,'US/Eastern','(GMT-05:00) Eastern Time (US &amp; Canada)','2021-07-06 09:28:06','2021-07-06 09:28:06'),(16,'US/East-Indiana','(GMT-05:00) Indiana (East)','2021-07-06 09:28:06','2021-07-06 09:28:06'),(17,'America/Bogota','(GMT-05:00) Bogota','2021-07-06 09:28:06','2021-07-06 09:28:06'),(18,'America/Lima','(GMT-05:00) Lima','2021-07-06 09:28:06','2021-07-06 09:28:06'),(19,'America/Caracas','(GMT-04:30) Caracas','2021-07-06 09:28:06','2021-07-06 09:28:06'),(20,'Canada/Atlantic','(GMT-04:00) Atlantic Time (Canada)','2021-07-06 09:28:06','2021-07-06 09:28:06'),(21,'America/La_Paz','(GMT-04:00) La Paz','2021-07-06 09:28:06','2021-07-06 09:28:06'),(22,'America/Santiago','(GMT-04:00) Santiago','2021-07-06 09:28:06','2021-07-06 09:28:06'),(23,'Canada/Newfoundland','(GMT-03:30) Newfoundland','2021-07-06 09:28:06','2021-07-06 09:28:06'),(24,'America/Buenos_Aires','(GMT-03:00) Buenos Aires','2021-07-06 09:28:06','2021-07-06 09:28:06'),(25,'America/Godthab','(GMT-03:00) Greenland','2021-07-06 09:28:06','2021-07-06 09:28:06'),(26,'Atlantic/Stanley','(GMT-02:00) Stanley','2021-07-06 09:28:06','2021-07-06 09:28:06'),(27,'Atlantic/Azores','(GMT-01:00) Azores','2021-07-06 09:28:06','2021-07-06 09:28:06'),(28,'Atlantic/Cape_Verde','(GMT-01:00) Cape Verde Is.','2021-07-06 09:28:06','2021-07-06 09:28:06'),(29,'Africa/Casablanca','(GMT) Casablanca','2021-07-06 09:28:06','2021-07-06 09:28:06'),(30,'Europe/Dublin','(GMT) Dublin','2021-07-06 09:28:06','2021-07-06 09:28:06'),(31,'Europe/Lisbon','(GMT) Lisbon','2021-07-06 09:28:06','2021-07-06 09:28:06'),(32,'Europe/London','(GMT) London','2021-07-06 09:28:06','2021-07-06 09:28:06'),(33,'Africa/Monrovia','(GMT) Monrovia','2021-07-06 09:28:06','2021-07-06 09:28:06'),(34,'Europe/Amsterdam','(GMT+01:00) Amsterdam','2021-07-06 09:28:06','2021-07-06 09:28:06'),(35,'Europe/Belgrade','(GMT+01:00) Belgrade','2021-07-06 09:28:06','2021-07-06 09:28:06'),(36,'Europe/Berlin','(GMT+01:00) Berlin','2021-07-06 09:28:06','2021-07-06 09:28:06'),(37,'Europe/Bratislava','(GMT+01:00) Bratislava','2021-07-06 09:28:06','2021-07-06 09:28:06'),(38,'Europe/Brussels','(GMT+01:00) Brussels','2021-07-06 09:28:06','2021-07-06 09:28:06'),(39,'Europe/Budapest','(GMT+01:00) Budapest','2021-07-06 09:28:06','2021-07-06 09:28:06'),(40,'Europe/Copenhagen','(GMT+01:00) Copenhagen','2021-07-06 09:28:06','2021-07-06 09:28:06'),(41,'Europe/Ljubljana','(GMT+01:00) Ljubljana','2021-07-06 09:28:06','2021-07-06 09:28:06'),(42,'Europe/Madrid','(GMT+01:00) Madrid','2021-07-06 09:28:06','2021-07-06 09:28:06'),(43,'Europe/Paris','(GMT+01:00) Paris','2021-07-06 09:28:06','2021-07-06 09:28:06'),(44,'Europe/Prague','(GMT+01:00) Prague','2021-07-06 09:28:06','2021-07-06 09:28:06'),(45,'Europe/Rome','(GMT+01:00) Rome','2021-07-06 09:28:06','2021-07-06 09:28:06'),(46,'Europe/Sarajevo','(GMT+01:00) Sarajevo','2021-07-06 09:28:06','2021-07-06 09:28:06'),(47,'Europe/Skopje','(GMT+01:00) Skopje','2021-07-06 09:28:06','2021-07-06 09:28:06'),(48,'Europe/Stockholm','(GMT+01:00) Stockholm','2021-07-06 09:28:06','2021-07-06 09:28:06'),(49,'Europe/Vienna','(GMT+01:00) Vienna','2021-07-06 09:28:06','2021-07-06 09:28:06'),(50,'Europe/Warsaw','(GMT+01:00) Warsaw','2021-07-06 09:28:06','2021-07-06 09:28:06'),(51,'Europe/Zagreb','(GMT+01:00) Zagreb','2021-07-06 09:28:06','2021-07-06 09:28:06'),(52,'Europe/Athens','(GMT+02:00) Athens','2021-07-06 09:28:06','2021-07-06 09:28:06'),(53,'Europe/Bucharest','(GMT+02:00) Bucharest','2021-07-06 09:28:06','2021-07-06 09:28:06'),(54,'Africa/Cairo','(GMT+02:00) Cairo','2021-07-06 09:28:06','2021-07-06 09:28:06'),(55,'Africa/Harare','(GMT+02:00) Harare','2021-07-06 09:28:06','2021-07-06 09:28:06'),(56,'Europe/Helsinki','(GMT+02:00) Helsinki','2021-07-06 09:28:06','2021-07-06 09:28:06'),(57,'Asia/Jerusalem','(GMT+02:00) Jerusalem','2021-07-06 09:28:06','2021-07-06 09:28:06'),(58,'Europe/Kiev','(GMT+02:00) Kyiv','2021-07-06 09:28:06','2021-07-06 09:28:06'),(59,'Europe/Minsk','(GMT+02:00) Minsk','2021-07-06 09:28:06','2021-07-06 09:28:06'),(60,'Europe/Riga','(GMT+02:00) Riga','2021-07-06 09:28:06','2021-07-06 09:28:06'),(61,'Europe/Sofia','(GMT+02:00) Sofia','2021-07-06 09:28:06','2021-07-06 09:28:06'),(62,'Europe/Tallinn','(GMT+02:00) Tallinn','2021-07-06 09:28:06','2021-07-06 09:28:06'),(63,'Europe/Vilnius','(GMT+02:00) Vilnius','2021-07-06 09:28:06','2021-07-06 09:28:06'),(64,'Europe/Istanbul','(GMT+03:00) Istanbul','2021-07-06 09:28:06','2021-07-06 09:28:06'),(65,'Asia/Baghdad','(GMT+03:00) Baghdad','2021-07-06 09:28:06','2021-07-06 09:28:06'),(66,'Asia/Kuwait','(GMT+03:00) Kuwait','2021-07-06 09:28:06','2021-07-06 09:28:06'),(67,'Africa/Nairobi','(GMT+03:00) Nairobi','2021-07-06 09:28:06','2021-07-06 09:28:06'),(68,'Asia/Riyadh','(GMT+03:00) Riyadh','2021-07-06 09:28:06','2021-07-06 09:28:06'),(69,'Asia/Tehran','(GMT+03:30) Tehran','2021-07-06 09:28:06','2021-07-06 09:28:06'),(70,'Europe/Moscow','(GMT+04:00) Moscow','2021-07-06 09:28:06','2021-07-06 09:28:06'),(71,'Asia/Baku','(GMT+04:00) Baku','2021-07-06 09:28:06','2021-07-06 09:28:06'),(72,'Europe/Volgograd','(GMT+04:00) Volgograd','2021-07-06 09:28:06','2021-07-06 09:28:06'),(73,'Asia/Muscat','(GMT+04:00) Muscat','2021-07-06 09:28:06','2021-07-06 09:28:06'),(74,'Asia/Tbilisi','(GMT+04:00) Tbilisi','2021-07-06 09:28:06','2021-07-06 09:28:06'),(75,'Asia/Yerevan','(GMT+04:00) Yerevan','2021-07-06 09:28:06','2021-07-06 09:28:06'),(76,'Asia/Kabul','(GMT+04:30) Kabul','2021-07-06 09:28:06','2021-07-06 09:28:06'),(77,'Asia/Karachi','(GMT+05:00) Karachi','2021-07-06 09:28:06','2021-07-06 09:28:06'),(78,'Asia/Tashkent','(GMT+05:00) Tashkent','2021-07-06 09:28:06','2021-07-06 09:28:06'),(79,'Asia/Kolkata','(GMT+05:30) Kolkata','2021-07-06 09:28:06','2021-07-06 09:28:06'),(80,'Asia/Kathmandu','(GMT+05:45) Kathmandu','2021-07-06 09:28:06','2021-07-06 09:28:06'),(81,'Asia/Yekaterinburg','(GMT+06:00) Ekaterinburg','2021-07-06 09:28:06','2021-07-06 09:28:06'),(82,'Asia/Almaty','(GMT+06:00) Almaty','2021-07-06 09:28:06','2021-07-06 09:28:06'),(83,'Asia/Dhaka','(GMT+06:00) Dhaka','2021-07-06 09:28:06','2021-07-06 09:28:06'),(84,'Asia/Novosibirsk','(GMT+07:00) Novosibirsk','2021-07-06 09:28:06','2021-07-06 09:28:06'),(85,'Asia/Bangkok','(GMT+07:00) Bangkok','2021-07-06 09:28:06','2021-07-06 09:28:06'),(86,'Asia/Ho_Chi_Minh','(GMT+07.00) Ho Chi Minh','2021-07-06 09:28:06','2021-07-06 09:28:06'),(87,'Asia/Jakarta','(GMT+07:00) Jakarta','2021-07-06 09:28:06','2021-07-06 09:28:06'),(88,'Asia/Krasnoyarsk','(GMT+08:00) Krasnoyarsk','2021-07-06 09:28:06','2021-07-06 09:28:06'),(89,'Asia/Chongqing','(GMT+08:00) Chongqing','2021-07-06 09:28:06','2021-07-06 09:28:06'),(90,'Asia/Hong_Kong','(GMT+08:00) Hong Kong','2021-07-06 09:28:06','2021-07-06 09:28:06'),(91,'Asia/Kuala_Lumpur','(GMT+08:00) Kuala Lumpur','2021-07-06 09:28:06','2021-07-06 09:28:06'),(92,'Australia/Perth','(GMT+08:00) Perth','2021-07-06 09:28:06','2021-07-06 09:28:06'),(93,'Asia/Singapore','(GMT+08:00) Singapore','2021-07-06 09:28:06','2021-07-06 09:28:06'),(94,'Asia/Taipei','(GMT+08:00) Taipei','2021-07-06 09:28:06','2021-07-06 09:28:06'),(95,'Asia/Ulaanbaatar','(GMT+08:00) Ulaan Bataar','2021-07-06 09:28:06','2021-07-06 09:28:06'),(96,'Asia/Urumqi','(GMT+08:00) Urumqi','2021-07-06 09:28:06','2021-07-06 09:28:06'),(97,'Asia/Irkutsk','(GMT+09:00) Irkutsk','2021-07-06 09:28:06','2021-07-06 09:28:06'),(98,'Asia/Seoul','(GMT+09:00) Seoul','2021-07-06 09:28:06','2021-07-06 09:28:06'),(99,'Asia/Tokyo','(GMT+09:00) Tokyo','2021-07-06 09:28:06','2021-07-06 09:28:06'),(100,'Australia/Adelaide','(GMT+09:30) Adelaide','2021-07-06 09:28:06','2021-07-06 09:28:06'),(101,'Australia/Darwin','(GMT+09:30) Darwin','2021-07-06 09:28:06','2021-07-06 09:28:06'),(102,'Asia/Yakutsk','(GMT+10:00) Yakutsk','2021-07-06 09:28:06','2021-07-06 09:28:06'),(103,'Australia/Brisbane','(GMT+10:00) Brisbane','2021-07-06 09:28:06','2021-07-06 09:28:06'),(104,'Australia/Canberra','(GMT+10:00) Canberra','2021-07-06 09:28:06','2021-07-06 09:28:06'),(105,'Pacific/Guam','(GMT+10:00) Guam','2021-07-06 09:28:06','2021-07-06 09:28:06'),(106,'Australia/Hobart','(GMT+10:00) Hobart','2021-07-06 09:28:06','2021-07-06 09:28:06'),(107,'Australia/Melbourne','(GMT+10:00) Melbourne','2021-07-06 09:28:06','2021-07-06 09:28:06'),(108,'Pacific/Port_Moresby','(GMT+10:00) Port Moresby','2021-07-06 09:28:06','2021-07-06 09:28:06'),(109,'Australia/Sydney','(GMT+10:00) Sydney','2021-07-06 09:28:06','2021-07-06 09:28:06'),(110,'Asia/Vladivostok','(GMT+11:00) Vladivostok','2021-07-06 09:28:06','2021-07-06 09:28:06'),(111,'Asia/Magadan','(GMT+12:00) Magadan','2021-07-06 09:28:06','2021-07-06 09:28:06'),(112,'Pacific/Auckland','(GMT+12:00) Auckland','2021-07-06 09:28:06','2021-07-06 09:28:06'),(113,'Pacific/Fiji','(GMT+12:00) Fiji','2021-07-06 09:28:06','2021-07-06 09:28:06');
/*!40000 ALTER TABLE `time_zones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public/whatsapp-support/demo-avatar.jpg',
  `ws_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin','admin1@gmail.com',NULL,'$2y$10$YFZqv6CESvVn8iiZmdCrAef.S1BSAxdl4NxzJhi6TZlGQUNbcKrTa','1','public/whatsapp-support/demo-avatar.jpg','takaxh0als6vlmk8wtxnifnvxtfejk7jlryrywbppig4rfk0rrrvyclkjwtogytm',NULL,'2021-07-06 09:28:06','2021-07-06 09:28:06'),(2,'User','user@gmail.com',NULL,'$2y$10$50XLGosJg2ZQ8B9CJGuhnOhVORB0bQuJE5avFIcDYzWFMAEGA7Iwq','2','public/whatsapp-support/demo-avatar.jpg','xbvllnoysz8ksqyhlvvhc6ndkci3g5tbjeho5kcu7fvixd4s9os0k9qlqd4fhck6',NULL,'2021-07-06 09:28:06','2021-07-06 09:28:06'),(3,'Agent','agent@gmail.com',NULL,'$2y$10$o1WLOdnq07NUOejWz3gztO9Ewij/LGwDQ7T/cUOtQaL5BXfDOu4RW','3','public/whatsapp-support/demo-avatar.jpg','hlz6nmcor19snalk72wmhrccozdhgco6ny6offm5vx93okli4vpytw6mxkn53unj',NULL,'2021-07-06 09:28:06','2021-07-06 09:28:06');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `version_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `version_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `release_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `version_histories` WRITE;
/*!40000 ALTER TABLE `version_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `version_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `whatsapp_support_agent_times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whatsapp_support_agent_times` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_id` bigint(20) unsigned NOT NULL,
  `day` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start` time NOT NULL,
  `end` time NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `whatsapp_support_agent_times_agent_id_foreign` (`agent_id`),
  CONSTRAINT `whatsapp_support_agent_times_agent_id_foreign` FOREIGN KEY (`agent_id`) REFERENCES `whatsapp_support_agents` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `whatsapp_support_agent_times` WRITE;
/*!40000 ALTER TABLE `whatsapp_support_agent_times` DISABLE KEYS */;
/*!40000 ALTER TABLE `whatsapp_support_agent_times` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `whatsapp_support_agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whatsapp_support_agents` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `user_id` bigint(20) unsigned NOT NULL,
  `always_available` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `whatsapp_support_agents_user_id_foreign` (`user_id`),
  CONSTRAINT `whatsapp_support_agents_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `whatsapp_support_agents` WRITE;
/*!40000 ALTER TABLE `whatsapp_support_agents` DISABLE KEYS */;
INSERT INTO `whatsapp_support_agents` VALUES (1,'Agent','Sales','public/whatsapp-support/demo-avatar.jpg','+8801841412141',1,3,1,'2021-07-06 09:28:06','2021-07-06 09:28:06');
/*!40000 ALTER TABLE `whatsapp_support_agents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `whatsapp_support_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whatsapp_support_messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `message` text COLLATE utf8mb4_unicode_ci,
  `ip` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `device_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `os` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `domain` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `whatsapp_support_messages` WRITE;
/*!40000 ALTER TABLE `whatsapp_support_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `whatsapp_support_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `whatsapp_support_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `whatsapp_support_settings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `agent_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'single',
  `availability` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'both' COMMENT 'mobile',
  `showing_page` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all' COMMENT 'all',
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#0dc152',
  `intro_text` text COLLATE utf8mb4_unicode_ci,
  `welcome_message` text COLLATE utf8mb4_unicode_ci,
  `homepage_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `primary_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `open_popup` tinyint(1) NOT NULL DEFAULT '0',
  `show_unavailable_agent` tinyint(1) NOT NULL DEFAULT '1',
  `layout` int(11) NOT NULL DEFAULT '1',
  `icon_position` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'bottom_right',
  `bottom` int(11) NOT NULL DEFAULT '20',
  `right` int(11) NOT NULL DEFAULT '30',
  `left` int(11) NOT NULL DEFAULT '30',
  `bubble_logo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public/whatsapp-support/demo-avatar.jpg',
  `layout_preview_url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'whatsapp-support/preview-1.png',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `whatsapp_support_settings` WRITE;
/*!40000 ALTER TABLE `whatsapp_support_settings` DISABLE KEYS */;
INSERT INTO `whatsapp_support_settings` VALUES (1,'single','both','all','#0dc152','Our customer support team is here to answer your questions. Ask us anything!','Hi, How can I help?','','+8801841412141',0,1,1,'bottom_right',20,30,30,'public/whatsapp-support/demo-avatar.jpg','whatsapp-support/preview-1.png',NULL,NULL);
/*!40000 ALTER TABLE `whatsapp_support_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

