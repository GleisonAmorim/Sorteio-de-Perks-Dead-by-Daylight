(function($)
{
    "use strict";

    $("#inviteToGroup").select2();
    $("#selectStaffss").select2();
    $("#checkbox").on('click', function () {
        if ($("#checkbox").is(':checked')) {
            $("#selectStaffss > option").prop("selected", "selected");
            $("#selectStaffss").trigger("change");
        } else {
            $("#selectStaffss > option").removeAttr("selected");
            $("#selectStaffss").trigger("change");
        }
    });


    // for select2 multiple dropdown in send email/Sms in Class tab
    $("#selectSectionss").select2();
    $("#checkbox_section").on('click', function () {
        if ($("#checkbox_section").is(':checked')) {
            $("#selectSectionss > option").prop("selected", "selected");
            $("#selectSectionss").trigger("change");
        } else {
            $("#selectSectionss > option").removeAttr("selected");
            $("#selectSectionss").trigger("change");
        }
    });

    $('#languageChange').on('change', function () {
            var str = $('#languageChange').val();
            var url = $('#url').val();
            var formData = {
                id: $(this).val()
            };
            // get section for student
            $.ajax({
                type: "POST",
                data: formData,
                dataType: 'json',
                url: url + '/' + 'language-change',
                success: function (data) {
                    url= url + '/' + 'locale'+ '/' + data[0].language_universal;
                    window.location.href = url;
                },
                error: function (data) {
                    console.log('Error:', data);
                }
            });
        });

    $(document).on("click", "#delete", function(e){
        e.preventDefault();
        var link = $(this).attr("href");
        swal({
            title: "Do you Want to delete?",
            text: "Once You Delete, This will be Permanently Deleted!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    window.location.href = link;
                } else {
                    swal("Safe Data!");
                }
            });
    });

    $(".leads_option_open").on("click", function() {
        $(this).parent(".dots_lines").toggleClass("leads_option_active");
    });
    $(document).on('click', function(event) {
        if (!$(event.target).closest(".dots_lines").length) {
            $("body")
                .find(".dots_lines")
                .removeClass("leads_option_active");
        }
    });

    $('.user_search').select2({
        matcher: function(term, text, option) {
            return text.toUpperCase().indexOf(term.toUpperCase())>=0 || option.val().toUpperCase().indexOf(term.toUpperCase())>=0;
        }
    });

    $('.close').on('click', function() {
        $('.custom_notification').removeClass('open_notification');
    });

    $('#php_file_input').on("change", function (e) {
        $("#php_file_input_ph").attr("placeholder", e.target.files[0].name);
    });

})(jQuery);
