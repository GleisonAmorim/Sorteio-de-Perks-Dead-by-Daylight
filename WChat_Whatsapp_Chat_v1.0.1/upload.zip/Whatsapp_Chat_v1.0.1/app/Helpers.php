<?php

use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Schema;
use Modules\Localization\Entities\Language;

if (!function_exists('permissionCheck')) {
    function permissionCheck($route_name)
    {
        if (auth()->check()) {
            if (auth()->user()->role_id == 1) {
                return TRUE;
            } else {
                $roles = app('permission_list');
                $role = $roles->where('id', auth()->user()->role_id)->first();
                if ($role != null && $role->permissions->contains('route', $route_name)) {
                    return TRUE;
                } else {
                    return FALSE;
                }
            }
        }
        return FALSE;
    }
}

if (!function_exists('appMode')) {
    function appMode()
    {
        return Config::get('app.app_sync');
    }
}

if (!function_exists('demoCheck')) {
    function demoCheck()
    {
        if (appMode()) {
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }
    }
}

if (!function_exists('isRtl')){
    function isRtl(){
        $rtl_array = ['ar'];

        $locale = App::currentLocale();
        if (Schema::hasTable('languages')){
            $rtl = Language::where('code', $locale)->first()->rtl;
        }else{
            $rtl = in_array($locale, $rtl_array);
        }

        return $rtl;
    }
}

if (!function_exists('getSetting')) {
    function getSetting()
    {
        try {
            return app('getSetting');

        } catch (Exception $exception) {
            return false;
        }
    }
}
