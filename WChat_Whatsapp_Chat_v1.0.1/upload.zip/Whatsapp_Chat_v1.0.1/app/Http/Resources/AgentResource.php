<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AgentResource extends JsonResource
{
    public function toArray($request)
    {
        return [
            'name' => $this->name,
            'designation' => $this->designation,
            'avatar' => $this->avatar,
            'number' => $this->number,
            'status' => $this->status,
            'available' => $this->isAvailable(),
            'always_available' => $this->always_available,
        ];
    }
}
