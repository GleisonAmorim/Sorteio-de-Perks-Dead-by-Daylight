<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Mews\Purifier\Facades\Purifier;

class XSS
{
    public function handle($request, Closure $next)
    {
        $inputs = $request->all();
        if(count($inputs) > 0)
        {
            foreach ($inputs as $key => $input){
                $request->merge([$key => Purifier::clean($input)]);
            }
        }

        return $next($request);

    }
}
