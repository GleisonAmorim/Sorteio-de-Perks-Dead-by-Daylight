<?php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Modules\RolePermission\Entities\Role;
use Modules\WhatsappSupport\Traits\ImageStore;

class UserController extends Controller
{

    use ImageStore;

    public function index()
    {
        $users = User::whereNotIn('role_id',[1,3])->get();
        return view('user.index', compact('users'));
    }

    public function create()
    {
        $roles = Role::whereNotIn('id', [3])->get();
        return view('user.create', compact('roles'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'role_id' => 'required',
            'email' => 'required|unique:users',
        ]);

        $avatar = 'public/whatsapp-support/demo-avatar.jpg';

        if ($request->hasFile('image')){
            $avatar = $this->saveAvatarImage($request->image);
        }

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'avatar' => $avatar,
            'role_id' => $request->role_id,
            'password' => bcrypt(12345678),
        ]);

        session()->flash('success','User Created!');
        return redirect()->route('users.index');
    }

    public function show($id)
    {
        $user = User::find($id);
        $roles = Role::whereNotIn('id', [3])->get();
        return view('user.show', compact('user','roles'));
    }

    public function update(Request $request, $id)
    {
        if(appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }

        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
        ]);

        $user = User::find($id);

        $request['avatar'] = auth()->user()->avatar;
        if ($request->hasFile('image')){
            $request['avatar'] = $this->saveAvatarImage($request->image);
            try {unlink($user->avatar);}catch (\Exception $e){}


        }
        $user->update($request->only('name','email', 'avatar', 'role_id'));

        session()->flash('success', 'Profile Updated!');
        return redirect()->route('users.index');
    }

    public function destroy($id)
    {
        if(appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }

        $user = User::find($id);
        try {unlink($user->avatar);}catch (\Exception $e){}
        $user->delete();
        session()->flash('success','Agent Delete!');
        return redirect()->back();
    }


}
