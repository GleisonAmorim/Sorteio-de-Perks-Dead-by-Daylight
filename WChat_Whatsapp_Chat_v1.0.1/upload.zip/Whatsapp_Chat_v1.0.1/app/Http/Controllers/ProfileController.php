<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Modules\WhatsappSupport\Traits\ImageStore;

class ProfileController extends Controller
{

    use ImageStore;

    public function index()
    {
        $user = auth()->user();
        return view('profile.index', compact('user'));
    }

    public function update(Request $request)
    {
        if(appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }

        $this->validate($request, [
            'name' => 'required',
            'email' => 'required',
        ]);

        $request['avatar'] = auth()->user()->avatar;
        if ($request->hasFile('image')){
            $request['avatar'] = $this->saveAvatarImage($request->image);
        }


        auth()->user()->update($request->only('name','email', 'avatar'));

        session()->flash('success', 'Profile Updated!');
        return redirect()->back();
    }

    public function password(Request $request)
    {
        if(auth()->user()->isAdmin() && appMode()){
            session()->flash('error','For the demo version, you cannot do this action.');
            return redirect()->back();
        }
        $this->validate($request, [
            'current_password' => 'required',
            'password' => 'min:6|required_with:confirm_password|same:confirm_password',
            'confirm_password' => 'min:6|required'
        ]);

        $oldPass = Hash::check($request->current_password, auth()->user()->password);

        if(!$oldPass){
            session()->flash('error', 'Your given current password is incorrect!');
            return redirect()->back();
        }

        auth()->user()->update([
            'password' => bcrypt($request->password)
        ]);

        session()->flash('success', 'Your password is successfully changed!');
        return redirect()->back();

    }
}
