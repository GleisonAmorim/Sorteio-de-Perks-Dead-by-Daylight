<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Requests\MessageStoreRequest;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;
use Modules\WhatsappSupport\Entities\Agents;
use Modules\WhatsappSupport\Entities\Settings;
use Modules\WhatsappSupport\Repositories\MessageRepository;

class HomeController extends Controller
{

    public function initials(Request $request)
    {
        $user = User::where('ws_token',$request->ws_token)->first();
        if (is_null($user)){
            return response()->json(['valid' => false]);
        }

        $setting = Settings::first();
        $agents = Agents::all();
        foreach ($agents as $agent){
            $agent['available'] = $agent->isAvailable();
        }
        return response()->json([
                'valid'=> true,
                'setting' => $setting,
                'agents' => $agents
            ]);
    }

    public function send(MessageStoreRequest $request)
    {
        try {
            MessageRepository::store($request->all());
            $ws_setting = Settings::first();
            $to_number = $ws_setting->isMulti() ? request()->agent_number : $ws_setting->primary_number;
            return redirect()->to('https://api.whatsapp.com/send?phone='.$to_number.'&text='.$request->message);
        }catch (\Exception $e){
            \Log::info($e->getMessage());
            return redirect()->back();
        }

    }

    public function languageChange(Request $request){

        \session()->put('applocale', $request->lang);

        return redirect()->back();
    }
}
